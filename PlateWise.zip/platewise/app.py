"""PlateWise entry point: login, sidebar navigation, top bar and page router.
Run with:  streamlit run app.py
(The folder is called 'views' on purpose: a folder called 'pages' would trigger Streamlit's automatic multipage menu.)"""
import importlib
from datetime import date, datetime

import streamlit as st

from core import database as db
from core import security, ui
from services import common

st.set_page_config(page_title="PlateWise", page_icon="🍽", layout="wide")
ui.inject_css()

# key, label, icon, permission needed to open, module
GROUPS = {
    "Operations": [("overview", "Operations Overview", "🧭", "view", "overview"),
                   ("zones", "Canteen Floor & Zones", "🗺", "view", "zone_map"),
                   ("batches", "Batch Preparation Board", "🍳", "view", "batches"),
                   ("service", "Service Counter", "🍽", "view", "service_counter"),
                   ("waste", "Waste Measurement Desk", "⚖", "view", "waste_desk")],
    "Planning": [("demand", "Demand Planning Studio", "📈", "view", "demand"),
                 ("recs", "Recommendation Review", "✅", "view", "recommendations")],
    "Analytics": [("intel", "Waste Intelligence", "🔍", "view", "waste_intel"),
                  ("sql", "SQL Reports", "🧮", "reports.view", "sql_reports")],
    "Store & setup": [("inventory", "Inventory & Ingredient Store", "📦", "view", "inventory"),
                      ("menu", "Menu Management", "📋", "view", "menu")],
    "Admin": [("reports", "Reports & Exports", "📤", "reports.view", "reports"),
              ("users", "User Management", "👥", "users.manage", "users"),
              ("audit", "Audit History", "🕮", "audit.view", "audit")],
}


def connection_gate():
    ok, msg = db.check_connection()
    if not ok:
        st.error(msg)
        st.code("1) Copy .env.example to .env and fill in the MySQL settings\n2) python -m scripts.init_db --admin-user admin\n"
                "3) (optional) python -m scripts.seed_synthetic --reset\n4) streamlit run app.py", language="bash")
        st.stop()
    if db.query_df("SELECT COUNT(*) AS n FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name='users'").iloc[0, 0] == 0:
        st.warning("The database is empty. Run `python -m scripts.init_db --admin-user admin` first.")
        st.stop()


def login_screen():
    c1, c2, c3 = st.columns([1, 1.2, 1])
    with c2:
        st.markdown(f'<div style="background:{ui.NAVY};padding:1.2rem 1.4rem;margin-top:3rem;">'
                    f'<div class="pw-brand">{ui.LOGO_SVG}<div><b>PlateWise</b><small>Smart Canteen Food Waste & Demand Intelligence</small></div></div></div>',
                    unsafe_allow_html=True)
        with st.form("login"):
            u = st.text_input("Username")
            p = st.text_input("Password", type="password")
            go = st.form_submit_button("Sign in", type="primary", use_container_width=True)
        if go:
            tries = st.session_state.get("tries", 0)
            if tries >= 5:
                st.error("Too many failed attempts in this session. Reload the page to try again.")
                return
            user = security.authenticate(u, p)
            if user:
                st.session_state.user, st.session_state.tries = user, 0
                st.rerun()
            st.session_state.tries = tries + 1
            st.error("Invalid username or password.")
        st.caption("Demonstration build. Data in a freshly seeded database is SYNTHETIC.")


def sidebar(user) -> tuple:
    allowed = {p[0]: p for g in GROUPS.values() for p in g if security.can(user, p[3])}
    if st.session_state.get("page") not in allowed:
        st.session_state.page = "overview"
    with st.sidebar:
        st.markdown(f'<div class="pw-brand">{ui.LOGO_SVG}<div><b>PlateWise</b><small>{ui.esc(common.settings()["canteen_name"])}</small></div></div>', unsafe_allow_html=True)
        for group, pages in GROUPS.items():
            vis = [p for p in pages if p[0] in allowed]
            if not vis:
                continue
            st.caption(group.upper())
            for key, label, icon, _perm, _mod in vis:
                if st.button(f"{icon}  {label}", key=f"nav_{key}", type="primary" if st.session_state.page == key else "secondary"):
                    st.session_state.page = key
                    st.rerun()
        st.divider()
        st.caption(f"Signed in: **{user['full_name']}** ({user['role']})")
        if st.button("Sign out", key="logout"):
            for k in ("user", "page"):
                st.session_state.pop(k, None)
            st.rerun()
    return allowed[st.session_state.page]


def canteen_status(op_date: date) -> str:
    st_ = common.settings()
    if op_date.weekday() not in st_["operating_days"]:
        return "Closed day (not an operating weekday)"
    if op_date != date.today():
        return "Viewing a past/future date"
    now = datetime.now().time()
    for p in common.periods().itertuples():
        start = (datetime.min + p.start_time).time()
        end = (datetime.min + p.end_time).time()
        if start <= now <= end:
            return f"Open: {p.period_name} service"
    return "Open day, between services"


def main():
    connection_gate()
    user = st.session_state.get("user")
    if not user:
        login_screen()
        return
    page = sidebar(user)
    t1, t2, t3 = st.columns([3, 1.4, 2.4])
    t1.markdown(f"### {page[2]} {page[1]}")
    op_date = t2.date_input("Operating date", value=date.today(), key="op_date", label_visibility="collapsed")
    t3.markdown(f'<div style="text-align:right;padding-top:.5rem;">{ui.chip(canteen_status(op_date))} '
                f'{ui.chip(op_date.strftime("%a %d %b %Y"), plain=True)}</div>', unsafe_allow_html=True)
    st.markdown('<div style="border-bottom:1px solid #D9D3C0;margin-bottom:.8rem;"></div>', unsafe_allow_html=True)
    module = importlib.import_module(f"views.{page[4]}")
    try:
        module.render(user, op_date)
    except security.PermissionDenied as e:
        st.error(f"🔒 {e}")
    except db.DatabaseError as e:
        st.error(f"🗄️ {e}")


main()
