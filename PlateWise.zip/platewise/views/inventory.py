"""Page 7: Inventory & Ingredient Store (Zone E)."""
from datetime import date

import pandas as pd
import plotly.express as px
import streamlit as st

from core import security, ui
from services import common, inventory_service as inv


def render(user, op_date):
    can_write = security.can(user, "inventory.write")
    t1, t2, t3, t4, t5 = st.tabs(["Current stock", "Receive stock", "Spoilage & adjustments", "Usage & cost", "Setup"])
    ings = inv.ingredients()
    with t1:
        s = inv.stock()
        if s.empty:
            ui.empty("No ingredients defined yet. Add them in the Setup tab.")
        else:
            low = int(s["low_stock_flag"].sum())
            exp = inv.expiry_watch(op_date)
            ui.kpi_row([("Ingredients tracked", len(s), "", ""), ("Low stock", low, "items", "at or below reorder level"),
                        ("Expiry alerts", len(exp), "lots", "expired or expiring soon"), ("Stock value", f"{common.settings()['currency']}{s['stock_value'].sum():,.0f}", "", "at latest cost")])
            v = s.copy()
            v["Status"] = v["low_stock_flag"].map({1: "▲ Low", 0: "OK"})
            st.dataframe(v[["ingredient_name", "current_stock", "unit_code", "reorder_level", "last_purchase_date", "Status"]].rename(columns={
                "ingredient_name": "Ingredient", "current_stock": "Stock", "unit_code": "Unit", "reorder_level": "Reorder level", "last_purchase_date": "Last purchase"}).round(2),
                hide_index=True, use_container_width=True)
            ui.section("Expiry watch (FIFO estimate)")
            if exp.empty:
                st.markdown("✓ No lots expired or expiring soon.")
            else:
                st.dataframe(exp[["ingredient_name", "remaining_qty", "unit_code", "received", "expiry_date", "days_to_expiry", "alert"]].rename(columns={
                    "ingredient_name": "Ingredient", "remaining_qty": "Remaining", "unit_code": "Unit", "received": "Received", "expiry_date": "Expiry", "days_to_expiry": "Days left", "alert": "Alert"}),
                    hide_index=True, use_container_width=True)
                ui.note("Remaining quantity per lot assumes the oldest stock is used first.")
    with t2:
        if not can_write:
            st.info("Your role can view but not record stock.")
        elif ings.empty:
            ui.empty("Add an ingredient first (Setup tab).")
        else:
            sup = inv.suppliers()
            if sup.empty:
                ui.empty("Add a supplier first (Setup tab).")
            else:
                with st.form("recv", clear_on_submit=True):
                    g = st.selectbox("Ingredient", ings["ingredient_id"], format_func=lambda i: ings.set_index("ingredient_id").loc[i, "ingredient_name"])
                    c1, c2, c3 = st.columns(3)
                    q = c1.number_input("Quantity", min_value=0.0, value=0.0, step=1.0)
                    u = c2.selectbox("Unit", ["kg", "g", "l", "ml", "pcs"])
                    c = c3.number_input("Cost per ingredient unit", min_value=0.0, value=0.0, step=1.0, help="Cost per kg / l / pcs of the ingredient's own unit")
                    c4, c5 = st.columns(2)
                    sp = c4.selectbox("Supplier", sup["supplier_id"], format_func=lambda i: sup.set_index("supplier_id").loc[i, "supplier_name"])
                    inv_no = c5.text_input("Invoice number")
                    r1, r2 = st.columns(2)
                    rd = r1.date_input("Received on", value=min(op_date, date.today()))
                    ex = r2.date_input("Expiry date (blank = shelf life)", value=None)
                    go = st.form_submit_button("Record purchase", type="primary")
                if go:
                    with ui.guarded("Purchase recorded."):
                        inv.receive_stock(user, g, q, u, c, rd, sp, inv_no, ex)
    with t3:
        if not can_write:
            st.info("Your role can view but not record spoilage.")
        elif not ings.empty:
            a, b = st.columns(2)
            with a:
                st.markdown("**Record spoilage**")
                with st.form("spoil", clear_on_submit=True):
                    g = st.selectbox("Ingredient", ings["ingredient_id"], format_func=lambda i: ings.set_index("ingredient_id").loc[i, "ingredient_name"], key="sp_g")
                    q = st.number_input("Spoiled quantity", min_value=0.0, value=0.0, step=0.5)
                    u = st.selectbox("Unit", ["kg", "g", "l", "ml", "pcs"], key="sp_u")
                    n = st.text_input("Reason / note")
                    go = st.form_submit_button("Record spoilage")
                if go:
                    with ui.guarded("Spoilage recorded."):
                        inv.record_spoilage(user, g, q, u, min(op_date, date.today()), n)
            with b:
                st.markdown("**Stock-count adjustment**")
                with st.form("adj", clear_on_submit=True):
                    g = st.selectbox("Ingredient", ings["ingredient_id"], format_func=lambda i: ings.set_index("ingredient_id").loc[i, "ingredient_name"], key="ad_g")
                    ch = st.number_input("Change (+/−, in ingredient unit)", value=0.0, step=0.5)
                    why = st.text_input("Reason (required)")
                    go = st.form_submit_button("Apply adjustment")
                if go:
                    with ui.guarded("Adjustment recorded and audited."):
                        inv.adjust_stock(user, g, ch, min(op_date, date.today()), why)
        ui.section("Recent movements")
        m = inv.movements(100)
        st.dataframe(m, hide_index=True, use_container_width=True, height=300) if not m.empty else ui.empty("No movements yet.")
    with t4:
        from services import reporting_service as rs
        df = rs.ds_ingredient_consumption()
        if df.empty:
            ui.empty("No ingredient movements yet.")
        else:
            tot = df.groupby("Ingredient").agg(Used=("Usage_Cost", "sum"), Spoiled=("Spoilage_Cost", "sum"), Purchased=("Purchase_Cost", "sum")).reset_index()
            fig = px.bar(tot.melt("Ingredient", var_name="Type", value_name="Cost"), x="Ingredient", y="Cost", color="Type", barmode="group",
                         title="Ingredient cost: purchased, used, spoiled", color_discrete_sequence=[ui.LIGHTBLUE, ui.VIOLET, ui.NAVY])
            st.plotly_chart(ui.style_fig(fig, 340), use_container_width=True)
            sp = inv.spoilage_vs_purchases()
            sp["spoilage % of purchases"] = (sp["spoiled_cost"] / sp["purchased_cost"].replace(0, pd.NA) * 100).astype(float).round(1)
            st.dataframe(sp.drop(columns=["ingredient_id"]).round(2), hide_index=True, use_container_width=True)
            ui.note("Usage is derived from recipe quantities x portions prepared, so it is an estimate of consumption, not a stock-take.")
    with t5:
        if not can_write:
            st.info("Only roles with inventory permission can change setup.")
        else:
            a, b = st.columns(2)
            with a:
                st.markdown("**New ingredient**")
                with st.form("new_ing", clear_on_submit=True):
                    n = st.text_input("Name")
                    c1, c2 = st.columns(2)
                    un = c1.selectbox("Unit", ["kg", "l", "pcs"])
                    co = c2.number_input("Cost per unit", min_value=0.0, value=0.0, step=1.0)
                    c3, c4 = st.columns(2)
                    ro = c3.number_input("Reorder level", min_value=0.0, value=0.0, step=1.0)
                    sl = c4.number_input("Shelf life (days)", min_value=1, value=30)
                    go = st.form_submit_button("Add ingredient")
                if go:
                    with ui.guarded("Ingredient added."):
                        inv.add_ingredient(user, n, un, co, ro, sl)
            with b:
                st.markdown("**New supplier**")
                with st.form("new_sup", clear_on_submit=True):
                    n = st.text_input("Supplier name")
                    ph = st.text_input("Phone")
                    go = st.form_submit_button("Add supplier")
                if go:
                    with ui.guarded("Supplier added."):
                        inv.add_supplier(user, n, ph)
            st.dataframe(inv.suppliers(), hide_index=True, use_container_width=True)
