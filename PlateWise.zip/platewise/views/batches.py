"""Page 3: Batch Preparation Board (Zone A)."""
from datetime import datetime

import pandas as pd
import streamlit as st

from core import security, ui
from services import common, preparation_service as prep, forecast_service


def _card(b) -> str:
    pct = lambda x: 0 if not b["qty_prepared"] else min(100, round(x / b["qty_prepared"] * 100))
    return (f'<div class="pw-card"><div class="hd"><span class="nm">{ui.esc(b["item_name"])}</span><span class="cd">{ui.esc(b["batch_code"])}</span></div>'
            f'<div class="meta">{ui.esc(b["station_name"])} · prepared {pd.Timestamp(b["prepared_at"]):%H:%M} · cost Rs {b["unit_cost"]:.2f}/portion ({ui.esc(b["cost_source"])})'
            f'{" · SYNTHETIC" if b["is_synthetic"] else ""}</div>'
            f'<div class="nums"><div><b>{b["qty_prepared"]}</b>prepared</div><div><b>{b["served_allocated"]}</b>served*</div><div><b>{b["remaining"]}</b>remaining*</div></div>'
            f'<div class="pw-bar"><i style="width:{pct(b["served_allocated"])}%"></i></div></div>')


def render(user, op_date):
    can_write = security.can(user, "prep.write")
    items = common.items()
    stations = common.stations("prep")
    plan = forecast_service.pending_for(op_date)
    left, right = st.columns([1, 2.2], gap="large")
    with left:
        ui.section("Record a new batch")
        if not can_write:
            st.info("Your role can view the board but not record batches.")
        else:
            with st.form("new_batch", clear_on_submit=True):
                it = st.selectbox("Menu item", items["item_id"], format_func=lambda i: items.set_index("item_id").loc[i, "item_name"])
                stn = st.selectbox("Preparation station", stations["station_id"], format_func=lambda i: stations.set_index("station_id").loc[i, "station_name"])
                qty = st.number_input("Quantity prepared (portions)", min_value=0, max_value=5000, value=0, step=5)
                c1, c2 = st.columns(2)
                tm = c1.time_input("Time prepared", value=datetime.now().time().replace(second=0, microsecond=0))
                cost = c2.number_input("Manual cost per portion (optional)", min_value=0.0, value=0.0, step=0.5, help="Leave 0 to use the recipe cost.")
                notes = st.text_input("Notes (optional)")
                go = st.form_submit_button("Save batch", type="primary", use_container_width=True)
            if go:
                with ui.guarded():
                    r = prep.create_batch(user, op_date, it, stn, qty, datetime.combine(op_date, tm), cost or None, notes)
                    st.success(f"Saved {r['batch_code']} (cost Rs {r['unit_cost']:.2f}/portion from {r['cost_source']}).")
        if not plan.empty:
            ui.section("Manager's plan for this date")
            ap = plan[plan["status"].isin(["approved", "adjusted"])]
            if ap.empty:
                ui.note("Recommendations exist but none are approved yet (Demand Planning Studio).")
            else:
                st.dataframe(ap[["item_name", "approved_qty"]].rename(columns={"item_name": "Item", "approved_qty": "Approved portions"}), hide_index=True, use_container_width=True)
    with right:
        batches = prep.list_batches(op_date)
        ui.section(f"Batches on {op_date:%d %b %Y}")
        if not batches:
            ui.empty("No batches recorded for this date. Use the form to add the first batch.")
            return
        f1, f2 = st.columns(2)
        per = f1.selectbox("Service period", ["All"] + common.periods()["period_name"].tolist())
        stn_f = f2.selectbox("Station", ["All"] + stations["station_name"].tolist())
        item_period = items.set_index("item_name")["period_name"].to_dict()
        shown = [b for b in batches if (per == "All" or item_period.get(b["item_name"]) == per) and (stn_f == "All" or b["station_name"] == stn_f)]
        if not shown:
            ui.empty("No batches match these filters.")
        cols = st.columns(2)
        for i, b in enumerate(shown):
            cols[i % 2].markdown(_card(b), unsafe_allow_html=True)
        ui.note("* Served per batch is an allocation (oldest batch first); the counter records served portions per item, not per batch.")
        if can_write and shown:
            with st.expander("Correct a batch quantity"):
                with st.form("fix_batch"):
                    ch = st.selectbox("Batch", [b["batch_id"] for b in shown], format_func=lambda i: next(f"{x['batch_code']} · {x['item_name']} ({x['qty_prepared']})" for x in shown if x["batch_id"] == i))
                    nq = st.number_input("New quantity (portions)", min_value=1, max_value=5000, value=10, step=1)
                    why = st.text_input("Reason (required, saved in audit history)")
                    ok = st.form_submit_button("Update quantity")
                if ok:
                    with ui.guarded("Quantity updated and logged."):
                        prep.update_batch_qty(user, int(ch), nq, why)
