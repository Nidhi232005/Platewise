"""Menu management: items, portion weights, costs, recipes."""
import pandas as pd
import streamlit as st

from core import security, ui
from services import common, inventory_service as inv, menu_service as ms


def render(user, op_date):
    can = security.can(user, "menu.write")
    items = common.items(False)
    cats, pers = ms.categories(), common.periods()
    t1, t2, t3 = st.tabs(["Menu items", "Recipes & cost", "Item history"])
    with t1:
        st.dataframe(items.rename(columns={"item_name": "Item", "category_name": "Category", "period_name": "Period", "selling_price": "Price",
                                           "portion_weight_kg": "Portion kg", "portion_weight_source": "Weight source", "est_cost_per_portion": "Est. cost",
                                           "rounding_step": "Rounding step", "is_active": "Active"}).drop(columns=["item_id", "period_id"]),
                     hide_index=True, use_container_width=True)
        if not can:
            st.info("Only managers and administrators can change the menu.")
        else:
            mode = st.radio("Action", ["Add item", "Edit item", "Activate / deactivate"], horizontal=True)
            sel = None
            if mode != "Add item":
                sel = st.selectbox("Item", items["item_id"], format_func=lambda i: items.set_index("item_id").loc[i, "item_name"])
            if mode == "Activate / deactivate" and sel:
                active = bool(items.set_index("item_id").loc[sel, "is_active"])
                if st.button("Deactivate" if active else "Activate"):
                    with ui.guarded("Updated."):
                        ms.set_active(user, int(sel), not active)
            else:
                cur = items.set_index("item_id").loc[sel] if sel else None
                with st.form("item_form"):
                    n = st.text_input("Item name", value=cur["item_name"] if cur is not None else "")
                    c1, c2, c3 = st.columns(3)
                    cat = c1.selectbox("Category", cats["category_id"], format_func=lambda i: cats.set_index("category_id").loc[i, "category_name"])
                    per = c2.selectbox("Service period", pers["period_id"], format_func=lambda i: pers.set_index("period_id").loc[i, "period_name"])
                    pr = c3.number_input("Selling price", min_value=0.0, value=float(cur["selling_price"]) if cur is not None else 0.0, step=1.0)
                    c4, c5, c6 = st.columns(3)
                    pw = c4.number_input("Portion weight (kg)", min_value=0.0, value=float(cur["portion_weight_kg"]) if cur is not None else 0.0, step=0.01, format="%.3f")
                    est = c5.number_input("Estimated cost / portion (used if no recipe)", min_value=0.0, value=0.0, step=1.0)
                    stp = c6.number_input("Rounding step (portions)", min_value=1, value=int(cur["rounding_step"]) if cur is not None else 5)
                    src = st.text_input("Source of portion weight (e.g. 'weighed 10 servings on 3 Oct')", value=cur["portion_weight_source"] if cur is not None else "")
                    go = st.form_submit_button("Save item", type="primary")
                if go:
                    with ui.guarded("Item saved."):
                        ms.save_item(user, n, cat, per, pr, pw, src, est or None, stp, int(sel) if sel else None)
    with t2:
        if items.empty:
            ui.empty("No menu items yet.")
        else:
            iid = st.selectbox("Menu item", items["item_id"], format_func=lambda i: items.set_index("item_id").loc[i, "item_name"], key="rcp_item")
            rcp = ms.recipe(int(iid))
            if rcp.empty:
                ui.empty("No recipe yet: production cost will use the estimated cost on the item, or a manual cost per batch.")
            else:
                st.dataframe(rcp.drop(columns=["ingredient_id"]).rename(columns={"ingredient_name": "Ingredient", "unit_code": "Unit", "qty_per_portion": "Qty / portion",
                                                                                   "cost_per_unit": "Cost / unit", "cost_per_portion": "Cost / portion"}).round(4), hide_index=True, use_container_width=True)
                st.markdown(f"**Recipe cost per portion: {common.settings()['currency']}{rcp['cost_per_portion'].sum():.2f}** (sum of quantity × latest ingredient cost; estimate)")
            if can:
                ing = inv.ingredients()
                with st.form("rcp_form", clear_on_submit=True):
                    g = st.selectbox("Ingredient", ing["ingredient_id"], format_func=lambda i: ing.set_index("ingredient_id").loc[i, "ingredient_name"])
                    q = st.number_input("Quantity per portion (in the ingredient's unit)", min_value=0.0, value=0.0, step=0.005, format="%.4f")
                    go = st.form_submit_button("Add / update line")
                if go:
                    with ui.guarded("Recipe line saved."):
                        ms.set_recipe_line(user, int(iid), int(g), q)
                if not rcp.empty:
                    rm = st.selectbox("Remove ingredient", rcp["ingredient_id"], format_func=lambda i: rcp.set_index("ingredient_id").loc[i, "ingredient_name"], key="rm_ing")
                    if st.button("Remove line"):
                        with ui.guarded("Removed."):
                            ms.remove_recipe_line(user, int(iid), int(rm))
    with t3:
        if items.empty:
            ui.empty("No menu items yet.")
        else:
            iid = st.selectbox("Menu item", items["item_id"], format_func=lambda i: items.set_index("item_id").loc[i, "item_name"], key="hist2")
            h = ms.item_history(int(iid))
            if h.empty:
                ui.empty("No history for this item.")
            else:
                st.dataframe(h[["operating_date", "prepared_portions", "served_portions", "expected_leftover_portions", "discarded_portions_est", "discarded_cost_est", "revenue", "recon_status"]].round(2).sort_values("operating_date", ascending=False),
                             hide_index=True, use_container_width=True, height=380)
