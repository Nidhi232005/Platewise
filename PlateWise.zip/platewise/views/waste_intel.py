"""Page 6: Waste Intelligence."""
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from analytics import cost_analysis as ca
from analytics import metrics
from core import ui
from services import common


def render(user, op_date):
    d = common.daily_summary()
    if d.empty:
        ui.empty("No operational records yet. Waste analytics appear after batches, service and weighings are recorded.")
        return
    cur = common.settings()["currency"]
    d["operating_date"] = pd.to_datetime(d["operating_date"])
    t1, t2, t3, t4, t5 = st.tabs(["Trends", "Items & cost", "Repeated overproduction", "Reconciliation", "Before / after"])
    with t1:
        g = d.groupby(pd.Grouper(key="operating_date", freq="W")).agg(prep=("prepared_portions", "sum"), disc=("discarded_portions_est", "sum"),
                                                                       cost=("discarded_cost_est", "sum"), don=("donated_portions_est", "sum")).reset_index()
        g["Waste %"] = g["disc"] / g["prep"] * 100
        fig = go.Figure()
        fig.add_bar(x=g["operating_date"], y=g["cost"], name=f"Waste cost ({cur.strip()}, est.)", marker_color=ui.LIGHTBLUE, yaxis="y")
        fig.add_scatter(x=g["operating_date"], y=g["Waste %"], name="Waste %", line=dict(color=ui.VIOLET), yaxis="y2")
        fig.update_layout(title="Weekly waste cost and waste % (estimates)", yaxis2=dict(overlaying="y", side="right", title="%"), yaxis=dict(title="Cost"))
        st.plotly_chart(ui.style_fig(fig, 340), use_container_width=True)
        cat = d.groupby([pd.Grouper(key="operating_date", freq="W"), "category_name"]).agg(disc=("discarded_portions_est", "sum")).reset_index()
        fig2 = px.area(cat, x="operating_date", y="disc", color="category_name", title="Discarded portions by category (estimate)")
        st.plotly_chart(ui.style_fig(fig2, 300), use_container_width=True)
    with t2:
        it = d.groupby("item_name").agg(prep=("prepared_portions", "sum"), served=("served_portions", "sum"), disc=("discarded_portions_est", "sum"),
                                        kg=("discarded_kg", "sum"), cost=("discarded_cost_est", "sum"), avoid=("avoidable_cost_est", "sum"), don=("donated_portions_est", "sum")).reset_index()
        it["Waste %"] = it["disc"] / it["prep"] * 100
        a, b = st.columns(2)
        f = px.bar(it.sort_values("cost"), x="cost", y="item_name", orientation="h", title=f"Estimated waste cost by item ({cur.strip()})")
        f.update_traces(marker_color=ui.VIOLET)
        a.plotly_chart(ui.style_fig(f), use_container_width=True)
        f2 = px.bar(it.sort_values("Waste %"), x="Waste %", y="item_name", orientation="h", title="Waste % by item")
        f2.update_traces(marker_color=ui.NAVY)
        b.plotly_chart(ui.style_fig(f2), use_container_width=True)
        cb = ca.cost_breakdown(d)
        ui.kpi_row([("Production cost", f"{cur}{cb['production_cost']:,.0f}", "", "estimate"), ("Waste cost", f"{cur}{cb['waste_cost']:,.0f}", "", "estimate"),
                    ("Avoidable (edible)", f"{cur}{cb['avoidable_cost']:,.0f}", "", "edible when discarded"), ("Donated value", f"{cur}{cb['donated_value']:,.0f}", "", "at cost, estimate"),
                    ("Foregone revenue", f"{cur}{cb['foregone_revenue']:,.0f}", "", "opportunity, not a cash loss")])
        st.dataframe(it.rename(columns={"item_name": "Item", "prep": "Prepared", "served": "Served", "disc": "Discarded (est. portions)", "kg": "Discarded kg (measured)",
                                        "cost": "Waste cost (est.)", "avoid": "Avoidable cost (est.)", "don": "Donated (est. portions)"}).round(2), hide_index=True, use_container_width=True)
    with t3:
        d["surplus_pct"] = (d["prepared_portions"] - d["served_portions"]) / d["prepared_portions"] * 100
        d["over"] = d["surplus_pct"] > 10
        r = d.groupby("item_name").agg(days=("over", "size"), over_days=("over", "sum"), avg_surplus=("surplus_pct", "mean"), sold_out=("sold_out_flag", "sum")).reset_index()
        r["Share of days with >10% surplus"] = (r["over_days"] / r["days"] * 100).round(0)
        st.dataframe(r.rename(columns={"item_name": "Item", "days": "Days", "over_days": "Days >10% surplus", "avg_surplus": "Avg surplus %", "sold_out": "Sold-out days"}).round(1).sort_values("Share of days with >10% surplus", ascending=False),
                     hide_index=True, use_container_width=True)
        d["Weekday"] = d["operating_date"].dt.day_name().str[:3]
        hm = d.pivot_table(index="item_name", columns="Weekday", values="surplus_pct", aggfunc="mean").reindex(columns=["Mon", "Tue", "Wed", "Thu", "Fri", "Sat"])
        fig = px.imshow(hm, text_auto=".0f", color_continuous_scale=["#FFFFFF", ui.LIGHTBLUE, ui.VIOLET], aspect="auto", title="Average surplus % by item and weekday")
        st.plotly_chart(ui.style_fig(fig, 340), use_container_width=True)
        ui.note("Items with a high share of surplus days AND few sold-out days are the safest candidates for smaller preparation quantities.")
    with t4:
        ex = d[d["recon_status"].isin(["unexplained_loss", "over_measured", "invalid_counts", "not_weighed"])]
        s = d["recon_status"].value_counts().rename_axis("Status").reset_index(name="Item-days")
        a, b = st.columns([1, 2])
        a.dataframe(s, hide_index=True, use_container_width=True)
        if ex.empty:
            b.markdown("✓ No reconciliation exceptions.")
        else:
            t = ex.sort_values("operating_date", ascending=False)[["operating_date", "item_name", "prepared_portions", "served_portions", "expected_leftover_portions",
                                                                    "measured_portions_est", "unexplained_portions_est", "recon_status"]].head(60).copy()
            t[["measured_portions_est", "unexplained_portions_est"]] = t[["measured_portions_est", "unexplained_portions_est"]].round(1)
            b.dataframe(t, hide_index=True, use_container_width=True, height=330)
    with t5:
        ui.note("Descriptive comparison of the same item before and after a chosen date. Demand, menu and weather also change, so this is not proof of cause.")
        items = ["All items"] + sorted(d["item_name"].unique())
        c1, c2, c3 = st.columns(3)
        sel = c1.selectbox("Item", items)
        dmin, dmax = d["operating_date"].min().date(), d["operating_date"].max().date()
        change = c2.date_input("Change date", value=min(max(dmax - pd.Timedelta(days=28).to_pytimedelta(), dmin), dmax), min_value=dmin, max_value=dmax)
        win = c3.slider("Window (days each side)", 7, 42, 21)
        iid = None if sel == "All items" else int(d.loc[d["item_name"] == sel, "item_id"].iloc[0])
        out = ca.before_after(d, iid, change, win)
        b, a = out["before"], out["after"]
        if b["days"] == 0 or a["days"] == 0:
            ui.empty("Not enough records on one side of this date.")
        else:
            ui.kpi_row([("Waste % before", f"{b['waste_pct']:.1f}", "%", f"{b['days']} item-days"), ("Waste % after", f"{a['waste_pct']:.1f}", "%", f"{a['days']} item-days"),
                        ("Sold-out days before", f"{b['shortage_rate']:.0f}", "%", ""), ("Sold-out days after", f"{a['shortage_rate']:.0f}", "%", ""),
                        ("Avoidable cost change", f"{cur}{a['avoidable_cost'] - b['avoidable_cost']:,.0f}", "", "after − before (est.)")])
            ui.note("Lower waste with MORE sold-out days is a trade-off, not a pure improvement.")
