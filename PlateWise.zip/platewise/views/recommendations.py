"""Recommendation review: advisory rules with evidence, manager decision and measured result."""
import json

import pandas as pd
import streamlit as st

from core import security, ui
from services import recommendation_service as rec

RULE = {"repeated_surplus": "Repeated surplus", "repeated_shortage": "Repeated shortage", "variable_demand": "Variable demand",
        "unexplained_discrepancy": "Unexplained discrepancy", "donation_opportunity": "Donation opportunity", "ingredient_spoilage": "Ingredient spoilage"}


def render(user, op_date):
    c1, c2 = st.columns([1, 3])
    if c1.button("Run decision rules", type="primary", disabled=not security.can(user, "forecast.run")):
        with ui.guarded():
            st.success(f"{rec.generate(user, op_date)} new recommendation(s) added.")
    c2.caption("Rules look at the last 21 days up to the selected date. They never suggest cutting production for an item that already sells out often.")
    status = st.radio("Show", ["open", "approved", "implemented", "rejected", "closed", "all"], horizontal=True)
    df = rec.listing(None if status == "all" else status)
    if df.empty:
        ui.empty("No recommendations with this status.")
        return
    for r in df.itertuples():
        with st.expander(f"#{r.adv_id} · {RULE.get(r.rule_code, r.rule_code)} · {r.subject or 'Store'} · confidence {r.confidence}"):
            st.markdown(f"**Problem:** {r.problem}")
            st.markdown(f"**Proposed action:** {r.proposed_action}")
            st.markdown(f"**Expected benefit:** {r.expected_benefit}")
            st.caption(f"Limitations: {r.limitations}")
            try:
                m = json.loads(r.metrics_json or "{}")
                st.caption("Evidence: " + ", ".join(f"{k} = {round(v, 2) if isinstance(v, float) else v}" for k, v in m.items()))
            except ValueError:
                pass
            st.caption(f"Generated {r.generated_on} · status **{r.status}**" + (f" · implemented {r.implemented_on}" if pd.notna(r.implemented_on) else ""))
            if r.status == "implemented":
                out = rec.measured_outcome(int(r.adv_id))
                if out:
                    b, a = out["before"], out["after"]
                    st.markdown(f"**Measured result (21 days before vs after, descriptive only):** waste {b['waste_pct']:.1f}% → {a['waste_pct']:.1f}% "
                                f"({out['waste_pct_change']:+.1f} pts) · sold-out days {b['shortage_rate']:.0f}% → {a['shortage_rate']:.0f}% ({out['shortage_rate_change']:+.0f} pts) "
                                f"· sample {b['days']} vs {a['days']} days")
                    ui.note("Other factors (demand, weather, exams) also changed, so this does not prove the recommendation caused the difference.")
            if security.can(user, "recommendations.review") and r.status in ("open", "approved"):
                note = st.text_input("Note (required to reject)", key=f"note_{r.adv_id}")
                a, b, c = st.columns(3)
                if r.status == "open" and a.button("Approve", key=f"ap_{r.adv_id}"):
                    with ui.guarded("Approved."):
                        rec.review(user, int(r.adv_id), "approved", note)
                if r.status == "open" and b.button("Reject", key=f"rj_{r.adv_id}"):
                    with ui.guarded("Rejected."):
                        rec.review(user, int(r.adv_id), "rejected", note)
                if r.status == "approved":
                    d = a.date_input("Implemented on", value=op_date, key=f"d_{r.adv_id}")
                    if b.button("Mark implemented", key=f"im_{r.adv_id}"):
                        with ui.guarded("Marked as implemented."):
                            rec.review(user, int(r.adv_id), "implemented", note, d)
