"""Page 4: Waste Measurement Desk (Zones C and D)."""
from datetime import datetime

import streamlit as st

from analytics.metrics import kg_to_portions, to_kg
from core import security, ui
from services import common, waste_service as ws

LABELS = {"overproduction": "Overproduction", "low_demand": "Lower demand than expected", "quality_issue": "Quality issue",
          "spillage": "Spillage", "plate_return": "Returned on plates", "other": "Other"}
STATUS = {"balanced": "Balanced", "not_weighed": "Leftover not weighed", "unexplained_loss": "Less weighed than expected (unexplained loss)",
          "over_measured": "More weighed than expected", "invalid_counts": "Served exceeds prepared (data error)", "no_batch": "No batch"}


def _recon_box(r: dict):
    if r.get("status") in (None, "no_batch"):
        return
    ok = r["status"] == "balanced"
    sym = "✓" if ok else "▲"
    st.markdown(f"**{sym} Reconciliation: {STATUS.get(r['status'], r['status'])}**")
    c = st.columns(5)
    c[0].metric("Prepared", r["prepared"])
    c[1].metric("Served", r["served"])
    c[2].metric("Expected leftover", r["expected_leftover"], help="prepared − served (counted)")
    c[3].metric("Measured leftover (est.)", f"{r['measured_portions_est']:.1f}" if r["measured_portions_est"] is not None else "–", help="weighed kg ÷ portion weight (estimate)")
    c[4].metric("Unexplained", f"{r['unexplained_portions_est']:+.1f}" if r["unexplained_portions_est"] is not None else "–", help=f"tolerance ±{r['tolerance_portions']}")
    if r.get("disposition_status") == "pending_disposition":
        st.warning("Part of the weighed food has no decision yet (donate / discard / retain).")


def render(user, op_date):
    can_write = security.can(user, "waste.write")
    d = common.daily_summary(op_date, op_date)
    left, right = st.columns([1.15, 1], gap="large")
    with left:
        ui.section("Weigh leftovers (manual scale entry)")
        if not can_write:
            st.info("Your role can view but not record weighings.")
        elif d.empty:
            ui.empty("No batches were prepared on this date, so there is nothing to weigh.")
        else:
            items = d.set_index("item_id")
            iid = st.selectbox("Menu item", list(items.index), format_func=lambda i: items.loc[i, "item_name"], key="wd_item")
            r = items.loc[iid]
            pw = float(r["portion_weight_kg"])
            st.caption(f"Prepared {int(r['prepared_portions'])} · served {int(r['served_portions'])} · expected leftover {int(r['expected_leftover_portions'])} portions "
                       f"· conversion: 1 portion = {pw:.3f} kg")
            scales = common.stations("scale")
            c1, c2, c3 = st.columns([1.2, 1, 1.2])
            scale = c1.selectbox("Weighing station", scales["station_id"], format_func=lambda i: f"{scales.set_index('station_id').loc[i, 'station_code']}")
            val = c2.number_input("Measured weight", min_value=0.0, value=0.0, step=0.1, format="%.3f")
            unit = c3.selectbox("Unit", ["kg", "g"])
            c4, c5 = st.columns(2)
            cond = c4.selectbox("Food condition", ["edible", "not_edible"], format_func=lambda x: "Edible" if x == "edible" else "Not edible (must be discarded)")
            reason = c5.selectbox("Reason for surplus / disposal", list(LABELS), format_func=LABELS.get)
            kg = to_kg(val, unit) if val else 0.0
            if kg:
                st.markdown(f"**Calculated:** {kg:.3f} kg ≈ **{kg_to_portions(kg, pw):.1f} portions** (estimate)")
            ui.section("What happens to this food?")
            dc, dd, dr = st.columns(3)
            don = dc.number_input("Donated (kg)", min_value=0.0, value=0.0, step=0.1, format="%.3f", disabled=(cond == "not_edible"))
            ret = dr.number_input("Retained safely (kg)", min_value=0.0, value=0.0, step=0.1, format="%.3f", disabled=(cond == "not_edible"))
            oth = st.number_input("Other loss (kg)", min_value=0.0, value=0.0, step=0.1, format="%.3f")
            rest_to_disc = st.checkbox("Discard the remainder", value=True)
            disc = max(kg - don - ret - oth, 0.0) if rest_to_disc else dd.number_input("Discarded (kg)", min_value=0.0, value=0.0, step=0.1, format="%.3f")
            if rest_to_disc:
                dd.markdown(f"Discarded (kg)<br><b>{disc:.3f}</b>", unsafe_allow_html=True)
            alloc = don + disc + ret + oth
            if kg:
                st.caption(f"Allocated {alloc:.3f} of {kg:.3f} kg" + (" ✓" if abs(alloc - kg) < 0.0015 else " (the rest stays pending)"))
            recipient, safe = "", False
            if don > 0:
                a, b = st.columns(2)
                recipient = a.text_input("Donation recipient")
                safe = b.checkbox("Food-safety check passed (temperature, time, packaging)")
            reason_txt = st.text_input("Disposition note (optional)")
            note = st.text_input("Weighing note (optional)")
            if st.button("Save weighing", type="primary", disabled=(kg <= 0)):
                with ui.guarded():
                    disps = []
                    for typ, w in [("donated", don), ("discarded", disc), ("retained", ret), ("other_loss", oth)]:
                        if w > 0:
                            e = {"type": typ, "weight_kg": round(w, 3), "reason": reason_txt}
                            if typ == "donated":
                                e["donation"] = {"recipient_name": recipient, "food_safety_checked": safe}
                            disps.append(e)
                    res = ws.record_weighing(user, op_date, int(iid), int(scale), val, unit, cond, reason, disps, datetime.now(), note)
                    st.success(f"Saved: {res['weight_kg']} kg ≈ {res['portions_est']} portions (estimate).")
                    _recon_box(res["reconciliation"])
            else:
                _recon_box(ws.item_reconciliation(op_date, int(iid)))
    with right:
        ui.section("Weighings today")
        wl = ws.weighing_log(op_date)
        if wl.empty:
            ui.empty("No weighings for this date.")
        else:
            st.dataframe(wl.drop(columns=["unit_code"]).rename(columns={"weighed_at": "Time", "item_name": "Item", "scale_id": "Scale", "weight_value": "Entered",
                                                                       "weight_kg": "Kg", "food_condition": "Condition", "reason_code": "Reason", "donated_kg": "Donated",
                                                                       "discarded_kg": "Discarded", "retained_kg": "Retained", "other_loss_kg": "Other"}),
                         hide_index=True, use_container_width=True, height=260)
        ui.section("Awaiting a decision")
        pend = ws.pending_dispositions()
        if pend.empty:
            st.markdown("✓ Every weighed quantity has been allocated.")
        else:
            st.dataframe(pend, hide_index=True, use_container_width=True, height=160)
            if can_write:
                with st.form("pending_form"):
                    wid = st.selectbox("Weighing", pend["weigh_id"], format_func=lambda i: f"#{i} · {pend.set_index('weigh_id').loc[i, 'item_name']} · {pend.set_index('weigh_id').loc[i, 'unallocated_kg']:.2f} kg left")
                    typ = st.selectbox("Decision", ws.DISPOSITIONS)
                    kgp = st.number_input("Weight (kg)", min_value=0.0, value=0.0, step=0.1, format="%.3f")
                    rn = st.text_input("Recipient (donations only)")
                    sf = st.checkbox("Food-safety check passed (donations only)")
                    go = st.form_submit_button("Record decision")
                if go:
                    with ui.guarded("Decision recorded."):
                        ws.add_disposition(user, int(wid), typ, kgp, "", {"recipient_name": rn, "food_safety_checked": sf} if typ == "donated" else None)
        ui.section("Donations")
        dn = ws.donations()
        if dn.empty:
            ui.empty("No donations recorded yet.")
        else:
            st.dataframe(dn.head(30), hide_index=True, use_container_width=True, height=240)
