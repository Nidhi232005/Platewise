"""Page 8: Reports & Exports (Excel + Tableau data sources)."""
from datetime import date, timedelta

import streamlit as st

from core import security, ui
from exports import excel_export as xl, tableau_export as tb
from services import reporting_service as rs


def render(user, op_date):
    if not security.can(user, "export"):
        st.info("You can view reports but your role cannot export data.")
    c1, c2 = st.columns(2)
    rng = c1.date_input("Period", value=(op_date - timedelta(days=89), op_date), key="exp_range")
    if not isinstance(rng, tuple) or len(rng) != 2:
        st.stop()
    start, end = rng
    tot = rs.database_totals(start, end)
    ui.section("Control totals from the MySQL base tables")
    ui.kpi_row([("Prepared", f"{tot['prepared']:,}", "portions", ""), ("Served", f"{tot['served']:,}", "portions", ""),
                ("Discarded", f"{tot['discarded_kg']:,.1f}", "kg", "measured"), ("Donated", f"{tot['donated_kg']:,.1f}", "kg", "measured")])
    if not security.can(user, "export"):
        return
    t1, t2 = st.tabs(["Excel workbook", "Tableau data sources"])
    with t1:
        st.markdown("Contains 9 pivot-ready Excel Tables, a formula summary (SUMIFS) and a PivotTable guide. "
                    "**It does not contain native PivotTable objects**; create them in Excel in under a minute using the Pivot_Guide sheet.")
        if st.button("Build Excel workbook", type="primary"):
            with ui.guarded():
                data, info = xl.build_workbook(start, end)
                chk = xl.verify_workbook(data, start, end)
                st.session_state["xlsx"] = (data, info, chk, start, end)
        if "xlsx" in st.session_state:
            data, info, chk, s, e = st.session_state["xlsx"]
            if chk.get("ok"):
                st.success("Verified: Excel totals equal the MySQL totals above.")
            else:
                st.error(f"Mismatch between Excel and MySQL: {chk.get('differences')}")
            st.json(info["rows"], expanded=False)
            st.download_button("Download PlateWise_Report.xlsx", data, f"PlateWise_Report_{s}_{e}.xlsx",
                               "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    with t2:
        st.markdown("A ZIP of CSV files (facts + item dimension + control totals). Connect Tableau Desktop to the CSVs, or directly to the MySQL views "
                    "`v_daily_item_summary`, `v_forecast_vs_actual` and `v_inventory_stock`. See `docs/tableau_guide.md`.")
        if st.button("Build Tableau data ZIP"):
            with ui.guarded():
                z, counts = tb.build_tableau_zip(start, end)
                st.session_state["tbz"] = (z, counts, start, end)
        if "tbz" in st.session_state:
            z, counts, s, e = st.session_state["tbz"]
            st.json(counts, expanded=False)
            st.download_button("Download tableau_data.zip", z, f"PlateWise_Tableau_{s}_{e}.zip", "application/zip")
        ui.note("No Tableau workbook (.twbx) is included: dashboards must be built in Tableau Desktop following docs/tableau_guide.md.")
