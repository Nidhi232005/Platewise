"""Page 1: Operations Overview (day KPIs, operations timeline, period analysis)."""
from datetime import timedelta

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from analytics import metrics
from core import database as db
from core import ui
from services import common, forecast_service, inventory_service, recommendation_service


def _timeline(op_date):
    q = {"Preparation": ("prep_batches", "prepared_at", "operating_date"), "Service": ("service_records", "served_at", "operating_date"),
         "Weighing": ("weighing_records", "weighed_at", "operating_date")}
    rows = []
    for phase, (tbl, col, dcol) in q.items():
        r = db.query_df(f"SELECT MIN({col}) AS a, MAX({col}) AS b, COUNT(*) AS n FROM {tbl} WHERE {dcol}=:d", {"d": op_date}).iloc[0]
        if r["n"] and not pd.isna(r["a"]):
            rows.append((phase, r["a"], r["b"], int(r["n"])))
    r = db.query_df("SELECT MIN(d.decided_at) AS a, MAX(d.decided_at) AS b, COUNT(*) AS n FROM waste_dispositions d "
                    "JOIN weighing_records w ON w.weigh_id=d.weigh_id WHERE w.operating_date=:d", {"d": op_date}).iloc[0]
    if r["n"] and not pd.isna(r["a"]):
        rows.append(("Surplus handling", r["a"], r["b"], int(r["n"])))
    if not rows:
        ui.empty("No activity recorded for this date yet. Start in the Batch Preparation Board.")
        return
    df = pd.DataFrame(rows, columns=["Phase", "Start", "Finish", "Records"])
    df["Start"], df["Finish"] = pd.to_datetime(df["Start"]), pd.to_datetime(df["Finish"])
    df["Finish"] = df.apply(lambda r: r["Finish"] + timedelta(minutes=20) if r["Finish"] - r["Start"] < timedelta(minutes=20) else r["Finish"], axis=1)
    fig = px.timeline(df, x_start="Start", x_end="Finish", y="Phase", color="Phase", text="Records",
                      category_orders={"Phase": ["Preparation", "Service", "Weighing", "Surplus handling"]},
                      color_discrete_sequence=[ui.VIOLET, "#7FA9D1", ui.NAVY, ui.PERI])
    fig.update_yaxes(autorange="reversed", title=None)
    fig.update_traces(textposition="inside", texttemplate="%{text} records")
    fig.update_layout(showlegend=False)
    st.plotly_chart(ui.style_fig(fig, 230), use_container_width=True)


def render(user, op_date):
    st_ = common.settings()
    cur = st_["currency"]
    d = common.daily_summary(op_date, op_date)
    s = metrics.summarize(d)
    edible_kg = float(d["edible_kg"].sum()) if not d.empty else 0.0
    ui.section(f"Today on the floor ({op_date:%d %b %Y})")
    ui.kpi_row([("Food prepared", f"{s['prepared']:,}", "portions", "counted"), ("Food served", f"{s['served']:,}", "portions", "counted"),
                ("Edible surplus", f"{edible_kg:.1f}", "kg", "measured on scale"),
                ("Food discarded", f"{s['discarded_kg']:.1f}", "kg", f"≈ {s['discarded_portions']:.0f} portions (estimate)"),
                ("Donations completed", f"{s['donated_kg']:.1f}", "kg", f"≈ {s['donated_portions']:.0f} portions (estimate)"),
                ("Est. waste cost", f"{cur}{s['waste_cost']:,.0f}", "", "production cost, estimate")])
    nxt = forecast_service.next_operating_day(op_date, st_["operating_days"])
    plan = forecast_service.pending_for(nxt)
    ui.section(f"Forecast for the next operating day ({nxt:%a %d %b})")
    if plan.empty:
        ui.empty("No forecast generated yet. Open the Demand Planning Studio to create one.")
    else:
        tot = plan["recommended_qty"].fillna(0).sum()
        a, b = st.columns([1, 3])
        a.markdown(ui.kpi("Recommended total", f"{int(tot):,}", "portions", f"{(plan['status'].isin(['approved', 'adjusted'])).sum()} of {len(plan)} approved"), unsafe_allow_html=True)
        b.dataframe(plan[["item_name", "period_name", "predicted_demand", "recommended_qty", "status"]].rename(columns={
            "item_name": "Item", "period_name": "Period", "predicted_demand": "Predicted demand", "recommended_qty": "Recommended", "status": "Status"}),
            hide_index=True, use_container_width=True, height=min(35 * len(plan) + 38, 320))
    ui.section("Operations timeline")
    _timeline(op_date)
    ui.section("Period analysis")
    c1, c2, c3 = st.columns([2, 1, 1])
    end_default = op_date
    rng = c1.date_input("Date range", value=(end_default - timedelta(days=29), end_default), key="ov_range")
    cats = ["All"] + common.items(False)["category_name"].drop_duplicates().tolist()
    cat = c2.selectbox("Category", cats, key="ov_cat")
    if not isinstance(rng, tuple) or len(rng) != 2:
        st.stop()
    p = common.daily_summary(rng[0], rng[1], cat)
    if p.empty:
        ui.empty("No records in this range and category.")
        return
    ps = metrics.summarize(p)
    n_open = len(recommendation_service.listing("open"))
    low = int(inventory_service.stock()["low_stock_flag"].sum())
    c3.markdown(ui.chip(f"{n_open} advisory items open", plain=True) + "<br>" + ui.chip(f"{low} low-stock ingredients", plain=True), unsafe_allow_html=True)
    ui.kpi_row([("Prepared", f"{ps['prepared']:,}", "portions", ""), ("Served", f"{ps['served']:,}", "portions", ""),
                ("Surplus", f"{ps['surplus']:,}", "portions", "prepared - served"), ("Waste", f"{ps['waste_pct']:.1f}", "%", "discarded / prepared"),
                ("Shortage rate", f"{ps['shortage_rate']:.1f}", "%", "item-days sold out"), ("Est. waste cost", f"{cur}{ps['waste_cost']:,.0f}", "", "estimate")])
    daily = p.groupby("operating_date").agg(prepared=("prepared_portions", "sum"), served=("served_portions", "sum"),
                                            disc=("discarded_portions_est", "sum")).reset_index()
    daily["waste_pct"] = daily["disc"] / daily["prepared"] * 100
    a, b = st.columns(2)
    fig = go.Figure()
    fig.add_bar(x=daily["operating_date"], y=daily["prepared"], name="Prepared", marker_color=ui.LIGHTBLUE)
    fig.add_bar(x=daily["operating_date"], y=daily["served"], name="Served", marker_color=ui.VIOLET)
    fig.update_layout(barmode="group", title="Prepared vs served (portions)")
    a.plotly_chart(ui.style_fig(fig), use_container_width=True)
    fig2 = px.line(daily, x="operating_date", y="waste_pct", markers=True, title="Daily waste % (estimate)")
    fig2.update_traces(line_color=ui.NAVY)
    b.plotly_chart(ui.style_fig(fig2), use_container_width=True)
    a, b = st.columns(2)
    it = p.groupby("item_name").agg(prep=("prepared_portions", "sum"), disc=("discarded_portions_est", "sum")).reset_index()
    it["Waste %"] = it["disc"] / it["prep"] * 100
    fig3 = px.bar(it.sort_values("Waste %"), x="Waste %", y="item_name", orientation="h", title="Highest-waste items (waste %, estimate)")
    fig3.update_traces(marker_color=ui.VIOLET)
    a.plotly_chart(ui.style_fig(fig3), use_container_width=True)
    b.markdown("**Recent operational records**")
    rec = p.sort_values("operating_date", ascending=False).head(8)[["operating_date", "item_name", "prepared_portions", "served_portions", "recon_status"]]
    b.dataframe(rec.rename(columns={"operating_date": "Date", "item_name": "Item", "prepared_portions": "Prepared", "served_portions": "Served", "recon_status": "Reconciliation"}),
                hide_index=True, use_container_width=True)
