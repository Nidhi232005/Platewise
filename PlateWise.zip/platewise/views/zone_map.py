"""Page 2: Canteen Floor & Zone Map - an SVG built from live data (not decorative)."""
import streamlit as st

from core import ui
from services import zone_service

NODES = {  # zone code -> (x, y, w, h)
    "A": (20, 20, 250, 170), "B": (330, 20, 250, 170), "C": (640, 20, 250, 170),
    "D": (640, 250, 250, 170), "E": (20, 250, 250, 170),
}
GOTO = {"A": "batches", "B": "service", "C": "waste", "D": "waste", "E": "inventory"}


def _svg(zones) -> str:
    e = ui.esc
    out = ['<svg viewBox="0 0 910 440" width="100%" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Canteen floor map">',
           '<defs><marker id="ar" markerUnits="userSpaceOnUse" markerWidth="12" markerHeight="10" refX="11" refY="5" orient="auto"><path d="M0,0 L12,5 L0,10 Z" fill="#14213D"/></marker></defs>',
           '<rect x="0" y="0" width="910" height="440" fill="#FFFDF7" stroke="#D9D3C0"/>']
    flows = [("A", "B", "cooked"), ("B", "C", "returns"), ("C", "D", "weighed")]
    pos = {"A": (270, 105, 330, 105), "B": (580, 105, 640, 105), "C": (765, 190, 765, 250)}
    for (a, b, lab), key in zip(flows, ["A", "B", "C"]):
        x1, y1, x2, y2 = pos[key]
        out.append(f'<line x1="{x1}" y1="{y1}" x2="{x2}" y2="{y2}" stroke="#14213D" stroke-width="2.5" marker-end="url(#ar)"/>')
        out.append(f'<text x="{(x1 + x2) / 2 + (6 if key == "C" else 0)}" y="{(y1 + y2) / 2 - (8 if key != "C" else -4)}" font-size="11" fill="#5A5A63" text-anchor="{"start" if key == "C" else "middle"}">{lab}</text>')
    out.append('<line x1="145" y1="250" x2="145" y2="190" stroke="#14213D" stroke-width="2.5" marker-end="url(#ar)" stroke-dasharray="6 4"/>')
    out.append('<text x="155" y="225" font-size="11" fill="#5A5A63">ingredients</text>')
    for i, line in enumerate(["Dashed outline = open tasks or alerts.", "Counts are live from MySQL.", "Measured = scale kg.", "Estimated = kg / portion weight."]):
        out.append(f'<text x="300" y="{300 + i * 18}" font-size="12" fill="#5A5A63">{line}</text>')
    for z in zones:
        x, y, w, h = NODES[z["code"]]
        n = len(z["alerts"])
        fill = "#E3E4F8" if z["count"] else "#FFFFFF"
        dash = ' stroke-dasharray="7 4"' if n else ""
        stroke = "#5B58C9" if n else "#14213D"
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{fill}" stroke="{stroke}" stroke-width="2.2"{dash}/>')
        out.append(f'<rect x="{x}" y="{y}" width="{w}" height="30" fill="#14213D"/>')
        out.append(f'<circle cx="{x + 17}" cy="{y + 15}" r="11" fill="#B8B5F0"/><text x="{x + 17}" y="{y + 20}" font-size="14" font-weight="700" text-anchor="middle" fill="#14213D">{z["code"]}</text>')
        out.append(f'<text x="{x + 36}" y="{y + 20}" font-size="14" font-weight="600" fill="#fff">{e(z["name"])}</text>')
        out.append(f'<text x="{x + 12}" y="{y + 52}" font-size="12.5" fill="#2B2B30">{e(z["activity"])}</text>')
        for i, (lab, val, unit) in enumerate(z["quantities"][:3]):
            out.append(f'<text x="{x + 12}" y="{y + 86 + i * 24}" font-size="12" fill="#5A5A63">{e(lab)}</text>')
            out.append(f'<text x="{x + w - 12}" y="{y + 86 + i * 24}" font-size="17" font-weight="700" fill="#14213D" text-anchor="end">{e(val)} <tspan font-size="11" font-weight="400" fill="#5A5A63">{e(unit)}</tspan></text>')
        badge = f"▲ {n} open task{'s' if n != 1 else ''}" if n else "✓ nothing pending"
        out.append(f'<text x="{x + 12}" y="{y + h - 12}" font-size="12.5" font-weight="600" fill="{"#5B58C9" if n else "#5A5A63"}">{badge}</text>')
    out.append("</svg>")
    return "".join(out)


def render(user, op_date):
    zones = zone_service.zone_status(op_date)
    if all(z["count"] == 0 and not z["alerts"] for z in zones[:4]):
        ui.empty(f"No batches have been recorded for {op_date:%d %b %Y}, so zones A to D are idle. Zone E shows live store status.")
    st.markdown(_svg(zones), unsafe_allow_html=True)
    ui.section("Inspect a zone")
    labels = {z["code"]: f"{z['code']} · {z['name']}" for z in zones}
    code = st.radio("Zone", list(labels), format_func=labels.get, horizontal=True, label_visibility="collapsed")
    z = next(x for x in zones if x["code"] == code)
    a, b = st.columns([1, 1])
    with a:
        st.markdown(f"**{z['icon']} {z['name']}** — {z['activity']}")
        for lab, val, unit in z["quantities"]:
            st.markdown(f"- {lab}: **{val} {unit}**")
        if st.button(f"Open the {z['name']} page", key=f"goto_{code}"):
            st.session_state.page = GOTO[code]
            st.rerun()
    with b:
        st.markdown("**Outstanding tasks and alerts**")
        if z["alerts"]:
            for al in z["alerts"][:12]:
                st.markdown(f"- ▲ {al}")
            if len(z["alerts"]) > 12:
                st.caption(f"... and {len(z['alerts']) - 12} more")
        else:
            st.markdown("✓ Nothing pending in this zone.")
    if not z["detail"].empty:
        st.dataframe(z["detail"], hide_index=True, use_container_width=True)
