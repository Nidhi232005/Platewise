"""Page 5: Demand Planning Studio."""
from datetime import date

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from analytics import forecasting as fc
from core import security, ui
from services import common, forecast_service as fs

WD = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]


def _plan_tab(user, op_date):
    st_ = common.settings()
    default = op_date if op_date >= date.today() and op_date.weekday() in st_["operating_days"] else fs.next_operating_day(max(op_date, date.today() - pd.Timedelta(days=1).to_pytimedelta()), st_["operating_days"])
    target = st.date_input("Plan for operating date", value=default, key="plan_date")
    c1, c2 = st.columns([1, 3])
    if c1.button("Generate recommendations", type="primary", disabled=not security.can(user, "forecast.run")):
        with ui.guarded():
            r = fs.run_forecast(user, target)
            st.success(f"Created {r['created']} recommendations" + (f" (kept already-approved plans for: {', '.join(r['skipped_already_approved'])})" if r["skipped_already_approved"] else "") + ".")
    c2.caption("Uses only data recorded BEFORE the planning date. Recommendations are estimates; the manager decides the final quantity.")
    plan = fs.pending_for(target)
    if plan.empty:
        ui.empty("No recommendations for this date yet. Click 'Generate recommendations'.")
        return
    view = plan.rename(columns={"item_name": "Item", "period_name": "Period", "model_used": "Model", "predicted_demand": "Predicted demand",
                                "recommended_qty": "Recommended", "approved_qty": "Approved", "status": "Status", "history_points": "History days",
                                "mae_selected": "Backtest MAE", "expected_footfall": "Expected footfall"})
    st.dataframe(view[["Item", "Period", "Model", "Predicted demand", "Recommended", "Approved", "Status", "History days", "Backtest MAE", "Expected footfall"]],
                 hide_index=True, use_container_width=True)
    ui.section("Why this quantity?")
    for r in plan.itertuples():
        with st.expander(f"{r.item_name}: recommended {'-' if pd.isna(r.recommended_qty) else int(r.recommended_qty)} portions · {r.status}"):
            st.write(r.explanation)
    ui.section("Manager review: approve, adjust or reject")
    if not security.can(user, "forecast.review"):
        st.info("Only managers and administrators can approve plans.")
        return
    open_ = plan[plan["status"].isin(["pending", "insufficient_data"])]
    if open_.empty:
        st.markdown("✓ All recommendations for this date have been reviewed.")
        return
    rid = st.selectbox("Item", open_["rec_id"], format_func=lambda i: open_.set_index("rec_id").loc[i, "item_name"])
    row = open_.set_index("rec_id").loc[rid]
    base_q = 0 if pd.isna(row["recommended_qty"]) else int(row["recommended_qty"])
    qty = st.number_input("Quantity to prepare (portions)", min_value=0, max_value=5000, value=base_q, step=5, key=f"q_{rid}")
    note = st.text_input("Reason (required to adjust or reject)", key=f"n_{rid}")
    a, b, c = st.columns(3)
    if a.button("Approve as recommended", disabled=pd.isna(row["recommended_qty"])):
        with ui.guarded("Approved."):
            fs.review(user, int(rid), "approve", note=note)
    if b.button("Approve my adjusted quantity"):
        with ui.guarded("Adjusted quantity approved."):
            fs.review(user, int(rid), "adjust", qty, note)
    if c.button("Reject"):
        with ui.guarded("Rejected."):
            fs.review(user, int(rid), "reject", note=note)


def _history_tab():
    items = common.items(False)
    iid = st.selectbox("Menu item", items["item_id"], format_func=lambda i: items.set_index("item_id").loc[i, "item_name"], key="hist_item")
    h = common.daily_summary(item_id=int(iid))
    if h.empty:
        ui.empty("No history for this item yet.")
        return
    h["wd"] = pd.to_datetime(h["operating_date"]).dt.weekday
    a, b = st.columns(2)
    wd = h.groupby("wd").agg(avg_served=("served_portions", "mean"), avg_prep=("prepared_portions", "mean")).reset_index()
    wd["Weekday"] = wd["wd"].map(lambda x: WD[x])
    fig = go.Figure()
    fig.add_bar(x=wd["Weekday"], y=wd["avg_prep"], name="Avg prepared", marker_color=ui.LIGHTBLUE)
    fig.add_bar(x=wd["Weekday"], y=wd["avg_served"], name="Avg served", marker_color=ui.VIOLET)
    fig.update_layout(barmode="group", title="Weekday demand pattern (portions)")
    a.plotly_chart(ui.style_fig(fig), use_container_width=True)
    fig2 = px.line(h, x="operating_date", y="served_portions", markers=True, title="Historical servings (portions)")
    fig2.update_traces(line_color=ui.NAVY)
    so = h[h["sold_out_flag"] > 0]
    fig2.add_scatter(x=so["operating_date"], y=so["served_portions"], mode="markers", name="Sold out", marker=dict(color=ui.VIOLET, size=9, symbol="diamond"))
    b.plotly_chart(ui.style_fig(fig2), use_container_width=True)
    ui.note("Diamonds mark sold-out days: observed servings understate real demand on those days.")


def _fva_tab(user):
    items = common.items(False)
    iid = st.selectbox("Menu item", items["item_id"], format_func=lambda i: items.set_index("item_id").loc[i, "item_name"], key="fva_item")
    if st.button("Evaluate outcomes for recorded days", disabled=not security.can(user, "forecast.run")):
        with ui.guarded():
            st.success(f"Evaluated {fs.evaluate_outcomes()} recommendation outcome(s).")
    s = fs.series_for_item(int(iid))
    if s.empty:
        ui.empty("No evaluated forecasts for this item yet. They appear after a planned day has batches and service records.")
    else:
        fig = go.Figure()
        fig.add_scatter(x=s["target_date"], y=s["actual_demand_est"], name="Actual demand (est.)", line=dict(color=ui.NAVY))
        fig.add_scatter(x=s["target_date"], y=s["predicted_demand"], name="Forecast", line=dict(color=ui.VIOLET, dash="dot"))
        fig.add_scatter(x=s["target_date"], y=s["prepared_qty"], name="Prepared", line=dict(color="#7FA9D1"))
        fig.update_layout(title="Forecast vs actual vs prepared (portions)")
        st.plotly_chart(ui.style_fig(fig, 340), use_container_width=True)
    ui.section("Forecast accuracy by item")
    acc = fs.accuracy_summary()
    if acc.empty:
        ui.empty("No accuracy data yet.")
    else:
        st.dataframe(acc.rename(columns={"item_name": "Item", "forecasts": "Forecasts", "mae": "MAE (portions)", "bias": "Bias (forecast − actual)", "avg_actual": "Avg actual"}).round(2),
                     hide_index=True, use_container_width=True)
        ui.note("MAE = mean absolute error. Bias > 0 means the forecast was too high on average.")


def _model_tab():
    items = common.items()
    iid = st.selectbox("Menu item", items["item_id"], format_func=lambda i: items.set_index("item_id").loc[i, "item_name"], key="mc_item")
    st_ = common.settings()
    hist = fc.prepare_history(fs.history_for_item(int(iid), date.today() + pd.Timedelta(days=1).to_pytimedelta()), st_["sold_out_uplift"])
    if len(hist) < st_["min_obs"]:
        ui.empty(f"Only {len(hist)} days of history (need {st_['min_obs']}).")
        return
    cfg = {**common.forecast_cfg(st_), "rounding_step": int(items.set_index("item_id").loc[iid, "rounding_step"])}
    sc = fc.backtest(hist, cfg)
    rows = [{"Model": m, "Test days": s["n"], "MAE": s.get("mae"), "RMSE": s.get("rmse"), "Baseline MAE (same days)": s.get("baseline_mae", s.get("mae"))} for m, s in sc.items()]
    st.dataframe(pd.DataFrame(rows).round(2), hide_index=True, use_container_width=True)
    chosen = fc.select_model(sc, st_["improvement_threshold"])
    st.markdown(f"**Model that would be used: `{chosen}`.** A model replaces the simple baseline only if its MAE is at least "
                f"{st_['improvement_threshold'] * 100:.0f}% lower on the same chronological test days (walk-forward: each day is predicted using earlier days only).")


def render(user, op_date):
    t1, t2, t3, t4 = st.tabs(["Plan a day", "Demand history", "Forecast vs actual", "Model check"])
    with t1:
        _plan_tab(user, op_date)
    with t2:
        _history_tab()
    with t3:
        _fva_tab(user)
    with t4:
        _model_tab()
