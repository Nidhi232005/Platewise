"""SQL-based reports: each named query from sql/analytical_queries.sql."""
import streamlit as st

from core import ui
from services import reporting_service as rs


def render(user, op_date):
    q = rs.named_queries()
    key = st.selectbox("Report", list(q), format_func=lambda k: q[k]["title"])
    st.markdown(f"**{q[key]['title']}**")
    st.code(q[key]["sql"], language="sql")
    df = rs.run_named_query(key)
    if df.empty:
        ui.empty("This query returned no rows for the current data.")
    else:
        st.dataframe(df, hide_index=True, use_container_width=True)
        st.download_button("Download CSV", df.to_csv(index=False).encode("utf-8"), f"{key}.csv", "text/csv")
    ui.note("Queries run read-only against the MySQL views and tables; nothing is hard-coded.")
