"""User management (administrator only)."""
import streamlit as st

from core import database as db
from core import security, ui
from core.security import ROLES


def render(user, op_date):
    security.require(user, "users.manage")
    df = db.query_df("SELECT user_id, username, full_name, role, is_active, created_at FROM users ORDER BY user_id")
    st.dataframe(df, hide_index=True, use_container_width=True)
    a, b = st.columns(2, gap="large")
    with a:
        ui.section("Create user")
        with st.form("new_user", clear_on_submit=True):
            un = st.text_input("Username")
            fn = st.text_input("Full name")
            pw = st.text_input("Temporary password", type="password")
            ro = st.selectbox("Role", ROLES)
            go = st.form_submit_button("Create", type="primary")
        if go:
            with ui.guarded("User created."):
                security.create_user(user, un, fn, pw, ro)
    with b:
        ui.section("Manage user")
        uid = st.selectbox("User", df["user_id"], format_func=lambda i: df.set_index("user_id").loc[i, "username"])
        active = bool(df.set_index("user_id").loc[uid, "is_active"])
        if st.button("Deactivate" if active else "Activate"):
            with ui.guarded("Updated."):
                security.set_user_active(user, int(uid), not active)
        np_ = st.text_input("New password", type="password", key="rp")
        if st.button("Reset password"):
            with ui.guarded("Password reset."):
                security.reset_password(user, int(uid), np_)
    ui.note("Roles: admin (everything) · manager (plans, menu, reviews, exports) · operator (daily entries) · analyst (read-only reports and exports).")
