"""Zone B: Service Counter (portions served, remaining quantity, footfall)."""
from datetime import datetime

import streamlit as st

from core import security, ui
from services import common, sales_service as sales


def render(user, op_date):
    can_write = security.can(user, "service.write")
    d = common.daily_summary(op_date, op_date)
    items = common.items()
    ui.section(f"Counter status for {op_date:%d %b %Y}")
    if d.empty:
        ui.empty("No batches exist for this date, so nothing can be served yet. Record preparation batches first.")
    else:
        t = d[["item_name", "prepared_portions", "paid_portions", "comp_portions", "served_portions", "expected_leftover_portions", "sold_out_flag"]].copy()
        t["sold_out_flag"] = t["sold_out_flag"].map({0: "", 1: "Sold out"})
        st.dataframe(t.rename(columns={"item_name": "Item", "prepared_portions": "Prepared", "paid_portions": "Paid", "comp_portions": "Complimentary",
                                       "served_portions": "Served", "expected_leftover_portions": "Remaining", "sold_out_flag": "Flag"}),
                     hide_index=True, use_container_width=True)
    a, b = st.columns(2, gap="large")
    with a:
        ui.section("Record portions served")
        if not can_write:
            st.info("Your role can view but not record service.")
        elif d.empty:
            pass
        else:
            avail = items[items["item_id"].isin(d["item_id"])]
            with st.form("service_form", clear_on_submit=True):
                it = st.selectbox("Menu item", avail["item_id"], format_func=lambda i: avail.set_index("item_id").loc[i, "item_name"])
                c1, c2 = st.columns(2)
                paid = c1.number_input("Paid portions", min_value=0, max_value=5000, value=0, step=1)
                comp = c2.number_input("Complimentary portions", min_value=0, max_value=5000, value=0, step=1, help="Free meals are counted as served but not as revenue.")
                tm = st.time_input("Time of service", value=datetime.now().time().replace(microsecond=0))
                so = st.checkbox("Item sold out after this entry")
                note = st.text_input("Note (optional)")
                go = st.form_submit_button("Save service entry", type="primary", use_container_width=True)
            if go:
                with ui.guarded():
                    per = int(avail.set_index("item_id").loc[it, "period_id"])
                    stn = int(common.stations("counter").iloc[0]["station_id"])
                    r = sales.record_service(user, op_date, it, per, stn, paid, comp, datetime.combine(op_date, tm), None, so, note)
                    st.success(f"Saved. Remaining after this entry: {r['remaining']} portions.")
    with b:
        ui.section("Footfall (approximate)")
        ui.note("Expected = known before service (used by the forecaster). Observed = counted afterwards (history only).")
        if can_write:
            pr = common.periods()
            with st.form("ff_form"):
                p = st.selectbox("Service period", pr["period_id"], format_func=lambda i: pr.set_index("period_id").loc[i, "period_name"])
                c1, c2 = st.columns(2)
                exp = c1.number_input("Expected students", min_value=0, max_value=100000, value=0, step=10)
                obs = c2.number_input("Observed students", min_value=0, max_value=100000, value=0, step=10)
                go2 = st.form_submit_button("Save footfall")
            if go2:
                with ui.guarded("Footfall saved."):
                    sales.record_footfall(user, op_date, p, obs or None, exp or None)
        ff = sales.footfall_for(op_date)
        if ff.empty:
            ui.empty("No footfall recorded for this date.")
        else:
            st.dataframe(ff.rename(columns={"period_name": "Period", "expected_count": "Expected", "observed_count": "Observed"}), hide_index=True, use_container_width=True)
    ui.section("Service log")
    log = sales.service_log(op_date)
    if log.empty:
        ui.empty("No service entries for this date.")
    else:
        st.dataframe(log, hide_index=True, use_container_width=True, height=280)
