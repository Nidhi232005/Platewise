"""Audit history."""
import streamlit as st

from core import ui
from services import audit


def render(user, op_date):
    ent = st.selectbox("Entity", ["All", "prep_batch", "service_record", "weighing", "disposition", "inventory", "menu_item",
                                  "forecast_recommendation", "forecast_run", "advisory", "user", "footfall", "supplier", "ingredient"])
    df = audit.recent(500, None if ent == "All" else ent)
    if df.empty:
        ui.empty("No audit entries for this selection.")
    else:
        st.dataframe(df, hide_index=True, use_container_width=True, height=520)
    ui.note("Every create / update / approval writes an audit row in the same database transaction as the change itself.")
