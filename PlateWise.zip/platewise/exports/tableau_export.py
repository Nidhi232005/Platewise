"""Tableau-ready CSV data sources (UTF-8). Connect Tableau Desktop via Text file, or to MySQL views directly."""
import zipfile
from io import BytesIO

import pandas as pd

from services import reporting_service as rs

FILES = {
    "fact_daily_item.csv": rs.pivot_base,
    "fact_forecast_vs_actual.csv": rs.ds_forecast_vs_actual,
    "fact_dispositions.csv": rs.ds_donations_disposition,
    "fact_ingredients_monthly.csv": rs.ds_ingredient_consumption,
    "fact_purchases.csv": rs.ds_inventory_purchases,
    "fact_footfall.csv": rs.ds_footfall,
}


def build_tableau_zip(start=None, end=None) -> tuple[bytes, dict]:
    bio = BytesIO()
    counts = {}
    with zipfile.ZipFile(bio, "w", zipfile.ZIP_DEFLATED) as z:
        for name, fn in FILES.items():
            df = fn(start, end)
            counts[name] = len(df)
            z.writestr(name, (df if df is not None else pd.DataFrame()).to_csv(index=False, date_format="%Y-%m-%d"))
        dim = rs.ds_dim_item()
        counts["dim_item.csv"] = len(dim)
        z.writestr("dim_item.csv", dim.to_csv(index=False))
        tot = rs.database_totals(start, end)
        z.writestr("control_totals.csv", pd.DataFrame([tot]).to_csv(index=False))
        z.writestr("README.txt", "PlateWise Tableau data sources. Relate fact_daily_item.Item to dim_item.item_name. "
                   "control_totals.csv holds totals from the MySQL base tables: compare with SUM() in Tableau. "
                   "Data may be SYNTHETIC. See docs/tableau_guide.md for dashboard instructions.\n")
    return bio.getvalue(), counts
