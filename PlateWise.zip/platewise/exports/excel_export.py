"""Excel workbook builder (pandas + openpyxl).

Every data sheet is an Excel TABLE (ListObject) with typed columns, ready for Insert > PivotTable.
NOTE: openpyxl cannot author native PivotTable objects, so this workbook does NOT contain ready-made PivotTables.
It contains (a) pivot-ready tables, (b) a formula-driven summary (SUMIFS, NOT a PivotTable) and (c) step-by-step
instructions on the Pivot_Guide sheet (see also docs/pivot_guide.md).
"""
from datetime import datetime
from io import BytesIO

import pandas as pd
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

from services import reporting_service as rs

NAVY, IVORY = "14213D", "FAF6EC"
SHEETS = [  # (sheet name, table name, dataset function, description)
    ("Pivot_Base", "tbl_PivotBase", rs.pivot_base, "One row per date x item. Main PivotTable source."),
    ("PrepVsServed", "tbl_PrepVsServed", rs.ds_prep_vs_served, "Preparation versus servings."),
    ("WasteByItem", "tbl_WasteByItem", rs.ds_waste_by_item, "Waste totals per menu item."),
    ("WasteByDay", "tbl_WasteByDay", rs.ds_waste_by_day, "Waste totals per operating day."),
    ("WasteCost", "tbl_WasteCost", rs.ds_waste_cost, "Estimated cost of discarded food (estimate, not selling price)."),
    ("Ingredients", "tbl_Ingredients", rs.ds_ingredient_consumption, "Ingredient purchase, use and spoilage by month."),
    ("ForecastVsActual", "tbl_ForecastVsActual", rs.ds_forecast_vs_actual, "Stored forecasts versus actual outcomes."),
    ("Donations", "tbl_Donations", rs.ds_donations_disposition, "Surplus disposition: donated / discarded / retained."),
    ("InventoryPurchases", "tbl_InventoryPurchases", rs.ds_inventory_purchases, "Purchase lines with expiry dates."),
]
DEFINITIONS = [
    ("Prepared / Served", "COUNTED portions (batches / counter records)."),
    ("Measured_*_Kg", "MEASURED on the scale (manual entry)."),
    ("*_Portions_Est", "ESTIMATE = kg / portion weight of the menu item."),
    ("Waste %", "Discarded_Portions_Est / Prepared_Portions x 100."),
    ("Surplus", "Prepared - Served (expected leftover, counted)."),
    ("Waste_Cost_Est", "Discarded portions x average batch production cost (recipe cost). NOT the selling price."),
    ("Avoidable_Cost_Est", "Part of Waste_Cost_Est that was edible when discarded."),
    ("Unexplained_Portions_Est", "Expected leftover - measured leftover portions (reconciliation gap)."),
    ("Abs_Error", "|actual demand estimate - predicted demand|; sold-out days use served x (1 + uplift)."),
]


def _write_table(ws, df: pd.DataFrame, table_name: str):
    if df is None or df.empty:
        ws["A1"] = "No data for the selected period."
        return 0
    for c, col in enumerate(df.columns, 1):
        cell = ws.cell(row=1, column=c, value=col)
        cell.font, cell.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor=NAVY)
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for r, row in enumerate(df.itertuples(index=False), 2):
        for c, v in enumerate(row, 1):
            if v is None or (isinstance(v, float) and pd.isna(v)):
                v = None
            elif hasattr(v, "item") and not isinstance(v, (str, bytes)):
                v = v.item()
            cell = ws.cell(row=r, column=c, value=v)
            col = df.columns[c - 1]
            if "Date" in col or col == "Expiry_Date":
                cell.number_format = "yyyy-mm-dd"
            elif isinstance(v, float):
                cell.number_format = "#,##0.00"
    last = f"{get_column_letter(len(df.columns))}{len(df) + 1}"
    t = Table(displayName=table_name, ref=f"A1:{last}")
    t.tableStyleInfo = TableStyleInfo(name="TableStyleMedium2", showRowStripes=True)
    ws.add_table(t)
    ws.freeze_panes = "A2"
    for c, col in enumerate(df.columns, 1):
        width = max(len(str(col)), *(len(str(x)) for x in df[col].head(200))) + 2
        ws.column_dimensions[get_column_letter(c)].width = min(max(width, 10), 38)
    ws.row_dimensions[1].height = 30
    return len(df)


def build_workbook(start=None, end=None, canteen: str = "The Daily Table - Campus Kitchen", synthetic_note: bool = True) -> tuple[bytes, dict]:
    """Return (xlsx bytes, info). info['totals'] holds column sums written to the file for verification."""
    wb = Workbook()
    ws = wb.active
    ws.title = "README"
    rows = [("PlateWise report workbook", ""), ("Canteen", canteen),
            ("Generated", datetime.now().strftime("%Y-%m-%d %H:%M")), ("Period", f"{start or 'start'} to {end or 'latest'}"),
            ("Data note", "SYNTHETIC demonstration data unless you loaded your own records." if synthetic_note else "Operational records."),
            ("", ""), ("Sheet", "Contents")] + [(s[0], s[3]) for s in SHEETS] + [
            ("Summary", "Formula-driven totals per item (SUMIFS). This is NOT a PivotTable."), ("Pivot_Guide", "How to create / refresh PivotTables."),
            ("", ""), ("Definitions", "")] + DEFINITIONS
    for r, (a, b) in enumerate(rows, 1):
        ws.cell(row=r, column=1, value=a).font = Font(bold=True)
        ws.cell(row=r, column=2, value=b)
    ws["A1"].font = Font(bold=True, size=14, color=NAVY)
    ws.column_dimensions["A"].width = 28
    ws.column_dimensions["B"].width = 100
    info = {"rows": {}, "totals": {}}
    frames = {}
    for sheet, tname, fn, _ in SHEETS:
        df = fn(start, end)
        frames[sheet] = df
        info["rows"][sheet] = _write_table(wb.create_sheet(sheet), df, tname)
    base = frames["Pivot_Base"]
    if not base.empty:
        info["totals"] = {"prepared": int(base["Prepared_Portions"].sum()), "served": int(base["Served_Portions"].sum()),
                          "discarded_kg": round(float(base["Discarded_Kg"].sum()), 3), "donated_kg": round(float(base["Donated_Kg"].sum()), 3)}
        sm = wb.create_sheet("Summary", 1)
        heads = ["Item", "Prepared", "Served", "Discarded_Portions_Est", "Waste_Cost_Est", "Waste_%"]
        for c, h in enumerate(heads, 1):
            cell = sm.cell(row=1, column=c, value=h)
            cell.font, cell.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor=NAVY)
        n = len(base)
        cols = {c: get_column_letter(list(base.columns).index(c) + 1) for c in base.columns}
        rng = lambda col: f"Pivot_Base!${cols[col]}$2:${cols[col]}${n + 1}"
        items = sorted(base["Item"].unique())
        for r, it in enumerate(items, 2):
            sm.cell(row=r, column=1, value=it)
            sm.cell(row=r, column=2, value=f"=SUMIFS({rng('Prepared_Portions')},{rng('Item')},A{r})")
            sm.cell(row=r, column=3, value=f"=SUMIFS({rng('Served_Portions')},{rng('Item')},A{r})")
            sm.cell(row=r, column=4, value=f"=SUMIFS({rng('Discarded_Portions_Est')},{rng('Item')},A{r})").number_format = "#,##0.0"
            sm.cell(row=r, column=5, value=f"=SUMIFS({rng('Waste_Cost_Est')},{rng('Item')},A{r})").number_format = "#,##0.00"
            sm.cell(row=r, column=6, value=f"=IF(B{r}=0,0,D{r}/B{r}*100)").number_format = "0.00"
        tr = len(items) + 2
        sm.cell(row=tr, column=1, value="TOTAL").font = Font(bold=True)
        for c in range(2, 6):
            L = get_column_letter(c)
            sm.cell(row=tr, column=c, value=f"=SUM({L}2:{L}{tr - 1})").font = Font(bold=True)
        sm.cell(row=tr, column=6, value=f"=IF(B{tr}=0,0,D{tr}/B{tr}*100)").number_format = "0.00"
        sm.column_dimensions["A"].width = 24
        for c in "BCDEF":
            sm.column_dimensions[c].width = 22
    pg = wb.create_sheet("Pivot_Guide")
    steps = ["Create a PivotTable (Excel desktop):", "1. Open sheet Pivot_Base and click any cell inside the table (tbl_PivotBase).",
             "2. Insert > PivotTable > From Table/Range > New Worksheet > OK.",
             "3. Waste by item: Rows = Item; Values = Sum of Prepared_Portions, Sum of Discarded_Portions_Est, Sum of Waste_Cost_Est.",
             "4. Weekday pattern: Rows = Weekday (sort by WeekdayNo); Columns = Item; Values = Average of Served_Portions.",
             "5. Monthly trend: Rows = Month; Values = Sum of Discarded_Portions_Est. Insert > PivotChart for a chart.",
             "6. Add Slicers: PivotTable Analyze > Insert Slicer > Category, Weekday.",
             "7. Waste % needs a calculated field: PivotTable Analyze > Fields, Items & Sets > Calculated Field:",
             "   Name = Waste_Pct ; Formula = Discarded_Portions_Est / Prepared_Portions",
             "Refresh after new data: re-export from PlateWise (Reports & Exports), paste the new rows over the table, then Data > Refresh All.",
             "Check: the PivotTable grand totals of Prepared_Portions and Served_Portions must equal the Totals shown in PlateWise."]
    for r, s_ in enumerate(steps, 1):
        pg.cell(row=r, column=1, value=s_).font = Font(bold=(r == 1))
    pg.column_dimensions["A"].width = 130
    bio = BytesIO()
    wb.save(bio)
    return bio.getvalue(), info


def verify_workbook(xlsx_bytes: bytes, start=None, end=None) -> dict:
    """Re-open the file and compare its column sums with totals computed from the base MySQL tables."""
    wb = load_workbook(BytesIO(xlsx_bytes), data_only=False)
    ws = wb["Pivot_Base"]
    hdr = [c.value for c in ws[1]]
    if "Prepared_Portions" not in hdr:
        return {"ok": True, "note": "empty export"}

    def colsum(name):
        i = hdr.index(name)
        return sum((row[i] or 0) for row in ws.iter_rows(min_row=2, values_only=True))
    got = {"prepared": int(colsum("Prepared_Portions")), "served": int(colsum("Served_Portions")),
           "discarded_kg": round(colsum("Discarded_Kg"), 3), "donated_kg": round(colsum("Donated_Kg"), 3)}
    want = rs.database_totals(start, end)
    diffs = {k: (got[k], want[k]) for k in want if abs(got[k] - want[k]) > 0.01}
    return {"ok": not diffs, "excel": got, "mysql": want, "differences": diffs}
