"""Input validation helpers. Every function raises ValidationError with a readable message."""
from datetime import date, datetime


class ValidationError(ValueError):
    pass


def require_text(value, label: str, max_len: int = 100) -> str:
    v = (value or "").strip()
    if not v:
        raise ValidationError(f"{label} is required.")
    if len(v) > max_len:
        raise ValidationError(f"{label} must be at most {max_len} characters.")
    return v


def positive_int(value, label: str, maximum: int = 100000) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be a whole number.")
    if n <= 0:
        raise ValidationError(f"{label} must be greater than zero.")
    if n > maximum:
        raise ValidationError(f"{label} looks too large (maximum {maximum}).")
    return n


def non_negative_int(value, label: str, maximum: int = 100000) -> int:
    try:
        n = int(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be a whole number.")
    if n < 0:
        raise ValidationError(f"{label} cannot be negative.")
    if n > maximum:
        raise ValidationError(f"{label} looks too large (maximum {maximum}).")
    return n


def positive_number(value, label: str, maximum: float = 1_000_000) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be a number.")
    if x != x or x <= 0:
        raise ValidationError(f"{label} must be greater than zero.")
    if x > maximum:
        raise ValidationError(f"{label} looks too large (maximum {maximum}).")
    return x


def non_negative_number(value, label: str, maximum: float = 1_000_000) -> float:
    try:
        x = float(value)
    except (TypeError, ValueError):
        raise ValidationError(f"{label} must be a number.")
    if x != x or x < 0:
        raise ValidationError(f"{label} cannot be negative.")
    if x > maximum:
        raise ValidationError(f"{label} looks too large (maximum {maximum}).")
    return x


def one_of(value, choices, label: str):
    if value not in choices:
        raise ValidationError(f"{label} must be one of: {', '.join(map(str, choices))}.")
    return value


def not_future(d, label: str):
    d0 = d.date() if isinstance(d, datetime) else d
    if not isinstance(d0, date):
        raise ValidationError(f"{label} must be a valid date.")
    if d0 > date.today():
        raise ValidationError(f"{label} cannot be in the future.")
    return d0


def valid_password(pw: str) -> str:
    if not pw or len(pw) < 8:
        raise ValidationError("Password must be at least 8 characters.")
    if pw.isalpha() or pw.isdigit():
        raise ValidationError("Password must mix letters and digits (or symbols).")
    return pw
