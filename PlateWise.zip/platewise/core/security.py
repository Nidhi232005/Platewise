"""Password hashing, authentication and role-based permissions (enforced in services)."""
import bcrypt

from core import database as db
from core.validation import ValidationError, one_of, require_text, valid_password

ROLES = ("admin", "manager", "operator", "analyst")

PERMISSIONS = {
    "admin": {"*"},
    "manager": {
        "view", "menu.write", "inventory.write", "prep.write", "service.write", "waste.write",
        "forecast.run", "forecast.review", "recommendations.review", "reports.view", "export",
        "audit.view",
    },
    "operator": {"view", "prep.write", "service.write", "waste.write", "inventory.write"},
    "analyst": {"view", "reports.view", "export"},
}


class PermissionDenied(PermissionError):
    pass


def can(user: dict | None, permission: str) -> bool:
    if not user or user.get("role") not in PERMISSIONS:
        return False
    perms = PERMISSIONS[user["role"]]
    return "*" in perms or permission in perms


def require(user: dict | None, permission: str) -> None:
    """Raise PermissionDenied unless the user's role grants the permission."""
    if not can(user, permission):
        who = user.get("role") if user else "anonymous"
        raise PermissionDenied(f"Your role ({who}) is not allowed to do this ({permission}).")


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), hashed.encode("utf-8"))
    except ValueError:
        return False


def authenticate(username: str, password: str) -> dict | None:
    """Return the user dict if credentials are valid and the account is active."""
    df = db.query_df(
        "SELECT user_id, username, full_name, password_hash, role, is_active FROM users WHERE username = :u",
        {"u": (username or "").strip()},
    )
    if df.empty:
        verify_password(password or "", hash_password("dummy-password-1"))  # equalise timing
        return None
    row = df.iloc[0]
    if not row["is_active"] or not verify_password(password or "", row["password_hash"]):
        return None
    return {"user_id": int(row["user_id"]), "username": row["username"],
            "full_name": row["full_name"], "role": row["role"]}


def create_user(actor: dict | None, username: str, full_name: str, password: str, role: str, bootstrap: bool = False) -> int:
    """Create a user. Needs 'users.manage' (admin) unless bootstrap=True (first-run script)."""
    if not bootstrap:
        require(actor, "users.manage")
    username = require_text(username, "Username", 50)
    full_name = require_text(full_name, "Full name", 100)
    one_of(role, ROLES, "Role")
    valid_password(password)
    if not db.query_df("SELECT 1 FROM users WHERE username=:u", {"u": username}).empty:
        raise ValidationError("That username already exists.")
    with db.transaction() as conn:
        res = db.execute(
            "INSERT INTO users (username, full_name, password_hash, role) VALUES (:u,:f,:h,:r)",
            {"u": username, "f": full_name, "h": hash_password(password), "r": role}, conn)
        uid = res.lastrowid
        from services.audit import log
        log(conn, actor["user_id"] if actor else None, "create", "user", uid, {"username": username, "role": role})
    return uid


def set_user_active(actor: dict, user_id: int, active: bool) -> None:
    require(actor, "users.manage")
    if user_id == actor["user_id"] and not active:
        raise ValidationError("You cannot deactivate your own account.")
    with db.transaction() as conn:
        db.execute("UPDATE users SET is_active=:a WHERE user_id=:i", {"a": int(active), "i": user_id}, conn)
        from services.audit import log
        log(conn, actor["user_id"], "activate" if active else "deactivate", "user", user_id, {})


def reset_password(actor: dict, user_id: int, new_password: str) -> None:
    require(actor, "users.manage")
    valid_password(new_password)
    with db.transaction() as conn:
        db.execute("UPDATE users SET password_hash=:h WHERE user_id=:i", {"h": hash_password(new_password), "i": user_id}, conn)
        from services.audit import log
        log(conn, actor["user_id"], "reset_password", "user", user_id, {})
