"""Database access layer: engine, parameterised helpers, transactions, script runner."""
import re
from contextlib import contextmanager
from pathlib import Path

import pandas as pd
from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

from core import config

SQL_DIR = Path(__file__).resolve().parent.parent / "sql"
_engine = None


class DatabaseError(Exception):
    """Raised with a user-friendly message when the database cannot be used."""


def get_engine():
    global _engine
    if _engine is None:
        _engine = create_engine(config.database_url(), pool_pre_ping=True, pool_recycle=1800)
    return _engine


def set_engine(engine) -> None:
    """Used by tests/scripts to point the app at another database."""
    global _engine
    _engine = engine


def check_connection() -> tuple[bool, str]:
    try:
        with get_engine().connect() as conn:
            conn.execute(text("SELECT 1"))
        return True, "Connected"
    except SQLAlchemyError as exc:
        return False, f"Cannot connect to the database: {exc.__class__.__name__}. Check .env settings and that MySQL is running."


@contextmanager
def transaction():
    """All statements inside succeed together or are rolled back."""
    with get_engine().begin() as conn:
        yield conn


def query_df(sql: str, params: dict | None = None, conn=None) -> pd.DataFrame:
    try:
        if conn is not None:
            return pd.read_sql(text(sql), conn, params=params or {})
        with get_engine().connect() as c:
            return pd.read_sql(text(sql), c, params=params or {})
    except SQLAlchemyError as exc:
        raise DatabaseError(f"Database query failed: {exc.__class__.__name__}") from exc


def execute(sql: str, params: dict | None = None, conn=None):
    """Run one parameterised statement; returns the SQLAlchemy result."""
    if conn is not None:
        return conn.execute(text(sql), params or {})
    with transaction() as c:
        return c.execute(text(sql), params or {})


def scalar(sql: str, params: dict | None = None, conn=None):
    res = execute(sql, params, conn) if conn is not None else None
    if res is None:
        with get_engine().connect() as c:
            return c.execute(text(sql), params or {}).scalar()
    return res.scalar()


def split_statements(script: str) -> list[str]:
    lines = [ln for ln in script.splitlines() if not ln.strip().startswith("--")]
    return [s.strip() for s in "\n".join(lines).split(";") if s.strip()]


def run_script(path: Path, engine=None) -> int:
    engine = engine or get_engine()
    statements = split_statements(Path(path).read_text(encoding="utf-8"))
    with engine.begin() as conn:
        for stmt in statements:
            conn.execute(text(stmt))
    return len(statements)


def drop_all(engine=None) -> None:
    """Drop every table and view (used by --reset and by tests)."""
    engine = engine or get_engine()
    with engine.begin() as conn:
        conn.execute(text("SET FOREIGN_KEY_CHECKS=0"))
        views = conn.execute(text("SELECT table_name FROM information_schema.views WHERE table_schema = DATABASE()")).fetchall()
        for (v,) in views:
            conn.execute(text(f"DROP VIEW IF EXISTS `{v}`"))
        tables = conn.execute(text("SELECT table_name FROM information_schema.tables WHERE table_schema = DATABASE() AND table_type='BASE TABLE'")).fetchall()
        for (t,) in tables:
            if re.fullmatch(r"[A-Za-z0-9_]+", t):
                conn.execute(text(f"DROP TABLE IF EXISTS `{t}`"))
        conn.execute(text("SET FOREIGN_KEY_CHECKS=1"))


def create_schema(engine=None, reset: bool = False) -> None:
    engine = engine or get_engine()
    if reset:
        drop_all(engine)
    run_script(SQL_DIR / "schema.sql", engine)
    run_script(SQL_DIR / "reference_data.sql", engine)
    run_script(SQL_DIR / "views.sql", engine)


def get_settings() -> dict:
    df = query_df("SELECT setting_key, setting_value FROM config_settings")
    return dict(zip(df["setting_key"], df["setting_value"]))


def setting(key: str, default=None, cast=str):
    val = get_settings().get(key)
    return default if val is None else cast(val)
