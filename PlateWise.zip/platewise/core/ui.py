"""PlateWise visual identity and reusable UI components (CSS + small HTML builders)."""
import html
from contextlib import contextmanager

import streamlit as st

from core.database import DatabaseError
from core.security import PermissionDenied
from core.validation import ValidationError

NAVY, IVORY, CHARCOAL = "#14213D", "#FAF6EC", "#2B2B30"
PERI, VIOLET, LIGHTBLUE = "#B8B5F0", "#5B58C9", "#B7D3EC"
PALETTE = [VIOLET, "#7FA9D1", NAVY, PERI, LIGHTBLUE, "#8F8CE0", "#4A5A8A", "#9AA5C9"]

LOGO_SVG = """<svg width="38" height="38" viewBox="0 0 44 44" aria-label="PlateWise logo">
<circle cx="20" cy="22" r="15" fill="none" stroke="#B8B5F0" stroke-width="2.4"/>
<circle cx="20" cy="22" r="8.5" fill="#2C3A66" stroke="#B8B5F0" stroke-width="1.4"/>
<path d="M20 22 L20 13.5 A8.5 8.5 0 0 1 27.4 17.8 Z" fill="#B8B5F0"/>
<path d="M22 3.5 A19 19 0 0 1 41 22" fill="none" stroke="#8F8CE0" stroke-width="3" stroke-linecap="round"/>
<path d="M41 22 l-3.6 -4.6 l7.2 0 Z" fill="#8F8CE0"/></svg>"""

CSS = f"""
<style>
.stApp {{ background:{IVORY}; color:{CHARCOAL}; }}
[data-testid="stHeader"] {{ background:transparent; }}
[data-testid="stSidebar"] {{ background:{NAVY}; }}
[data-testid="stSidebar"] * {{ color:#E8EAF6; }}
[data-testid="stSidebar"] .stButton > button {{
  width:100%; justify-content:flex-start; text-align:left; background:transparent; border:0; border-radius:2px;
  padding:.35rem .6rem; font-size:.92rem; color:#C5CAE6; }}
[data-testid="stSidebar"] .stButton > button:hover {{ background:#22305A; color:#fff; }}
[data-testid="stSidebar"] .stButton > button[kind="primary"] {{ background:#2C3A66; color:#fff; border-left:3px solid {PERI}; font-weight:600; }}
[data-testid="stSidebar"] hr {{ border-color:#2C3A66; }}
h1,h2,h3 {{ color:{NAVY}; letter-spacing:-0.01em; }}
.pw-brand {{ display:flex; align-items:center; gap:.6rem; padding:.2rem 0 .8rem 0; }}
.pw-brand b {{ font-size:1.15rem; color:#fff; }} .pw-brand small {{ display:block; color:#A9B0D0; font-size:.72rem; }}
.pw-top {{ display:flex; justify-content:space-between; align-items:center; border-bottom:1px solid #D9D3C0; padding-bottom:.4rem; margin-bottom:.8rem; }}
.pw-chip {{ display:inline-block; padding:.12rem .55rem; font-size:.78rem; border:1px solid {PERI}; background:#E3E4F8; color:#3B3A8C; }}
.pw-chip.plain {{ background:#fff; border-color:#C9C3AE; color:{CHARCOAL}; }}
.pw-kpi {{ background:#fff; border:1px solid #D9D3C0; border-left:4px solid {VIOLET}; padding:.55rem .75rem; height:100%; }}
.pw-kpi .l {{ font-size:.74rem; color:#5A5A63; text-transform:uppercase; letter-spacing:.04em; }}
.pw-kpi .v {{ font-size:1.7rem; font-weight:650; color:{NAVY}; line-height:1.15; font-variant-numeric:tabular-nums; }}
.pw-kpi .u {{ font-size:.8rem; font-weight:400; color:#5A5A63; margin-left:.25rem; }}
.pw-kpi .n {{ font-size:.74rem; color:#5A5A63; }}
.pw-card {{ background:#fff; border:1px solid #D9D3C0; padding:.7rem .85rem; margin-bottom:.7rem; }}
.pw-card .hd {{ display:flex; justify-content:space-between; align-items:baseline; }}
.pw-card .nm {{ font-weight:650; color:{NAVY}; font-size:1.02rem; }}
.pw-card .cd {{ font-family:ui-monospace,Menlo,monospace; font-size:.72rem; color:#5A5A63; }}
.pw-card .meta {{ font-size:.78rem; color:#5A5A63; margin:.15rem 0 .4rem; }}
.pw-card .nums {{ display:flex; gap:1rem; }} .pw-card .nums div {{ font-size:.72rem; color:#5A5A63; }}
.pw-card .nums b {{ display:block; font-size:1.3rem; color:{NAVY}; font-variant-numeric:tabular-nums; }}
.pw-bar {{ height:8px; background:#E9E5D6; margin-top:.45rem; position:relative; }}
.pw-bar i {{ position:absolute; left:0; top:0; bottom:0; background:{VIOLET}; }}
.pw-bar i.b {{ background:{LIGHTBLUE}; }}
.pw-sec {{ margin:.9rem 0 .3rem; font-weight:650; color:{NAVY}; border-bottom:2px solid {PERI}; display:inline-block; }}
.pw-note {{ font-size:.78rem; color:#5A5A63; }}
.stTabs [data-baseweb="tab"] {{ font-weight:600; }}
.stButton > button[kind="primary"], .stFormSubmitButton > button[kind="primaryFormSubmit"], .stFormSubmitButton > button {{ border-radius:2px; }}
.stButton > button[kind="primary"] {{ background:{VIOLET}; border-color:{VIOLET}; }}
</style>
"""


def inject_css():
    st.markdown(CSS, unsafe_allow_html=True)


def esc(x) -> str:
    return html.escape(str(x))


def kpi(label: str, value, unit: str = "", note: str = "") -> str:
    return (f'<div class="pw-kpi"><div class="l">{esc(label)}</div><div class="v">{esc(value)}'
            f'<span class="u">{esc(unit)}</span></div><div class="n">{esc(note)}&nbsp;</div></div>')


def kpi_row(items: list[tuple]):
    cols = st.columns(len(items))
    for col, it in zip(cols, items):
        with col:
            st.markdown(kpi(*it), unsafe_allow_html=True)


def section(title: str):
    st.markdown(f'<div class="pw-sec">{esc(title)}</div>', unsafe_allow_html=True)


def note(text: str):
    st.markdown(f'<div class="pw-note">{esc(text)}</div>', unsafe_allow_html=True)


def chip(text: str, plain: bool = False) -> str:
    return f'<span class="pw-chip{" plain" if plain else ""}">{esc(text)}</span>'


def empty(message: str):
    st.info(f"ℹ️ {message}")


def style_fig(fig, height: int = 320):
    fig.update_layout(height=height, margin=dict(l=10, r=10, t=40, b=10), paper_bgcolor="rgba(0,0,0,0)",
                      plot_bgcolor="#FFFFFF", font=dict(color=CHARCOAL), colorway=PALETTE,
                      legend=dict(orientation="h", y=-0.2), title_font=dict(size=14, color=NAVY))
    fig.update_xaxes(gridcolor="#EFEBDD")
    fig.update_yaxes(gridcolor="#EFEBDD")
    return fig


@contextmanager
def guarded(success: str | None = None):
    """Turn expected errors into friendly messages instead of stack traces."""
    try:
        yield
        if success:
            st.success(success)
    except ValidationError as e:
        st.error(f"⚠️ {e}")
    except PermissionDenied as e:
        st.error(f"🔒 {e}")
    except DatabaseError as e:
        st.error(f"🗄️ {e}")
    except Exception as e:  # last resort: do not leak internals into the UI
        st.error(f"Something went wrong ({e.__class__.__name__}). The action was not completed.")
        st.session_state["last_error"] = repr(e)
