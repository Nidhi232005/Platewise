"""Configuration loaded from environment variables / .env (never hardcode credentials)."""
import os
from dotenv import load_dotenv
from sqlalchemy.engine import URL

load_dotenv()


def database_url() -> URL | str:
    """Build the SQLAlchemy URL. DATABASE_URL wins; otherwise DB_* variables are used."""
    direct = os.getenv("DATABASE_URL")
    if direct:
        return direct
    return URL.create(
        "mysql+pymysql",
        username=os.getenv("DB_USER", "root"),
        password=os.getenv("DB_PASSWORD", ""),
        host=os.getenv("DB_HOST", "127.0.0.1"),
        port=int(os.getenv("DB_PORT", "3306")),
        database=os.getenv("DB_NAME", "platewise"),
        query={"charset": "utf8mb4"},
    )
