"""FIFO lot tracking so expiry alerts reflect what is probably still on the shelf."""
import pandas as pd


def fifo_remaining_lots(movements: pd.DataFrame) -> pd.DataFrame:
    """movements columns: ingredient_id, movement_type, quantity_change, movement_date, expiry_date.
    Purchases create lots; usage/spoilage (negative) consume the OLDEST lots first;
    positive adjustments are treated as extra lots with no expiry. Returns remaining lots (qty > 0)."""
    rows = []
    if movements.empty:
        return pd.DataFrame(columns=["ingredient_id", "received", "expiry_date", "remaining_qty"])
    for ing, g in movements.sort_values(["movement_date", "movement_id"] if "movement_id" in movements else ["movement_date"]).groupby("ingredient_id"):
        lots = []
        for r in g.itertuples():
            q = float(r.quantity_change)
            if q > 0:
                lots.append([r.movement_date, r.expiry_date, q])
            else:
                need = -q
                for lot in lots:
                    take = min(lot[2], need)
                    lot[2] -= take
                    need -= take
                    if need <= 1e-9:
                        break
        for rec, exp, qty in lots:
            if qty > 1e-6:
                rows.append({"ingredient_id": ing, "received": rec, "expiry_date": exp, "remaining_qty": round(qty, 3)})
    return pd.DataFrame(rows, columns=["ingredient_id", "received", "expiry_date", "remaining_qty"])


def expiry_alerts(lots: pd.DataFrame, as_of, warn_days: int = 3) -> pd.DataFrame:
    if lots.empty:
        return lots.assign(days_to_expiry=[], alert=[])
    d = lots.dropna(subset=["expiry_date"]).copy()
    d["days_to_expiry"] = (pd.to_datetime(d["expiry_date"]) - pd.Timestamp(as_of)).dt.days
    d["alert"] = d["days_to_expiry"].apply(lambda x: "expired" if x < 0 else ("expiring_soon" if x <= warn_days else "ok"))
    return d[d["alert"] != "ok"].sort_values("days_to_expiry")
