"""Explainable demand forecasting with chronological validation (no future data leakage).

Candidate models (all use ONLY observations dated before the target date):
  baseline        mean of the last k same weekdays                       (always the reference)
  moving_avg_7    mean of the last 7 operating days
  footfall_ratio  baseline x (expected footfall on target day / mean observed footfall on those days)
                  -> used only when the target day's EXPECTED footfall is known in advance
  ridge           scikit-learn Ridge on weekday + last same-weekday demand + 7-day mean
A candidate replaces the baseline only if its backtest MAE is at least `improvement_threshold`
lower than the baseline's on the same test days; otherwise the simple baseline stays.
"""
import math

import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge

from analytics.metrics import mae, rmse

DEFAULT_CFG = {"k": 4, "min_obs": 8, "backtest_days": 14, "improvement_threshold": 0.05,
               "buffer": 0.05, "buffer_after_shortage": 0.10, "rounding_step": 5, "safety_mae_multiplier": 1.0}
WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def prepare_history(df: pd.DataFrame, sold_out_uplift: float = 0.10) -> pd.DataFrame:
    """Expect columns operating_date, served, sold_out (0/1), footfall_obs, footfall_exp.
    On sold-out days observed sales understate demand (censored), so demand = served*(1+uplift)."""
    h = df.copy()
    h["operating_date"] = pd.to_datetime(h["operating_date"])
    h = h.sort_values("operating_date").drop_duplicates("operating_date", keep="last").reset_index(drop=True)
    for c in ("sold_out", "footfall_obs", "footfall_exp"):
        if c not in h:
            h[c] = np.nan if c.startswith("footfall") else 0
    h["demand"] = h["served"].astype(float) * np.where(h["sold_out"].fillna(0) > 0, 1 + sold_out_uplift, 1.0)
    return h


def _same_weekday(hist: pd.DataFrame, target: pd.Timestamp, k: int) -> pd.DataFrame:
    past = hist[hist["operating_date"] < target]
    return past[past["operating_date"].dt.weekday == target.weekday()].tail(k)


def predict_baseline(hist, target, cfg):
    s = _same_weekday(hist, target, cfg["k"])
    return float(s["demand"].mean()) if len(s) >= 2 else None


def predict_moving_avg(hist, target, cfg, window: int = 7):
    past = hist[hist["operating_date"] < target].tail(window)
    return float(past["demand"].mean()) if len(past) >= 3 else None


def predict_footfall_ratio(hist, target, cfg, expected_footfall):
    if expected_footfall is None or (isinstance(expected_footfall, float) and math.isnan(expected_footfall)):
        return None
    s = _same_weekday(hist, target, cfg["k"])
    ff = s["footfall_obs"].dropna()
    if len(s) < 2 or len(ff) < max(2, len(s) - 1) or ff.mean() <= 0:
        return None
    return float(s["demand"].mean()) * float(expected_footfall) / float(ff.mean())


def _ridge_features(h: pd.DataFrame) -> pd.DataFrame:
    f = pd.DataFrame({"wd": h["operating_date"].dt.weekday})
    f["lag_wd"] = h.groupby(h["operating_date"].dt.weekday)["demand"].shift(1).values
    f["roll7"] = h["demand"].shift(1).rolling(7).mean().values
    return f


def predict_ridge(hist, target, cfg, min_train: int = 28):
    past = hist[hist["operating_date"] < target].reset_index(drop=True)
    if len(past) < min_train:
        return None
    feats = _ridge_features(past)
    ok = feats.dropna().index
    if len(ok) < min_train - 8:
        return None

    def design(wd, lag, roll):
        return [1.0 if wd == d else 0.0 for d in range(7)] + [lag, roll]
    X = np.array([design(feats.loc[i, "wd"], feats.loc[i, "lag_wd"], feats.loc[i, "roll7"]) for i in ok])
    y = past.loc[ok, "demand"].values
    same = past[past["operating_date"].dt.weekday == target.weekday()]
    if same.empty:
        return None
    x_new = np.array([design(target.weekday(), float(same["demand"].iloc[-1]), float(past["demand"].tail(7).mean()))])
    model = Ridge(alpha=1.0).fit(X, y)
    return float(max(model.predict(x_new)[0], 0.0))


def _predict(model: str, hist, target, cfg, expected_footfall):
    if model == "baseline":
        return predict_baseline(hist, target, cfg)
    if model == "moving_avg_7":
        return predict_moving_avg(hist, target, cfg)
    if model == "footfall_ratio":
        return predict_footfall_ratio(hist, target, cfg, expected_footfall)
    if model == "ridge":
        return predict_ridge(hist, target, cfg)
    raise ValueError(model)


CANDIDATES = ["moving_avg_7", "footfall_ratio", "ridge"]


def backtest(hist: pd.DataFrame, cfg: dict) -> dict:
    """Walk-forward validation: for each of the last N observed days, forecast it using only earlier rows.
    Compare every model on the SAME test days (those where baseline and the model both produced a value)."""
    test_idx = list(range(max(0, len(hist) - cfg["backtest_days"]), len(hist)))
    preds = {m: {} for m in ["baseline"] + CANDIDATES}
    for i in test_idx:
        t = hist.loc[i, "operating_date"]
        past = hist.iloc[:i]
        ef = hist.loc[i, "footfall_exp"]
        for m in preds:
            p = _predict(m, past, t, cfg, None if pd.isna(ef) else ef)
            if p is not None:
                preds[m][i] = p
    out = {}
    for m in CANDIDATES:
        common = [i for i in preds[m] if i in preds["baseline"]]
        if len(common) < 5:
            out[m] = {"n": len(common), "mae": None, "rmse": None, "baseline_mae": None}
            continue
        actual = hist.loc[common, "demand"].values
        out[m] = {"n": len(common), "mae": mae(actual, [preds[m][i] for i in common]),
                  "rmse": rmse(actual, [preds[m][i] for i in common]),
                  "baseline_mae": mae(actual, [preds["baseline"][i] for i in common])}
    b = list(preds["baseline"])
    out["baseline"] = {"n": len(b), "mae": mae(hist.loc[b, "demand"].values, [preds["baseline"][i] for i in b]) if b else None,
                       "rmse": rmse(hist.loc[b, "demand"].values, [preds["baseline"][i] for i in b]) if b else None}
    return out


def select_model(scores: dict, threshold: float, min_n: int = 8) -> str:
    best, best_mae = "baseline", None
    for m in CANDIDATES:
        s = scores.get(m, {})
        if s.get("mae") is None or s["n"] < min_n or not s.get("baseline_mae"):
            continue
        if s["mae"] <= s["baseline_mae"] * (1 - threshold) and (best_mae is None or s["mae"] < best_mae):
            best, best_mae = m, s["mae"]
    return best


def round_to_step(x: float, step: int) -> int:
    return int(math.floor(x / step + 0.5) * step)


def forecast_item(history: pd.DataFrame, target_date, expected_footfall=None, cfg: dict | None = None) -> dict:
    """history: output of prepare_history(); returns a dict ready to be stored and shown."""
    cfg = {**DEFAULT_CFG, **(cfg or {})}
    target = pd.Timestamp(target_date)
    hist = history[history["operating_date"] < target].reset_index(drop=True)
    res = {"status": "ok", "model_used": None, "predicted_demand": None, "recommended_qty": None,
           "buffer_pct": 0.0, "history_points": int(len(hist)), "backtest_n": 0, "mae_baseline": None,
           "mae_selected": None, "rmse_selected": None, "expected_footfall": expected_footfall,
           "inputs": {}, "explanation": "", "model_scores": {}}
    wd = WEEKDAYS[target.weekday()]
    if len(hist) < cfg["min_obs"]:
        res.update(status="insufficient_data", model_used="none",
                   explanation=f"Only {len(hist)} operating days of history (need {cfg['min_obs']}). "
                               f"No forecast produced; the manager should decide the quantity manually.")
        return res
    if hist["demand"].tail(cfg["k"] * 2).sum() == 0:
        res.update(model_used="zero_demand", predicted_demand=0.0, recommended_qty=0,
                   explanation="No demand was recorded in the recent comparable days. Recommendation is 0; "
                               "confirm with the manager before preparing anything.")
        return res
    scores = backtest(hist, cfg)
    chosen = select_model(scores, cfg["improvement_threshold"])
    pred = _predict(chosen, hist, target, cfg, expected_footfall)
    if pred is None:
        chosen, pred = "baseline", predict_baseline(hist, target, cfg)
    if pred is None:
        pred = predict_moving_avg(hist, target, cfg) or float(hist["demand"].tail(7).mean())
        chosen = "moving_avg_7"
    same = _same_weekday(hist, target, cfg["k"])
    shortage_recent = bool((same["sold_out"].fillna(0) > 0).any())
    floor_pct = cfg["buffer_after_shortage"] if shortage_recent else cfg["buffer"]
    sel = scores.get(chosen, {}) if chosen != "baseline" else scores["baseline"]
    # Safety stock = larger of (fixed % buffer) and (k x measured backtest MAE): items with erratic demand get more cover.
    mae_sel = sel.get("mae")
    mae_part = cfg["safety_mae_multiplier"] * mae_sel if mae_sel else 0.0
    safety = max(floor_pct * pred, mae_part)
    buffer = safety / pred if pred > 0 else floor_pct
    rec = max(round_to_step(pred + safety, cfg["rounding_step"]), int(math.ceil(pred)))
    base_mae = scores["baseline"]["mae"]
    vals = ", ".join(f"{v:.0f}" for v in same["demand"])
    parts = [f"Predicted {wd} demand {pred:.1f} portions using '{chosen}'."]
    if len(same):
        parts.append(f"Last {len(same)} {wd}s (demand): {vals}.")
    parts.append(f"Added {safety:.0f} portions of safety stock ({buffer*100:.0f}%: the larger of a {floor_pct*100:.0f}% buffer"
                 + (" [raised because an item sold out on a comparable day]" if shortage_recent else "")
                 + f" and {cfg['safety_mae_multiplier']:.1f} x the backtest error), rounded to steps of {cfg['rounding_step']}: prepare {rec}.")
    if base_mae is not None:
        alt = [f"{m} MAE {s['mae']:.1f}" for m, s in scores.items() if m != "baseline" and s.get("mae") is not None]
        parts.append(f"Backtest over the last {scores['baseline']['n']} days: baseline MAE {base_mae:.1f}"
                     + (f"; alternatives: {', '.join(alt)}" if alt else "")
                     + ("." if chosen != "baseline" else f". Baseline kept (no alternative lowered MAE by {cfg['improvement_threshold']*100:.0f}%+)."))
    parts.append("This is an estimate, not a guarantee.")
    res.update(model_used=chosen, predicted_demand=round(pred, 2), recommended_qty=int(rec),
               buffer_pct=buffer, backtest_n=int(scores["baseline"]["n"]),
               mae_baseline=None if base_mae is None else round(base_mae, 3),
               mae_selected=None if sel.get("mae") is None else round(sel["mae"], 3),
               rmse_selected=None if sel.get("rmse") is None else round(sel["rmse"], 3),
               inputs={"same_weekday_demand": [round(float(v), 1) for v in same["demand"]],
                       "sold_out_in_window": shortage_recent, "k": cfg["k"]},
               explanation=" ".join(parts), model_scores=scores)
    return res
