"""KPI formulas and quantity reconciliation. Pure functions (no database access).

Definitions (portions are COUNTED; kg are MEASURED; kg->portions is an ESTIMATE):
  surplus            = prepared - served
  waste_pct          = discarded_portions_est / prepared * 100
  shortage_rate      = days with sold-out / days with preparation * 100
  forecast error     = |actual - forecast|;  MAE = mean(error);  RMSE = sqrt(mean(error^2))
  waste per student  = discarded_portions_est / students served (observed footfall)
"""
import math

import numpy as np
import pandas as pd


def safe_div(num, den, default=0.0):
    try:
        if den is None or den == 0 or (isinstance(den, float) and math.isnan(den)):
            return default
        return num / den
    except TypeError:
        return default


def waste_pct(discarded_portions, prepared_portions) -> float:
    return safe_div(discarded_portions, prepared_portions) * 100.0


def surplus(prepared, served) -> int:
    return int(prepared) - int(served)


def kg_to_portions(weight_kg: float, portion_weight_kg: float) -> float:
    """Documented conversion: portions_est = kg / portion_weight_kg (ESTIMATE)."""
    if portion_weight_kg is None or portion_weight_kg <= 0:
        raise ValueError("portion_weight_kg must be positive")
    return float(weight_kg) / float(portion_weight_kg)


def to_kg(value: float, unit: str) -> float:
    factors = {"kg": 1.0, "g": 0.001}
    if unit not in factors:
        raise ValueError(f"Unsupported weight unit: {unit}")
    return float(value) * factors[unit]


def shortage_rate(days_with_sold_out: int, days_with_prep: int) -> float:
    return safe_div(days_with_sold_out, days_with_prep) * 100.0


def mae(actual, predicted) -> float | None:
    a, p = np.asarray(actual, float), np.asarray(predicted, float)
    return float(np.mean(np.abs(a - p))) if len(a) else None


def rmse(actual, predicted) -> float | None:
    a, p = np.asarray(actual, float), np.asarray(predicted, float)
    return float(np.sqrt(np.mean((a - p) ** 2))) if len(a) else None


def reconcile(prepared: int, served: int, measured_kg: float | None, portion_weight_kg: float,
              disposed_kg: float | None = None, tol_portions: float = 2, tol_pct: float = 0.05) -> dict:
    """Mass-balance check for one item on one day.

    expected_leftover = prepared - served               (counted)
    measured_portions = measured_kg / portion_weight    (estimate)
    unexplained       = expected_leftover - measured_portions
    Status:
      invalid_counts     served > prepared (data entry error)
      balanced           |unexplained| <= tolerance
      not_weighed        leftover expected but nothing weighed
      unexplained_loss   less weighed than expected (spillage, staff meals, counting error)
      over_measured      more weighed than expected (served count too high or double weighing)
    Separate check: disposition gap = measured_kg - disposed_kg ('pending_disposition' if > 0.05 kg).
    """
    expected = int(prepared) - int(served)
    tol = max(float(tol_portions), float(tol_pct) * max(int(prepared), 0))
    out = {"expected_leftover": expected, "tolerance_portions": round(tol, 2),
           "measured_portions_est": None, "unexplained_portions_est": None,
           "status": "balanced", "disposition_status": "n/a"}
    if expected < 0:
        out["status"] = "invalid_counts"
        return out
    if not measured_kg:
        out["measured_portions_est"] = 0.0
        out["unexplained_portions_est"] = float(expected)
        out["status"] = "not_weighed" if expected > tol else "balanced"
    else:
        mp = kg_to_portions(measured_kg, portion_weight_kg)
        un = expected - mp
        out["measured_portions_est"] = round(mp, 2)
        out["unexplained_portions_est"] = round(un, 2)
        if abs(un) <= tol:
            out["status"] = "balanced"
        else:
            out["status"] = "unexplained_loss" if un > 0 else "over_measured"
    if measured_kg:
        gap = float(measured_kg) - float(disposed_kg or 0)
        out["disposition_gap_kg"] = round(gap, 3)
        out["disposition_status"] = "pending_disposition" if gap > 0.05 else ("over_allocated" if gap < -0.05 else "complete")
    return out


def reconcile_frame(df: pd.DataFrame, tol_portions: float = 2, tol_pct: float = 0.05) -> pd.DataFrame:
    """Apply reconcile() to rows of v_daily_item_summary; adds recon_status columns."""
    if df.empty:
        return df.assign(recon_status=[], disposition_status=[])
    stat, dstat = [], []
    for r in df.itertuples():
        weighed = r.weigh_count > 0
        disposed = r.donated_kg + r.discarded_kg + r.retained_kg + r.other_loss_kg
        res = reconcile(int(r.prepared_portions), int(r.served_portions),
                        float(r.measured_kg) if weighed else None, float(r.portion_weight_kg),
                        float(disposed) if weighed else None, tol_portions, tol_pct)
        stat.append(res["status"])
        dstat.append(res["disposition_status"])
    return df.assign(recon_status=stat, disposition_status=dstat)


def summarize(df: pd.DataFrame) -> dict:
    """Headline KPIs from rows of v_daily_item_summary (already filtered by date/category)."""
    if df.empty:
        return {k: 0 for k in ["prepared", "served", "surplus", "discarded_portions", "donated_portions",
                               "waste_pct", "waste_cost", "avoidable_cost", "revenue", "shortage_rate",
                               "discarded_kg", "donated_kg", "measured_kg", "unexplained_days"]}
    prepared = float(df["prepared_portions"].sum())
    served = float(df["served_portions"].sum())
    disc = float(df["discarded_portions_est"].sum())
    days_prep = len(df)
    return {
        "prepared": int(prepared), "served": int(served), "surplus": int(prepared - served),
        "discarded_portions": disc, "donated_portions": float(df["donated_portions_est"].sum()),
        "waste_pct": waste_pct(disc, prepared),
        "waste_cost": float(df["discarded_cost_est"].sum()),
        "avoidable_cost": float(df["avoidable_cost_est"].sum()),
        "revenue": float(df["revenue"].sum()),
        "shortage_rate": shortage_rate(int(df["sold_out_flag"].sum()), days_prep),
        "discarded_kg": float(df["discarded_kg"].sum()), "donated_kg": float(df["donated_kg"].sum()),
        "measured_kg": float(df["measured_kg"].sum()),
        "unexplained_days": int((df.get("recon_status", pd.Series(dtype=str)).isin(
            ["unexplained_loss", "over_measured", "invalid_counts"])).sum()),
    }


def allocate_served_fifo(batches: list[dict], served_total: int) -> list[int]:
    """Estimate how many served portions came from each batch (oldest batch first).
    This is an ALLOCATION for display only; the counter records served per item, not per batch."""
    out, left = [], int(served_total)
    for b in sorted(batches, key=lambda x: x["prepared_at"]):
        take = min(left, int(b["qty_prepared"]))
        out.append(take)
        left -= take
    order = {id(b): i for i, b in enumerate(sorted(batches, key=lambda x: x["prepared_at"]))}
    return [out[order[id(b)]] for b in batches]
