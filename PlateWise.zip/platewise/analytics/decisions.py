"""Rule-based decision engine. Every rule returns a recommendation with evidence and limitations.
Safety principle: never suggest cutting production for an item that is already running short."""
import json

import numpy as np
import pandas as pd

from analytics.metrics import safe_div


def _rec(rule, item_id, item_name, problem, metrics, action, benefit, confidence, limitations, ingredient_id=None):
    return {"rule_code": rule, "item_id": item_id, "ingredient_id": ingredient_id, "item_name": item_name,
            "problem": problem, "metrics_json": json.dumps(metrics, default=float), "proposed_action": action,
            "expected_benefit": benefit, "confidence": confidence, "limitations": limitations}


def _conf(n: int) -> str:
    return "high" if n >= 20 else ("medium" if n >= 10 else "low")


def generate(daily: pd.DataFrame, spoilage: pd.DataFrame | None = None, as_of=None, window: int = 21) -> list[dict]:
    """daily: rows of v_daily_item_summary with recon_status. spoilage: ingredient spoilage vs purchases."""
    out = []
    if daily.empty:
        return out
    d = daily.copy()
    d["operating_date"] = pd.to_datetime(d["operating_date"])
    end = pd.Timestamp(as_of) if as_of else d["operating_date"].max()
    d = d[(d["operating_date"] <= end) & (d["operating_date"] > end - pd.Timedelta(days=window))]
    for (iid, name), g in d.groupby(["item_id", "item_name"]):
        n = len(g)
        if n < 6:
            continue
        prep, served = g["prepared_portions"].sum(), g["served_portions"].sum()
        waste_p = safe_div(g["discarded_portions_est"].sum(), prep) * 100
        sur_p = safe_div(prep - served, prep) * 100
        short_days = int(g["sold_out_flag"].sum())
        short_rate = short_days / n * 100
        avg_cost = float(g["avg_unit_cost"].mean())
        surplus_days = int(((g["prepared_portions"] - g["served_portions"]) > 0.08 * g["prepared_portions"]).sum())
        # 1. Repeated surplus -> reduce (blocked when shortages are frequent)
        if surplus_days >= 0.6 * n and sur_p >= 10 and short_rate < 15:
            avg_surplus = (prep - served) / n
            out.append(_rec("repeated_surplus", iid, name,
                            f"{name}: surplus above 8% on {surplus_days} of {n} days (average surplus {sur_p:.0f}% of prepared).",
                            {"days": n, "surplus_pct": sur_p, "waste_pct": waste_p, "shortage_rate": short_rate},
                            f"Lower preparation by about {int(avg_surplus * 0.6)} portions per day (keep a safety buffer).",
                            f"Estimated saving about Rs {avg_surplus * 0.6 * avg_cost:.0f} per day in production cost (estimate).",
                            _conf(n), f"Based on {n} days; assumes demand stays similar. Shortage rate was {short_rate:.0f}%."))
        # 2. Repeated shortage -> increase
        if short_days >= 3 and short_rate >= 15:
            out.append(_rec("repeated_shortage", iid, name,
                            f"{name} sold out on {short_days} of {n} days ({short_rate:.0f}%).",
                            {"days": n, "sold_out_days": short_days},
                            "Increase preparation (cook a second batch earlier or raise the forecast buffer).",
                            "Fewer unmet orders; sales on sold-out days are under-counted, so lost demand is unknown.",
                            _conf(n), "Unmet demand cannot be observed directly; uplift is an assumption."))
        # 3. High variability -> smaller batches
        served_series = g["served_portions"].astype(float)
        cv = safe_div(float(served_series.std()), float(served_series.mean()))
        if cv > 0.35 and served_series.mean() > 0:
            out.append(_rec("variable_demand", iid, name,
                            f"{name} demand is highly variable (coefficient of variation {cv:.2f}).",
                            {"cv": cv, "days": n},
                            "Cook in smaller batches and top up during service instead of one large batch.",
                            "Lower end-of-day surplus risk.", _conf(n), "Variability may reflect events or exams."))
        # 4. Unexplained discrepancies
        bad = int(g["recon_status"].isin(["unexplained_loss", "over_measured", "invalid_counts"]).sum()) if "recon_status" in g else 0
        if bad >= 3:
            out.append(_rec("unexplained_discrepancy", iid, name,
                            f"{name}: quantities did not reconcile on {bad} of {n} days.",
                            {"bad_days": bad, "days": n},
                            "Check counting at the counter, spillage and staff meals; weigh every return.",
                            "Cleaner data and more reliable forecasts.", _conf(n), "Cause is unknown until investigated."))
        # 5. Edible food discarded -> donation route
        edible_disc = float(g["discarded_edible_kg"].sum())
        if edible_disc >= 3.0:
            out.append(_rec("donation_opportunity", iid, name,
                            f"{name}: {edible_disc:.1f} kg of edible food was discarded in {n} days.",
                            {"edible_discarded_kg": edible_disc},
                            "Route edible surplus to the approved donation partner if it passes the food-safety check.",
                            f"Up to {edible_disc / float(g['portion_weight_kg'].iloc[0]):.0f} portions could feed others (estimate).",
                            "medium", "Only food that meets safety and local rules may be donated; safety comes first."))
    if spoilage is not None and not spoilage.empty:
        for r in spoilage.itertuples():
            if r.purchased_cost > 0 and r.spoiled_cost / r.purchased_cost > 0.05:
                out.append(_rec("ingredient_spoilage", None, None,
                                f"{r.ingredient_name}: spoilage was {r.spoiled_cost / r.purchased_cost * 100:.0f}% of purchase value.",
                                {"spoiled_cost": r.spoiled_cost, "purchased_cost": r.purchased_cost},
                                "Review order size or frequency for this ingredient.",
                                f"Up to Rs {r.spoiled_cost:.0f} per period (estimate).", "medium",
                                "Spoilage may come from storage conditions, not ordering.", int(r.ingredient_id)))
    return out
