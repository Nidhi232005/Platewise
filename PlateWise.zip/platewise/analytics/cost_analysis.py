"""Cost and impact calculations. Estimates are labelled; selling price is NOT treated as loss."""
import pandas as pd

from analytics.metrics import safe_div


def recipe_unit_cost(recipe_rows: list[tuple[float, float]]) -> float:
    """recipe_rows: (qty_per_portion, ingredient_cost_per_unit). Cost per portion = sum(q*c)."""
    return round(sum(q * c for q, c in recipe_rows), 2)


def cost_breakdown(df: pd.DataFrame) -> dict:
    """From v_daily_item_summary rows. Distinguishes four different money figures:
      production_cost   cost of everything cooked (estimate from recipe/manual cost)
      waste_cost        production cost of discarded food (estimate)
      avoidable_cost    part of waste_cost that was edible when discarded (could have been donated/reused)
      foregone_revenue  selling price x discarded portions (opportunity only, NOT a cash loss)
    """
    if df.empty:
        return dict(production_cost=0, waste_cost=0, avoidable_cost=0, foregone_revenue=0, donated_value=0, revenue=0)
    return {
        "production_cost": float(df["prep_cost_total"].sum()),
        "waste_cost": float(df["discarded_cost_est"].sum()),
        "avoidable_cost": float(df["avoidable_cost_est"].sum()),
        "foregone_revenue": float((df["discarded_portions_est"] * df["selling_price"]).sum()),
        "donated_value": float(df["donated_value_est"].sum()),
        "revenue": float(df["revenue"].sum()),
    }


def waste_per_student(discarded_portions: float, students: float) -> float:
    return safe_div(discarded_portions, students)


def before_after(daily: pd.DataFrame, item_id: int | None, change_date, window_days: int = 21) -> dict:
    """Compare average waste % and shortage rate before vs after an intervention date.
    NOT causal proof: demand, menu and weather also change. Reported with sample sizes."""
    d = daily if item_id is None else daily[daily["item_id"] == item_id]
    d = d.assign(operating_date=pd.to_datetime(d["operating_date"]))
    cd = pd.Timestamp(change_date)
    before = d[(d["operating_date"] < cd) & (d["operating_date"] >= cd - pd.Timedelta(days=window_days))]
    after = d[(d["operating_date"] >= cd) & (d["operating_date"] < cd + pd.Timedelta(days=window_days))]

    def stats(x):
        prep = float(x["prepared_portions"].sum())
        return {"days": int(len(x)), "waste_pct": safe_div(float(x["discarded_portions_est"].sum()), prep) * 100,
                "shortage_rate": safe_div(int(x["sold_out_flag"].sum()), len(x)) * 100,
                "avoidable_cost": float(x["avoidable_cost_est"].sum())}
    b, a = stats(before), stats(after)
    return {"before": b, "after": a,
            "waste_pct_change": a["waste_pct"] - b["waste_pct"],
            "shortage_rate_change": a["shortage_rate"] - b["shortage_rate"]}
