-- Physical configuration of the fictional canteen "The Daily Table - Campus Kitchen".
-- Stored in the database so zones, stations, hours and conversion factors are configurable.
INSERT IGNORE INTO zones (zone_code, zone_name, description, sort_order) VALUES
 ('A','Preparation Bay','Cooking stations Prep Bay A and Prep Bay B',1),
 ('B','Service Counter','Portions served to students',2),
 ('C','Weigh & Return Station','Leftover food weighed on the scale',3),
 ('D','Surplus Handling Station','Donation, discard or safe retention',4),
 ('E','Ingredient Store','Ingredient stock, usage, spoilage, expiry',5);
INSERT IGNORE INTO stations (station_code, station_name, zone_id, station_type)
 SELECT 'PREP-A','Prep Bay A',zone_id,'prep' FROM zones WHERE zone_code='A';
INSERT IGNORE INTO stations (station_code, station_name, zone_id, station_type)
 SELECT 'PREP-B','Prep Bay B',zone_id,'prep' FROM zones WHERE zone_code='A';
INSERT IGNORE INTO stations (station_code, station_name, zone_id, station_type)
 SELECT 'COUNTER-1','Service Counter 1',zone_id,'counter' FROM zones WHERE zone_code='B';
INSERT IGNORE INTO stations (station_code, station_name, zone_id, station_type)
 SELECT 'SCALE-01','Weighing Scale SCALE-01',zone_id,'scale' FROM zones WHERE zone_code='C';
INSERT IGNORE INTO stations (station_code, station_name, zone_id, station_type)
 SELECT 'SURPLUS-1','Surplus Handling Table',zone_id,'surplus' FROM zones WHERE zone_code='D';
INSERT IGNORE INTO stations (station_code, station_name, zone_id, station_type)
 SELECT 'STORE-1','Dry and Cold Store',zone_id,'store' FROM zones WHERE zone_code='E';
INSERT IGNORE INTO units (unit_code, unit_name, unit_type, to_base_factor) VALUES
 ('portion','Portion','count',1),('kg','Kilogram','mass',1),('g','Gram','mass',0.001),
 ('l','Litre','volume',1),('ml','Millilitre','volume',0.001),('pcs','Pieces','count',1);
INSERT IGNORE INTO service_periods (period_name, start_time, end_time) VALUES
 ('Breakfast','07:30:00','10:30:00'),('Lunch','12:00:00','15:00:00'),('Evening snacks','16:00:00','18:30:00');
INSERT IGNORE INTO config_settings (setting_key, setting_value, description) VALUES
 ('canteen_name','The Daily Table - Campus Kitchen','Display name'),
 ('currency_symbol','Rs ','Currency prefix for costs'),
 ('operating_days','0,1,2,3,4,5','Weekday numbers (Mon=0) the canteen operates'),
 ('buffer_pct','0.05','Safety buffer added to forecast demand'),
 ('buffer_pct_after_shortage','0.10','Buffer used if the item sold out on a recent comparable day'),
 ('sold_out_uplift','0.10','Demand uplift applied to sold-out days (censored demand assumption)'),
 ('recon_tolerance_portions','2','Reconciliation tolerance in portions'),
 ('recon_tolerance_pct','0.05','Reconciliation tolerance as share of prepared'),
 ('min_history_obs','8','Minimum observations before a forecast is produced'),
 ('same_weekday_k','4','Number of previous same weekdays in the baseline'),
 ('backtest_days','14','Chronological validation window (operating days)'),
 ('model_improvement_threshold','0.05','Alternative model must lower MAE by this share to replace baseline'),
 ('low_stock_expiry_days','3','Warn when stock expires within this many days'),
 ('safety_mae_multiplier','1.0','Safety stock = this x the item backtest MAE (or the % buffer if larger)'),
 ('model_version','pw-forecast-1.1','Version tag stored with every forecast');
INSERT IGNORE INTO categories (category_name) VALUES ('Breakfast'),('Main meal'),('Snacks');
