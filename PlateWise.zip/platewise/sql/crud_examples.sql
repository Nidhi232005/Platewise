-- CRUD examples (documentation). The application runs equivalent parameterised statements through SQLAlchemy.
-- CREATE
INSERT INTO categories (category_name) VALUES ('Beverages');
-- READ with JOIN
SELECT mi.item_name, c.category_name, mi.selling_price FROM menu_items mi JOIN categories c ON c.category_id = mi.category_id;
-- UPDATE
UPDATE menu_items SET selling_price = selling_price + 2 WHERE item_name = 'Samosa';
-- DELETE (soft delete is used for items that already have history)
DELETE FROM categories WHERE category_name = 'Beverages';
