-- One row per operating date x menu item that had at least one prep batch.
-- *_kg columns are MEASURED on the scale. *_portions_est columns are ESTIMATES (kg / portion_weight_kg).
-- prepared_portions and served_portions are COUNTED values.
CREATE OR REPLACE VIEW v_daily_item_summary AS
SELECT
  p.operating_date,
  p.item_id,
  mi.item_name,
  c.category_name,
  mi.portion_weight_kg,
  mi.selling_price,
  p.batches,
  p.prepared_portions,
  p.avg_unit_cost,
  p.prep_cost_total,
  COALESCE(s.paid_portions, 0) AS paid_portions,
  COALESCE(s.comp_portions, 0) AS comp_portions,
  COALESCE(s.paid_portions, 0) + COALESCE(s.comp_portions, 0) AS served_portions,
  COALESCE(s.revenue, 0) AS revenue,
  COALESCE(s.sold_out, 0) AS sold_out_flag,
  p.prepared_portions - (COALESCE(s.paid_portions, 0) + COALESCE(s.comp_portions, 0)) AS expected_leftover_portions,
  COALESCE(w.weigh_count, 0) AS weigh_count,
  COALESCE(w.measured_kg, 0) AS measured_kg,
  COALESCE(w.edible_kg, 0) AS edible_kg,
  COALESCE(w.not_edible_kg, 0) AS not_edible_kg,
  COALESCE(d.donated_kg, 0) AS donated_kg,
  COALESCE(d.discarded_kg, 0) AS discarded_kg,
  COALESCE(d.discarded_edible_kg, 0) AS discarded_edible_kg,
  COALESCE(d.retained_kg, 0) AS retained_kg,
  COALESCE(d.other_loss_kg, 0) AS other_loss_kg,
  COALESCE(w.measured_kg, 0) / mi.portion_weight_kg AS measured_portions_est,
  COALESCE(d.donated_kg, 0) / mi.portion_weight_kg AS donated_portions_est,
  COALESCE(d.discarded_kg, 0) / mi.portion_weight_kg AS discarded_portions_est,
  COALESCE(d.retained_kg, 0) / mi.portion_weight_kg AS retained_portions_est,
  (p.prepared_portions - (COALESCE(s.paid_portions, 0) + COALESCE(s.comp_portions, 0)))
    - COALESCE(w.measured_kg, 0) / mi.portion_weight_kg AS unexplained_portions_est,
  COALESCE(d.discarded_kg, 0) / mi.portion_weight_kg * p.avg_unit_cost AS discarded_cost_est,
  COALESCE(d.discarded_edible_kg, 0) / mi.portion_weight_kg * p.avg_unit_cost AS avoidable_cost_est,
  COALESCE(d.donated_kg, 0) / mi.portion_weight_kg * p.avg_unit_cost AS donated_value_est
FROM (
  SELECT operating_date, item_id, COUNT(*) AS batches, SUM(qty_prepared) AS prepared_portions,
         SUM(qty_prepared * unit_cost) / SUM(qty_prepared) AS avg_unit_cost,
         SUM(qty_prepared * unit_cost) AS prep_cost_total
  FROM prep_batches GROUP BY operating_date, item_id
) p
JOIN menu_items mi ON mi.item_id = p.item_id
JOIN categories c ON c.category_id = mi.category_id
LEFT JOIN (
  SELECT operating_date, item_id, SUM(portions_paid) AS paid_portions,
         SUM(portions_complimentary) AS comp_portions,
         SUM(portions_paid * unit_price) AS revenue, MAX(sold_out_flag) AS sold_out
  FROM service_records GROUP BY operating_date, item_id
) s ON s.operating_date = p.operating_date AND s.item_id = p.item_id
LEFT JOIN (
  SELECT operating_date, item_id, COUNT(*) AS weigh_count, SUM(weight_kg) AS measured_kg,
         SUM(CASE WHEN food_condition = 'edible' THEN weight_kg ELSE 0 END) AS edible_kg,
         SUM(CASE WHEN food_condition = 'not_edible' THEN weight_kg ELSE 0 END) AS not_edible_kg
  FROM weighing_records GROUP BY operating_date, item_id
) w ON w.operating_date = p.operating_date AND w.item_id = p.item_id
LEFT JOIN (
  SELECT wr.operating_date, wr.item_id,
         SUM(CASE WHEN wd.disposition_type = 'donated' THEN wd.weight_kg ELSE 0 END) AS donated_kg,
         SUM(CASE WHEN wd.disposition_type = 'discarded' THEN wd.weight_kg ELSE 0 END) AS discarded_kg,
         SUM(CASE WHEN wd.disposition_type = 'discarded' AND wr.food_condition = 'edible' THEN wd.weight_kg ELSE 0 END) AS discarded_edible_kg,
         SUM(CASE WHEN wd.disposition_type = 'retained' THEN wd.weight_kg ELSE 0 END) AS retained_kg,
         SUM(CASE WHEN wd.disposition_type = 'other_loss' THEN wd.weight_kg ELSE 0 END) AS other_loss_kg
  FROM waste_dispositions wd JOIN weighing_records wr ON wr.weigh_id = wd.weigh_id
  GROUP BY wr.operating_date, wr.item_id
) d ON d.operating_date = p.operating_date AND d.item_id = p.item_id;

-- Current stock = sum of signed movements (single source of truth).
CREATE OR REPLACE VIEW v_inventory_stock AS
SELECT i.ingredient_id, i.ingredient_name, i.unit_code, i.cost_per_unit, i.reorder_level,
       COALESCE(SUM(m.quantity_change), 0) AS current_stock,
       COALESCE(SUM(m.quantity_change), 0) * i.cost_per_unit AS stock_value,
       MAX(CASE WHEN m.movement_type = 'purchase' THEN m.movement_date END) AS last_purchase_date,
       CASE WHEN COALESCE(SUM(m.quantity_change), 0) <= i.reorder_level THEN 1 ELSE 0 END AS low_stock_flag
FROM ingredients i LEFT JOIN inventory_movements m ON m.ingredient_id = i.ingredient_id
WHERE i.is_active = 1
GROUP BY i.ingredient_id, i.ingredient_name, i.unit_code, i.cost_per_unit, i.reorder_level;

-- Each stored forecast joined to what actually happened.
CREATE OR REPLACE VIEW v_forecast_vs_actual AS
SELECT r.rec_id, r.target_date, r.item_id, mi.item_name, r.model_used, r.status,
       r.predicted_demand, r.recommended_qty, r.approved_qty,
       o.prepared_qty, o.served_qty, o.actual_demand_est, o.surplus_qty,
       o.discarded_portions_est, o.shortage_flag, o.abs_error
FROM forecast_recommendations r
JOIN menu_items mi ON mi.item_id = r.item_id
JOIN actual_outcomes o ON o.rec_id = r.rec_id;
