-- PlateWise schema (MySQL 8.0+ / MariaDB 10.5+). Engine: InnoDB, charset utf8mb4.
-- Cooked food is counted in PORTIONS (counted value).
-- Leftovers are measured in KG on the scale (measured value); kg -> portions uses
-- menu_items.portion_weight_kg and is always an ESTIMATE.

CREATE TABLE IF NOT EXISTS users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  full_name VARCHAR(100) NOT NULL,
  password_hash VARCHAR(100) NOT NULL,
  role ENUM('admin','manager','operator','analyst') NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS zones (
  zone_id INT AUTO_INCREMENT PRIMARY KEY,
  zone_code CHAR(1) NOT NULL UNIQUE,
  zone_name VARCHAR(60) NOT NULL,
  description VARCHAR(200),
  sort_order INT NOT NULL DEFAULT 0
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS stations (
  station_id INT AUTO_INCREMENT PRIMARY KEY,
  station_code VARCHAR(20) NOT NULL UNIQUE,
  station_name VARCHAR(60) NOT NULL,
  zone_id INT NOT NULL,
  station_type ENUM('prep','counter','scale','surplus','store') NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT fk_station_zone FOREIGN KEY (zone_id) REFERENCES zones(zone_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS units (
  unit_code VARCHAR(10) PRIMARY KEY,
  unit_name VARCHAR(30) NOT NULL,
  unit_type ENUM('count','mass','volume') NOT NULL,
  to_base_factor DECIMAL(12,6) NOT NULL CHECK (to_base_factor > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS service_periods (
  period_id INT AUTO_INCREMENT PRIMARY KEY,
  period_name VARCHAR(30) NOT NULL UNIQUE,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS config_settings (
  setting_key VARCHAR(50) PRIMARY KEY,
  setting_value VARCHAR(200) NOT NULL,
  description VARCHAR(250)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS menu_items (
  item_id INT AUTO_INCREMENT PRIMARY KEY,
  item_name VARCHAR(80) NOT NULL UNIQUE,
  category_id INT NOT NULL,
  period_id INT NOT NULL,
  selling_price DECIMAL(8,2) NOT NULL CHECK (selling_price >= 0),
  portion_weight_kg DECIMAL(6,3) NOT NULL CHECK (portion_weight_kg > 0),
  portion_weight_source VARCHAR(200) NOT NULL,
  est_cost_per_portion DECIMAL(8,2) NULL CHECK (est_cost_per_portion IS NULL OR est_cost_per_portion >= 0),
  rounding_step INT NOT NULL DEFAULT 5 CHECK (rounding_step > 0),
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_item_cat FOREIGN KEY (category_id) REFERENCES categories(category_id),
  CONSTRAINT fk_item_period FOREIGN KEY (period_id) REFERENCES service_periods(period_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ingredients (
  ingredient_id INT AUTO_INCREMENT PRIMARY KEY,
  ingredient_name VARCHAR(80) NOT NULL UNIQUE,
  unit_code VARCHAR(10) NOT NULL,
  cost_per_unit DECIMAL(10,2) NOT NULL CHECK (cost_per_unit >= 0),
  reorder_level DECIMAL(12,3) NOT NULL DEFAULT 0 CHECK (reorder_level >= 0),
  shelf_life_days INT NOT NULL DEFAULT 30 CHECK (shelf_life_days > 0),
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  CONSTRAINT fk_ing_unit FOREIGN KEY (unit_code) REFERENCES units(unit_code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS recipe_ingredients (
  item_id INT NOT NULL,
  ingredient_id INT NOT NULL,
  qty_per_portion DECIMAL(10,4) NOT NULL CHECK (qty_per_portion > 0),
  PRIMARY KEY (item_id, ingredient_id),
  CONSTRAINT fk_rec_item FOREIGN KEY (item_id) REFERENCES menu_items(item_id),
  CONSTRAINT fk_rec_ing FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS suppliers (
  supplier_id INT AUTO_INCREMENT PRIMARY KEY,
  supplier_name VARCHAR(80) NOT NULL UNIQUE,
  phone VARCHAR(20)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS purchases (
  purchase_id INT AUTO_INCREMENT PRIMARY KEY,
  supplier_id INT NOT NULL,
  purchase_date DATE NOT NULL,
  invoice_no VARCHAR(40),
  CONSTRAINT fk_pur_sup FOREIGN KEY (supplier_id) REFERENCES suppliers(supplier_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS forecast_runs (
  run_id INT AUTO_INCREMENT PRIMARY KEY,
  target_date DATE NOT NULL,
  model_version VARCHAR(30) NOT NULL,
  training_end_date DATE NULL,
  created_by INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  is_synthetic TINYINT(1) NOT NULL DEFAULT 0,
  CONSTRAINT fk_run_user FOREIGN KEY (created_by) REFERENCES users(user_id),
  INDEX ix_run_target (target_date)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS forecast_recommendations (
  rec_id INT AUTO_INCREMENT PRIMARY KEY,
  run_id INT NOT NULL,
  item_id INT NOT NULL,
  target_date DATE NOT NULL,
  model_used VARCHAR(40) NOT NULL,
  predicted_demand DECIMAL(9,2) NULL,
  buffer_pct DECIMAL(5,3) NOT NULL DEFAULT 0,
  recommended_qty INT NULL CHECK (recommended_qty IS NULL OR recommended_qty >= 0),
  history_points INT NOT NULL DEFAULT 0,
  backtest_n INT NOT NULL DEFAULT 0,
  mae_baseline DECIMAL(9,3) NULL,
  mae_selected DECIMAL(9,3) NULL,
  expected_footfall INT NULL,
  inputs_json TEXT,
  explanation TEXT,
  status ENUM('pending','approved','adjusted','rejected','superseded','insufficient_data') NOT NULL DEFAULT 'pending',
  approved_qty INT NULL CHECK (approved_qty IS NULL OR approved_qty >= 0),
  reviewed_by INT NULL,
  reviewed_at DATETIME NULL,
  review_note VARCHAR(250),
  CONSTRAINT fk_fr_run FOREIGN KEY (run_id) REFERENCES forecast_runs(run_id),
  CONSTRAINT fk_fr_item FOREIGN KEY (item_id) REFERENCES menu_items(item_id),
  CONSTRAINT fk_fr_user FOREIGN KEY (reviewed_by) REFERENCES users(user_id),
  INDEX ix_fr_target_item (target_date, item_id, status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS prep_batches (
  batch_id INT AUTO_INCREMENT PRIMARY KEY,
  batch_code VARCHAR(40) NOT NULL UNIQUE,
  operating_date DATE NOT NULL,
  item_id INT NOT NULL,
  batch_no INT NOT NULL,
  station_id INT NOT NULL,
  prepared_at DATETIME NOT NULL,
  qty_prepared INT NOT NULL CHECK (qty_prepared > 0),
  unit_cost DECIMAL(8,2) NOT NULL CHECK (unit_cost >= 0),
  cost_source ENUM('recipe','manual','menu_estimate') NOT NULL,
  operator_id INT NULL,
  rec_id INT NULL,
  notes VARCHAR(250),
  is_synthetic TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT uq_batch_day UNIQUE (operating_date, item_id, batch_no),
  CONSTRAINT fk_b_item FOREIGN KEY (item_id) REFERENCES menu_items(item_id),
  CONSTRAINT fk_b_station FOREIGN KEY (station_id) REFERENCES stations(station_id),
  CONSTRAINT fk_b_user FOREIGN KEY (operator_id) REFERENCES users(user_id),
  CONSTRAINT fk_b_rec FOREIGN KEY (rec_id) REFERENCES forecast_recommendations(rec_id),
  INDEX ix_b_date_item (operating_date, item_id)
) ENGINE=InnoDB;

-- Stock is NEVER stored as an editable number: current stock = SUM(quantity_change).
CREATE TABLE IF NOT EXISTS inventory_movements (
  movement_id INT AUTO_INCREMENT PRIMARY KEY,
  ingredient_id INT NOT NULL,
  movement_type ENUM('purchase','usage','spoilage','adjustment') NOT NULL,
  quantity_change DECIMAL(12,3) NOT NULL,
  unit_cost DECIMAL(10,2) NOT NULL CHECK (unit_cost >= 0),
  movement_date DATE NOT NULL,
  expiry_date DATE NULL,
  purchase_id INT NULL,
  batch_id INT NULL,
  note VARCHAR(200),
  created_by INT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_move_sign CHECK (
    (movement_type = 'purchase' AND quantity_change > 0) OR
    (movement_type IN ('usage','spoilage') AND quantity_change < 0) OR
    (movement_type = 'adjustment' AND quantity_change <> 0)),
  CONSTRAINT fk_mov_ing FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id),
  CONSTRAINT fk_mov_pur FOREIGN KEY (purchase_id) REFERENCES purchases(purchase_id),
  CONSTRAINT fk_mov_batch FOREIGN KEY (batch_id) REFERENCES prep_batches(batch_id),
  CONSTRAINT fk_mov_user FOREIGN KEY (created_by) REFERENCES users(user_id),
  INDEX ix_mov_ing_date (ingredient_id, movement_date),
  INDEX ix_mov_type (movement_type)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS service_records (
  service_id INT AUTO_INCREMENT PRIMARY KEY,
  operating_date DATE NOT NULL,
  item_id INT NOT NULL,
  period_id INT NOT NULL,
  station_id INT NOT NULL,
  served_at DATETIME NOT NULL,
  portions_paid INT NOT NULL DEFAULT 0 CHECK (portions_paid >= 0),
  portions_complimentary INT NOT NULL DEFAULT 0 CHECK (portions_complimentary >= 0),
  unit_price DECIMAL(8,2) NOT NULL CHECK (unit_price >= 0),
  remaining_after INT NULL CHECK (remaining_after IS NULL OR remaining_after >= 0),
  sold_out_flag TINYINT(1) NOT NULL DEFAULT 0,
  source ENUM('manual','import','synthetic') NOT NULL DEFAULT 'manual',
  operator_id INT NULL,
  note VARCHAR(250),
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_served_any CHECK (portions_paid + portions_complimentary > 0 OR sold_out_flag = 1),
  CONSTRAINT uq_service_slot UNIQUE (operating_date, item_id, period_id, served_at),
  CONSTRAINT fk_s_item FOREIGN KEY (item_id) REFERENCES menu_items(item_id),
  CONSTRAINT fk_s_period FOREIGN KEY (period_id) REFERENCES service_periods(period_id),
  CONSTRAINT fk_s_station FOREIGN KEY (station_id) REFERENCES stations(station_id),
  CONSTRAINT fk_s_user FOREIGN KEY (operator_id) REFERENCES users(user_id),
  INDEX ix_s_date_item (operating_date, item_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS footfall (
  footfall_id INT AUTO_INCREMENT PRIMARY KEY,
  operating_date DATE NOT NULL,
  period_id INT NOT NULL,
  expected_count INT NULL CHECK (expected_count IS NULL OR expected_count >= 0),
  observed_count INT NULL CHECK (observed_count IS NULL OR observed_count >= 0),
  source ENUM('manual','import','synthetic') NOT NULL DEFAULT 'manual',
  note VARCHAR(250),
  CONSTRAINT uq_footfall UNIQUE (operating_date, period_id),
  CONSTRAINT fk_ff_period FOREIGN KEY (period_id) REFERENCES service_periods(period_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS weighing_records (
  weigh_id INT AUTO_INCREMENT PRIMARY KEY,
  operating_date DATE NOT NULL,
  item_id INT NOT NULL,
  batch_id INT NULL,
  station_id INT NOT NULL,
  scale_id VARCHAR(20) NOT NULL,
  weight_value DECIMAL(9,3) NOT NULL CHECK (weight_value > 0),
  unit_code VARCHAR(10) NOT NULL,
  weight_kg DECIMAL(9,3) NOT NULL CHECK (weight_kg > 0),
  food_condition ENUM('edible','not_edible') NOT NULL,
  reason_code ENUM('overproduction','low_demand','quality_issue','spillage','plate_return','other') NOT NULL,
  weighed_at DATETIME NOT NULL,
  operator_id INT NULL,
  note VARCHAR(250),
  is_synthetic TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_w_item FOREIGN KEY (item_id) REFERENCES menu_items(item_id),
  CONSTRAINT fk_w_batch FOREIGN KEY (batch_id) REFERENCES prep_batches(batch_id),
  CONSTRAINT fk_w_station FOREIGN KEY (station_id) REFERENCES stations(station_id),
  CONSTRAINT fk_w_unit FOREIGN KEY (unit_code) REFERENCES units(unit_code),
  CONSTRAINT fk_w_user FOREIGN KEY (operator_id) REFERENCES users(user_id),
  INDEX ix_w_date_item (operating_date, item_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS waste_dispositions (
  disposition_id INT AUTO_INCREMENT PRIMARY KEY,
  weigh_id INT NOT NULL,
  disposition_type ENUM('donated','discarded','retained','other_loss') NOT NULL,
  weight_kg DECIMAL(9,3) NOT NULL CHECK (weight_kg > 0),
  reason VARCHAR(200),
  decided_at DATETIME NOT NULL,
  station_id INT NOT NULL,
  operator_id INT NULL,
  CONSTRAINT fk_d_weigh FOREIGN KEY (weigh_id) REFERENCES weighing_records(weigh_id),
  CONSTRAINT fk_d_station FOREIGN KEY (station_id) REFERENCES stations(station_id),
  CONSTRAINT fk_d_user FOREIGN KEY (operator_id) REFERENCES users(user_id),
  INDEX ix_d_weigh (weigh_id),
  INDEX ix_d_type (disposition_type)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS donations (
  donation_id INT AUTO_INCREMENT PRIMARY KEY,
  disposition_id INT NOT NULL UNIQUE,
  recipient_name VARCHAR(100) NOT NULL,
  handed_over_at DATETIME NOT NULL,
  food_safety_checked TINYINT(1) NOT NULL CHECK (food_safety_checked = 1),
  note VARCHAR(250),
  CONSTRAINT fk_don_disp FOREIGN KEY (disposition_id) REFERENCES waste_dispositions(disposition_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS actual_outcomes (
  outcome_id INT AUTO_INCREMENT PRIMARY KEY,
  rec_id INT NOT NULL UNIQUE,
  target_date DATE NOT NULL,
  item_id INT NOT NULL,
  predicted_demand DECIMAL(9,2) NULL,
  recommended_qty INT NULL,
  approved_qty INT NULL,
  prepared_qty INT NOT NULL,
  served_qty INT NOT NULL,
  actual_demand_est DECIMAL(9,2) NOT NULL,
  surplus_qty INT NOT NULL,
  discarded_portions_est DECIMAL(9,2) NOT NULL DEFAULT 0,
  shortage_flag TINYINT(1) NOT NULL DEFAULT 0,
  abs_error DECIMAL(9,2) NULL,
  evaluated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ao_rec FOREIGN KEY (rec_id) REFERENCES forecast_recommendations(rec_id),
  CONSTRAINT fk_ao_item FOREIGN KEY (item_id) REFERENCES menu_items(item_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS advisory_recommendations (
  adv_id INT AUTO_INCREMENT PRIMARY KEY,
  generated_on DATE NOT NULL,
  rule_code VARCHAR(40) NOT NULL,
  item_id INT NULL,
  ingredient_id INT NULL,
  problem VARCHAR(300) NOT NULL,
  metrics_json TEXT,
  proposed_action VARCHAR(300) NOT NULL,
  expected_benefit VARCHAR(250),
  confidence ENUM('low','medium','high') NOT NULL,
  limitations VARCHAR(300),
  status ENUM('open','approved','rejected','implemented','closed') NOT NULL DEFAULT 'open',
  reviewed_by INT NULL,
  reviewed_at DATETIME NULL,
  implemented_on DATE NULL,
  outcome_note VARCHAR(300),
  CONSTRAINT fk_adv_item FOREIGN KEY (item_id) REFERENCES menu_items(item_id),
  CONSTRAINT fk_adv_ing FOREIGN KEY (ingredient_id) REFERENCES ingredients(ingredient_id),
  CONSTRAINT fk_adv_user FOREIGN KEY (reviewed_by) REFERENCES users(user_id),
  INDEX ix_adv_status (status)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS audit_log (
  audit_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(40) NOT NULL,
  entity VARCHAR(40) NOT NULL,
  entity_id VARCHAR(40),
  details TEXT,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_user FOREIGN KEY (user_id) REFERENCES users(user_id),
  INDEX ix_audit_entity (entity, created_at)
) ENGINE=InnoDB;
