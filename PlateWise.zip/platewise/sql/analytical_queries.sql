-- Analytical queries. The Streamlit "SQL Reports" page runs each block that starts with "-- name:".
-- Covers JOIN, GROUP BY, HAVING, aggregate functions, subqueries and views.

-- name: highest_waste_items | Highest-waste menu items (JOIN + GROUP BY + HAVING)
SELECT item_name, category_name, SUM(prepared_portions) AS prepared,
       ROUND(SUM(discarded_portions_est), 1) AS discarded_portions_est,
       ROUND(SUM(discarded_portions_est) / SUM(prepared_portions) * 100, 2) AS waste_pct,
       ROUND(SUM(discarded_cost_est), 2) AS waste_cost_est
FROM v_daily_item_summary
GROUP BY item_name, category_name
HAVING SUM(prepared_portions) > 0
ORDER BY waste_pct DESC;

-- name: daily_waste_pct | Daily waste percentage
SELECT operating_date, SUM(prepared_portions) AS prepared, SUM(served_portions) AS served,
       ROUND(SUM(discarded_portions_est), 1) AS discarded_portions_est,
       ROUND(SUM(discarded_portions_est) / SUM(prepared_portions) * 100, 2) AS waste_pct
FROM v_daily_item_summary
GROUP BY operating_date
ORDER BY operating_date DESC
LIMIT 60;

-- name: weekday_demand | Weekday demand comparison (average portions served per day)
SELECT WEEKDAY(operating_date) AS weekday_no, DAYNAME(operating_date) AS weekday, item_name,
       ROUND(AVG(served_portions), 1) AS avg_served, ROUND(AVG(prepared_portions), 1) AS avg_prepared,
       COUNT(*) AS days_observed
FROM v_daily_item_summary
GROUP BY WEEKDAY(operating_date), DAYNAME(operating_date), item_name
ORDER BY item_name, weekday_no;

-- name: forecast_accuracy | Forecast-versus-actual accuracy per item (view + aggregates)
SELECT item_name, COUNT(*) AS forecasts, ROUND(AVG(abs_error), 2) AS mae_portions,
       ROUND(AVG(predicted_demand - actual_demand_est), 2) AS bias,
       ROUND(AVG(actual_demand_est), 1) AS avg_actual_demand
FROM v_forecast_vs_actual
WHERE predicted_demand IS NOT NULL
GROUP BY item_name
ORDER BY mae_portions DESC;

-- name: ingredient_spoilage | Ingredient spoilage cost
SELECT i.ingredient_name, i.unit_code,
       ROUND(SUM(-m.quantity_change), 2) AS spoiled_qty,
       ROUND(SUM(-m.quantity_change * m.unit_cost), 2) AS spoiled_cost
FROM inventory_movements m JOIN ingredients i ON i.ingredient_id = m.ingredient_id
WHERE m.movement_type = 'spoilage'
GROUP BY i.ingredient_name, i.unit_code
ORDER BY spoiled_cost DESC;

-- name: monthly_production_cost | Monthly production-cost trend
SELECT DATE_FORMAT(operating_date, '%Y-%m') AS month, SUM(prepared_portions) AS prepared_portions,
       ROUND(SUM(prep_cost_total), 2) AS production_cost,
       ROUND(SUM(prep_cost_total) / SUM(prepared_portions), 2) AS cost_per_portion
FROM v_daily_item_summary
GROUP BY DATE_FORMAT(operating_date, '%Y-%m')
ORDER BY month;

-- name: repeated_shortages | Items that repeatedly sold out (HAVING)
SELECT item_name, COUNT(*) AS days_prepared, SUM(sold_out_flag) AS sold_out_days,
       ROUND(SUM(sold_out_flag) / COUNT(*) * 100, 1) AS shortage_rate_pct
FROM v_daily_item_summary
GROUP BY item_name
HAVING SUM(sold_out_flag) >= 2
ORDER BY shortage_rate_pct DESC;

-- name: donation_quantities | Donation quantities by recipient (multi-table JOIN)
SELECT dn.recipient_name, COUNT(*) AS donations, ROUND(SUM(d.weight_kg), 2) AS total_kg,
       ROUND(SUM(d.weight_kg / mi.portion_weight_kg), 0) AS portions_est
FROM donations dn
JOIN waste_dispositions d ON d.disposition_id = dn.disposition_id
JOIN weighing_records w ON w.weigh_id = d.weigh_id
JOIN menu_items mi ON mi.item_id = w.item_id
GROUP BY dn.recipient_name
ORDER BY total_kg DESC;

-- name: variable_demand | Items with unusually variable demand (STDDEV / AVG)
SELECT item_name, ROUND(AVG(served_portions), 1) AS avg_served, ROUND(STDDEV_SAMP(served_portions), 1) AS std_dev,
       ROUND(STDDEV_SAMP(served_portions) / AVG(served_portions), 3) AS coeff_variation
FROM v_daily_item_summary
GROUP BY item_name
HAVING COUNT(*) >= 10
ORDER BY coeff_variation DESC;

-- name: recommendation_outcomes | Stored forecast recommendations and what happened
SELECT r.target_date, mi.item_name, r.model_used, r.status, r.predicted_demand, r.recommended_qty, r.approved_qty,
       o.prepared_qty, o.served_qty, o.surplus_qty, o.shortage_flag
FROM forecast_recommendations r
JOIN menu_items mi ON mi.item_id = r.item_id
LEFT JOIN actual_outcomes o ON o.rec_id = r.rec_id
WHERE r.status IN ('approved', 'adjusted')
ORDER BY r.target_date DESC
LIMIT 100;

-- name: above_average_waste | Items with waste% above the overall average (subquery)
SELECT item_name, ROUND(SUM(discarded_portions_est) / SUM(prepared_portions) * 100, 2) AS waste_pct
FROM v_daily_item_summary
GROUP BY item_name
HAVING SUM(discarded_portions_est) / SUM(prepared_portions) >
       (SELECT SUM(discarded_portions_est) / SUM(prepared_portions) FROM v_daily_item_summary)
ORDER BY waste_pct DESC;

-- name: reconciliation_exceptions | Days where counted and weighed quantities do not agree (subquery in FROM)
SELECT operating_date, item_name, prepared_portions, served_portions, expected_leftover_portions,
       ROUND(measured_portions_est, 1) AS measured_portions_est, ROUND(unexplained_portions_est, 1) AS unexplained_portions_est
FROM (SELECT * FROM v_daily_item_summary WHERE weigh_count > 0) x
WHERE ABS(unexplained_portions_est) > GREATEST(2, 0.05 * prepared_portions)
ORDER BY ABS(unexplained_portions_est) DESC
LIMIT 50;

-- name: current_stock_alerts | Current stock below reorder level (view)
SELECT ingredient_name, unit_code, ROUND(current_stock, 2) AS current_stock, reorder_level, last_purchase_date
FROM v_inventory_stock WHERE low_stock_flag = 1 ORDER BY ingredient_name;
