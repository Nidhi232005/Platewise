"""Zone A: preparation batches."""
from datetime import datetime

from analytics.cost_analysis import recipe_unit_cost
from analytics.metrics import allocate_served_fifo
from core import database as db
from core.security import require
from core.validation import ValidationError, positive_int, not_future, require_text
from services import common
from services.audit import log


def _recipe_rows(item_id, conn):
    return db.query_df("SELECT r.ingredient_id, r.qty_per_portion, i.cost_per_unit FROM recipe_ingredients r "
                       "JOIN ingredients i ON i.ingredient_id=r.ingredient_id WHERE r.item_id=:i", {"i": item_id}, conn)


def create_batch(user, operating_date, item_id, station_id, qty, prepared_at=None, manual_unit_cost=None,
                 notes="", rec_id=None, synthetic=False, skip_duplicate_guard=False) -> dict:
    """Record one batch. Several batches of the same item per day are allowed (batch_no 1, 2, ...)."""
    require(user, "prep.write")
    qty = positive_int(qty, "Quantity prepared", 5000)
    operating_date = not_future(common.to_date(operating_date), "Operating date")
    prepared_at = prepared_at or datetime.now()
    with db.transaction() as conn:
        item = common.get_item(int(item_id), conn)
        common.get_station(int(station_id), "prep", conn)
        if not skip_duplicate_guard and not db.query_df(
                "SELECT 1 FROM prep_batches WHERE operating_date=:d AND item_id=:i AND station_id=:s AND qty_prepared=:q "
                "AND created_at >= (NOW() - INTERVAL 60 SECOND)",
                {"d": operating_date, "i": int(item_id), "s": int(station_id), "q": qty}, conn).empty:
            raise ValidationError("An identical batch was just saved. If this is really a second batch, wait a minute or change the quantity.")
        recipe = _recipe_rows(int(item_id), conn)
        if manual_unit_cost not in (None, "", 0):
            cost, source = float(manual_unit_cost), "manual"
            if cost < 0:
                raise ValidationError("Cost cannot be negative.")
        elif not recipe.empty:
            cost, source = recipe_unit_cost(list(zip(recipe.qty_per_portion.astype(float), recipe.cost_per_unit.astype(float)))), "recipe"
        elif item["est_cost_per_portion"] is not None and item["est_cost_per_portion"] == item["est_cost_per_portion"]:
            cost, source = float(item["est_cost_per_portion"]), "menu_estimate"
        else:
            raise ValidationError("No cost available: add a recipe, an estimated cost on the menu item, or enter a manual cost.")
        batch_no = int(db.scalar("SELECT COALESCE(MAX(batch_no),0)+1 FROM prep_batches WHERE operating_date=:d AND item_id=:i",
                                 {"d": operating_date, "i": int(item_id)}, conn))
        code = f"B-{operating_date:%y%m%d}-{int(item_id):02d}-{batch_no}"
        bid = db.execute(
            "INSERT INTO prep_batches (batch_code, operating_date, item_id, batch_no, station_id, prepared_at, qty_prepared, "
            "unit_cost, cost_source, operator_id, rec_id, notes, is_synthetic) VALUES (:c,:d,:i,:n,:s,:t,:q,:u,:src,:o,:r,:no,:syn)",
            {"c": code, "d": operating_date, "i": int(item_id), "n": batch_no, "s": int(station_id), "t": prepared_at, "q": qty,
             "u": round(cost, 2), "src": source, "o": user["user_id"], "r": rec_id, "no": (notes or "")[:250], "syn": int(synthetic)}, conn).lastrowid
        for r in recipe.itertuples():
            db.execute("INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date, "
                       "batch_id, note, created_by) VALUES (:g,'usage',:q,:c,:d,:b,'recipe usage',:u)",
                       {"g": int(r.ingredient_id), "q": -round(float(r.qty_per_portion) * qty, 3), "c": float(r.cost_per_unit),
                        "d": operating_date, "b": bid, "u": user["user_id"]}, conn)
        log(conn, user["user_id"], "create", "prep_batch", bid, {"code": code, "qty": qty, "cost": cost, "cost_source": source})
    return {"batch_id": bid, "batch_code": code, "unit_cost": round(cost, 2), "cost_source": source}


def update_batch_qty(user, batch_id: int, new_qty, reason: str) -> None:
    """Correct a batch quantity (history kept in the audit log; ingredient usage is adjusted by the difference)."""
    require(user, "prep.write")
    new_qty = positive_int(new_qty, "New quantity", 5000)
    reason = require_text(reason, "Reason for change", 200)
    with db.transaction() as conn:
        b = db.query_df("SELECT * FROM prep_batches WHERE batch_id=:b", {"b": batch_id}, conn)
        if b.empty:
            raise ValidationError("Batch not found.")
        b = b.iloc[0]
        served = int(db.scalar("SELECT COALESCE(SUM(portions_paid+portions_complimentary),0) FROM service_records "
                               "WHERE operating_date=:d AND item_id=:i", {"d": b["operating_date"], "i": int(b["item_id"])}, conn))
        others = int(db.scalar("SELECT COALESCE(SUM(qty_prepared),0) FROM prep_batches WHERE operating_date=:d AND item_id=:i AND batch_id<>:b",
                               {"d": b["operating_date"], "i": int(b["item_id"]), "b": batch_id}, conn))
        if others + new_qty < served:
            raise ValidationError(f"Total prepared would be {others + new_qty}, below the {served} portions already served.")
        old = int(b["qty_prepared"])
        if new_qty == old:
            raise ValidationError("The quantity is unchanged.")
        db.execute("UPDATE prep_batches SET qty_prepared=:q WHERE batch_id=:b", {"q": new_qty, "b": batch_id}, conn)
        for r in _recipe_rows(int(b["item_id"]), conn).itertuples():
            delta = -round(float(r.qty_per_portion) * (new_qty - old), 3)
            if delta != 0:
                db.execute("INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date, "
                           "batch_id, note, created_by) VALUES (:g,:t,:q,:c,:d,:b,:n,:u)",
                           {"g": int(r.ingredient_id), "t": "usage" if delta < 0 else "adjustment", "q": delta,
                            "c": float(r.cost_per_unit), "d": b["operating_date"], "b": batch_id,
                            "n": f"batch qty corrected {old}->{new_qty}", "u": user["user_id"]}, conn)
        log(conn, user["user_id"], "update_qty", "prep_batch", batch_id, {"old": old, "new": new_qty, "reason": reason})


def list_batches(operating_date) -> list[dict]:
    df = db.query_df(
        "SELECT b.batch_id, b.batch_code, b.item_id, mi.item_name, b.batch_no, s.station_name, b.prepared_at, "
        "b.qty_prepared, b.unit_cost, b.cost_source, b.notes, b.is_synthetic FROM prep_batches b "
        "JOIN menu_items mi ON mi.item_id=b.item_id JOIN stations s ON s.station_id=b.station_id "
        "WHERE b.operating_date=:d ORDER BY b.prepared_at, b.batch_id", {"d": operating_date})
    served = db.query_df("SELECT item_id, SUM(portions_paid+portions_complimentary) AS served FROM service_records "
                         "WHERE operating_date=:d GROUP BY item_id", {"d": operating_date})
    served_map = {int(r.item_id): int(r.served) for r in served.itertuples()}
    out = []
    for item_id, g in df.groupby("item_id"):
        rows = g.to_dict("records")
        alloc = allocate_served_fifo(rows, served_map.get(int(item_id), 0))
        for r, a in zip(rows, alloc):
            r["served_allocated"] = a
            r["remaining"] = int(r["qty_prepared"]) - a
            out.append(r)
    return sorted(out, key=lambda r: r["prepared_at"])
