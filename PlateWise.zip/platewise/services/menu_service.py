"""Menu items, categories and recipes."""
from core import database as db
from core.security import require
from core.validation import (ValidationError, non_negative_number, positive_int, positive_number, require_text)
from services import common
from services.audit import log


def _dup(name, exclude=None):
    q = "SELECT item_id FROM menu_items WHERE LOWER(item_name)=LOWER(:n)"
    p = {"n": name}
    if exclude:
        q += " AND item_id<>:x"; p["x"] = exclude
    return not db.query_df(q, p).empty


def save_item(user, name, category_id, period_id, price, portion_weight_kg, weight_source,
              est_cost=None, rounding_step=5, item_id=None) -> int:
    require(user, "menu.write")
    name = require_text(name, "Item name", 80)
    price = non_negative_number(price, "Selling price", 10000)
    pw = positive_number(portion_weight_kg, "Portion weight (kg)", 5)
    src = require_text(weight_source, "Portion weight source", 200)
    est = None if est_cost in (None, "") else non_negative_number(est_cost, "Estimated cost", 10000)
    step = positive_int(rounding_step, "Rounding step", 100)
    if _dup(name, item_id):
        raise ValidationError("A menu item with this name already exists.")
    params = {"n": name, "c": int(category_id), "p": int(period_id), "pr": price, "pw": pw, "src": src, "e": est, "st": step}
    with db.transaction() as conn:
        if item_id:
            db.execute("UPDATE menu_items SET item_name=:n, category_id=:c, period_id=:p, selling_price=:pr, "
                       "portion_weight_kg=:pw, portion_weight_source=:src, est_cost_per_portion=:e, rounding_step=:st "
                       "WHERE item_id=:i", {**params, "i": item_id}, conn)
            log(conn, user["user_id"], "update", "menu_item", item_id, params)
            return item_id
        res = db.execute("INSERT INTO menu_items (item_name, category_id, period_id, selling_price, portion_weight_kg, "
                         "portion_weight_source, est_cost_per_portion, rounding_step) VALUES "
                         "(:n,:c,:p,:pr,:pw,:src,:e,:st)", params, conn)
        log(conn, user["user_id"], "create", "menu_item", res.lastrowid, params)
        return res.lastrowid


def set_active(user, item_id: int, active: bool) -> None:
    require(user, "menu.write")
    with db.transaction() as conn:
        db.execute("UPDATE menu_items SET is_active=:a WHERE item_id=:i", {"a": int(active), "i": item_id}, conn)
        log(conn, user["user_id"], "activate" if active else "deactivate", "menu_item", item_id, {})


def categories():
    return db.query_df("SELECT category_id, category_name FROM categories ORDER BY category_name")


def recipe(item_id: int):
    return db.query_df(
        "SELECT r.ingredient_id, i.ingredient_name, i.unit_code, r.qty_per_portion, i.cost_per_unit, "
        "r.qty_per_portion * i.cost_per_unit AS cost_per_portion FROM recipe_ingredients r "
        "JOIN ingredients i ON i.ingredient_id=r.ingredient_id WHERE r.item_id=:i ORDER BY i.ingredient_name", {"i": item_id})


def set_recipe_line(user, item_id: int, ingredient_id: int, qty_per_portion: float) -> None:
    require(user, "menu.write")
    q = positive_number(qty_per_portion, "Quantity per portion", 100)
    with db.transaction() as conn:
        db.execute("INSERT INTO recipe_ingredients (item_id, ingredient_id, qty_per_portion) VALUES (:i,:g,:q) "
                   "ON DUPLICATE KEY UPDATE qty_per_portion=:q", {"i": item_id, "g": ingredient_id, "q": q}, conn)
        log(conn, user["user_id"], "set_recipe", "menu_item", item_id, {"ingredient_id": ingredient_id, "qty": q})


def remove_recipe_line(user, item_id: int, ingredient_id: int) -> None:
    require(user, "menu.write")
    with db.transaction() as conn:
        db.execute("DELETE FROM recipe_ingredients WHERE item_id=:i AND ingredient_id=:g", {"i": item_id, "g": ingredient_id}, conn)
        log(conn, user["user_id"], "remove_recipe", "menu_item", item_id, {"ingredient_id": ingredient_id})


def item_history(item_id: int):
    return common.daily_summary(item_id=item_id)
