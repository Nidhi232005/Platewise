"""Ingredient store (Zone E): purchases, spoilage, adjustments, stock and expiry alerts."""
from datetime import timedelta

import pandas as pd

from analytics.inventory import expiry_alerts, fifo_remaining_lots
from core import database as db
from core.security import require
from core.validation import ValidationError, positive_int, positive_number, require_text
from services import common
from services.audit import log


def stock() -> pd.DataFrame:
    return db.query_df("SELECT * FROM v_inventory_stock ORDER BY ingredient_name")


def ingredients(active_only=True) -> pd.DataFrame:
    sql = "SELECT ingredient_id, ingredient_name, unit_code, cost_per_unit, reorder_level, shelf_life_days, is_active FROM ingredients"
    if active_only:
        sql += " WHERE is_active=1"
    return db.query_df(sql + " ORDER BY ingredient_name")


def suppliers() -> pd.DataFrame:
    return db.query_df("SELECT supplier_id, supplier_name, phone FROM suppliers ORDER BY supplier_name")


def add_supplier(user, name, phone="") -> int:
    require(user, "inventory.write")
    name = require_text(name, "Supplier name", 80)
    if not db.query_df("SELECT 1 FROM suppliers WHERE LOWER(supplier_name)=LOWER(:n)", {"n": name}).empty:
        raise ValidationError("Supplier already exists.")
    with db.transaction() as conn:
        res = db.execute("INSERT INTO suppliers (supplier_name, phone) VALUES (:n,:p)", {"n": name, "p": (phone or "")[:20]}, conn)
        log(conn, user["user_id"], "create", "supplier", res.lastrowid, {"name": name})
        return res.lastrowid


def add_ingredient(user, name, unit_code, cost_per_unit, reorder_level, shelf_life_days) -> int:
    require(user, "inventory.write")
    name = require_text(name, "Ingredient name", 80)
    cost = positive_number(cost_per_unit, "Cost per unit", 100000)
    reorder = float(reorder_level or 0)
    if reorder < 0:
        raise ValidationError("Reorder level cannot be negative.")
    life = positive_int(shelf_life_days, "Shelf life (days)", 3650)
    if not db.query_df("SELECT 1 FROM ingredients WHERE LOWER(ingredient_name)=LOWER(:n)", {"n": name}).empty:
        raise ValidationError("Ingredient already exists.")
    with db.transaction() as conn:
        res = db.execute("INSERT INTO ingredients (ingredient_name, unit_code, cost_per_unit, reorder_level, shelf_life_days) "
                         "VALUES (:n,:u,:c,:r,:l)", {"n": name, "u": unit_code, "c": cost, "r": reorder, "l": life}, conn)
        log(conn, user["user_id"], "create", "ingredient", res.lastrowid, {"name": name})
        return res.lastrowid


def _convert(conn, qty: float, from_unit: str, ingredient_id: int) -> float:
    """Convert qty entered in from_unit to the ingredient's own unit (same unit type required)."""
    df = db.query_df(
        "SELECT i.unit_code AS iu, ui.unit_type AS it, ui.to_base_factor AS ib, uf.unit_type AS ft, uf.to_base_factor AS fb "
        "FROM ingredients i JOIN units ui ON ui.unit_code=i.unit_code JOIN units uf ON uf.unit_code=:f "
        "WHERE i.ingredient_id=:g", {"g": ingredient_id, "f": from_unit}, conn)
    if df.empty:
        raise ValidationError("Unknown ingredient or unit.")
    r = df.iloc[0]
    if r["it"] != r["ft"]:
        raise ValidationError(f"Cannot convert {from_unit} into {r['iu']} (different measurement types).")
    return qty * float(r["fb"]) / float(r["ib"])


def receive_stock(user, ingredient_id, qty, unit, unit_cost, received_on, supplier_id, invoice_no="", expiry_date=None) -> int:
    require(user, "inventory.write")
    qty = positive_number(qty, "Quantity", 1_000_000)
    cost = positive_number(unit_cost, "Unit cost", 100000)
    with db.transaction() as conn:
        q = _convert(conn, qty, unit, int(ingredient_id))
        if expiry_date is None:
            life = int(db.scalar("SELECT shelf_life_days FROM ingredients WHERE ingredient_id=:i", {"i": int(ingredient_id)}, conn))
            expiry_date = received_on + timedelta(days=life)
        if expiry_date < received_on:
            raise ValidationError("Expiry date cannot be before the received date.")
        pid = db.execute("INSERT INTO purchases (supplier_id, purchase_date, invoice_no) VALUES (:s,:d,:n)",
                         {"s": int(supplier_id), "d": received_on, "n": (invoice_no or "")[:40]}, conn).lastrowid
        mid = db.execute(
            "INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date, "
            "expiry_date, purchase_id, created_by, note) VALUES (:g,'purchase',:q,:c,:d,:x,:p,:u,'stock received')",
            {"g": int(ingredient_id), "q": q, "c": cost, "d": received_on, "x": expiry_date, "p": pid, "u": user["user_id"]}, conn).lastrowid
        db.execute("UPDATE ingredients SET cost_per_unit=:c WHERE ingredient_id=:g", {"c": cost, "g": int(ingredient_id)}, conn)
        log(conn, user["user_id"], "purchase", "inventory", mid, {"ingredient_id": int(ingredient_id), "qty": q, "unit_cost": cost})
        return mid


def record_spoilage(user, ingredient_id, qty, unit, on_date, note="") -> int:
    require(user, "inventory.write")
    qty = positive_number(qty, "Spoiled quantity", 1_000_000)
    with db.transaction() as conn:
        q = _convert(conn, qty, unit, int(ingredient_id))
        cur = float(db.scalar("SELECT COALESCE(SUM(quantity_change),0) FROM inventory_movements WHERE ingredient_id=:g", {"g": int(ingredient_id)}, conn))
        if q > cur + 1e-9:
            raise ValidationError(f"Spoilage ({q:.2f}) is more than the stock on record ({cur:.2f}).")
        cost = float(db.scalar("SELECT cost_per_unit FROM ingredients WHERE ingredient_id=:g", {"g": int(ingredient_id)}, conn))
        mid = db.execute("INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date, "
                         "note, created_by) VALUES (:g,'spoilage',:q,:c,:d,:n,:u)",
                         {"g": int(ingredient_id), "q": -q, "c": cost, "d": on_date, "n": (note or "spoilage")[:200], "u": user["user_id"]}, conn).lastrowid
        log(conn, user["user_id"], "spoilage", "inventory", mid, {"ingredient_id": int(ingredient_id), "qty": q})
        return mid


def adjust_stock(user, ingredient_id, change, on_date, reason) -> int:
    """Stock-count correction (positive or negative). Reason is mandatory and audited."""
    require(user, "inventory.write")
    reason = require_text(reason, "Reason", 200)
    try:
        change = float(change)
    except (TypeError, ValueError):
        raise ValidationError("Adjustment must be a number.")
    if change == 0:
        raise ValidationError("Adjustment cannot be zero.")
    with db.transaction() as conn:
        cost = float(db.scalar("SELECT cost_per_unit FROM ingredients WHERE ingredient_id=:g", {"g": int(ingredient_id)}, conn))
        mid = db.execute("INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date, "
                         "note, created_by) VALUES (:g,'adjustment',:q,:c,:d,:n,:u)",
                         {"g": int(ingredient_id), "q": change, "c": cost, "d": on_date, "n": reason, "u": user["user_id"]}, conn).lastrowid
        log(conn, user["user_id"], "adjust", "inventory", mid, {"ingredient_id": int(ingredient_id), "change": change, "reason": reason})
        return mid


def movements(limit=300) -> pd.DataFrame:
    return db.query_df(
        "SELECT m.movement_id, m.movement_date, i.ingredient_name, m.movement_type, m.quantity_change, i.unit_code, "
        "m.unit_cost, m.expiry_date, m.note FROM inventory_movements m JOIN ingredients i ON i.ingredient_id=m.ingredient_id "
        "ORDER BY m.movement_date DESC, m.movement_id DESC LIMIT :n", {"n": int(limit)})


def expiry_watch(as_of) -> pd.DataFrame:
    mv = db.query_df("SELECT movement_id, ingredient_id, movement_type, quantity_change, movement_date, expiry_date "
                     "FROM inventory_movements WHERE movement_date <= :d", {"d": as_of})
    lots = fifo_remaining_lots(mv)
    al = expiry_alerts(lots, as_of, common.settings()["expiry_days"])
    if al.empty:
        return al
    names = ingredients(False)[["ingredient_id", "ingredient_name", "unit_code"]]
    return al.merge(names, on="ingredient_id", how="left")


def spoilage_vs_purchases(start=None, end=None) -> pd.DataFrame:
    sql = ("SELECT i.ingredient_id, i.ingredient_name, "
           "COALESCE(SUM(CASE WHEN m.movement_type='purchase' THEN m.quantity_change*m.unit_cost END),0) AS purchased_cost, "
           "COALESCE(SUM(CASE WHEN m.movement_type='spoilage' THEN -m.quantity_change*m.unit_cost END),0) AS spoiled_cost, "
           "COALESCE(SUM(CASE WHEN m.movement_type='usage' THEN -m.quantity_change*m.unit_cost END),0) AS used_cost "
           "FROM ingredients i LEFT JOIN inventory_movements m ON m.ingredient_id=i.ingredient_id "
           "AND (:s IS NULL OR m.movement_date>=:s) AND (:e IS NULL OR m.movement_date<=:e) "
           "GROUP BY i.ingredient_id, i.ingredient_name ORDER BY spoiled_cost DESC")
    return db.query_df(sql, {"s": start, "e": end})
