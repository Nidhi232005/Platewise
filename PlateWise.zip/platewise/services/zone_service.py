"""Live status of the five physical zones for the Zone Map page."""
import pandas as pd

from core import database as db
from services import common, inventory_service, waste_service


def zone_status(op_date) -> list[dict]:
    st = common.settings()
    d = common.daily_summary(op_date, op_date)
    zones = []
    prepared = int(d["prepared_portions"].sum()) if not d.empty else 0
    served = int(d["served_portions"].sum()) if not d.empty else 0
    batches = int(d["batches"].sum()) if not d.empty else 0

    # Zone A - tasks: approved quantity exists but no batch yet
    appr = db.query_df("SELECT r.item_id, mi.item_name, COALESCE(r.approved_qty,r.recommended_qty) AS qty FROM forecast_recommendations r "
                       "JOIN menu_items mi ON mi.item_id=r.item_id WHERE r.target_date=:d AND r.status IN ('approved','adjusted')", {"d": op_date})
    prepped_ids = set(d["item_id"]) if not d.empty else set()
    a_alerts = [f"Approved plan not started: {r.item_name} ({int(r.qty)} portions)" for r in appr.itertuples() if r.item_id not in prepped_ids]
    zones.append({"code": "A", "name": "Preparation Bay", "icon": "🍳", "activity": f"{batches} batches active" if batches else "No batches yet",
                  "count": batches, "quantities": [("Prepared", prepared, "portions")], "alerts": a_alerts,
                  "detail": d[["item_name", "batches", "prepared_portions"]] if not d.empty else pd.DataFrame()})
    # Zone B
    b_alerts = []
    if not d.empty:
        b_alerts += [f"No service recorded: {r.item_name}" for r in d[d["served_portions"] == 0].itertuples()]
        b_alerts += [f"Sold out: {r.item_name}" for r in d[d["sold_out_flag"] > 0].itertuples()]
    zones.append({"code": "B", "name": "Service Counter", "icon": "🍽", "activity": f"{served} portions served" if served else "Service not started",
                  "count": int((d["served_portions"] > 0).sum()) if not d.empty else 0,
                  "quantities": [("Served", served, "portions"), ("Remaining", prepared - served, "portions")], "alerts": b_alerts,
                  "detail": d[["item_name", "prepared_portions", "served_portions", "expected_leftover_portions"]] if not d.empty else pd.DataFrame()})
    # Zone C
    c_alerts = []
    wkg = float(d["measured_kg"].sum()) if not d.empty else 0.0
    if not d.empty:
        for r in d.itertuples():
            if r.recon_status == "not_weighed":
                c_alerts.append(f"Leftover not weighed: {r.item_name} (~{r.expected_leftover_portions} portions)")
            elif r.recon_status in ("unexplained_loss", "over_measured", "invalid_counts"):
                c_alerts.append(f"Discrepancy to explain: {r.item_name} ({r.recon_status.replace('_', ' ')})")
    zones.append({"code": "C", "name": "Weigh & Return", "icon": "⚖", "activity": f"{int(d['weigh_count'].sum()) if not d.empty else 0} weighings",
                  "count": int(d["weigh_count"].sum()) if not d.empty else 0, "quantities": [("Weighed", round(wkg, 2), "kg")], "alerts": c_alerts,
                  "detail": d[["item_name", "measured_kg", "measured_portions_est", "unexplained_portions_est", "recon_status"]] if not d.empty else pd.DataFrame()})
    # Zone D
    pend = waste_service.pending_dispositions(op_date)
    donated = float(d["donated_kg"].sum()) if not d.empty else 0.0
    discarded = float(d["discarded_kg"].sum()) if not d.empty else 0.0
    retained = float(d["retained_kg"].sum()) if not d.empty else 0.0
    zones.append({"code": "D", "name": "Surplus Handling", "icon": "🤝", "activity": f"{len(pend)} awaiting decision" if len(pend) else "All handled",
                  "count": int(len(pend)), "quantities": [("Donated", round(donated, 2), "kg"), ("Discarded", round(discarded, 2), "kg"), ("Retained", round(retained, 2), "kg")],
                  "alerts": [f"Awaiting disposition: {r.item_name} ({r.unallocated_kg:.2f} kg)" for r in pend.itertuples()],
                  "detail": d[["item_name", "donated_kg", "discarded_kg", "retained_kg", "disposition_status"]] if not d.empty else pd.DataFrame()})
    # Zone E
    stock = inventory_service.stock()
    low = stock[stock["low_stock_flag"] == 1] if not stock.empty else stock
    exp = inventory_service.expiry_watch(op_date)
    e_alerts = [f"Low stock: {r.ingredient_name} ({r.current_stock:.1f} {r.unit_code})" for r in low.itertuples()]
    e_alerts += [f"{'Expired' if r.alert == 'expired' else 'Expiring'}: {r.ingredient_name} ({r.remaining_qty:.1f} {r.unit_code}, {r.days_to_expiry} days)" for r in exp.itertuples()]
    zones.append({"code": "E", "name": "Ingredient Store", "icon": "📦", "activity": f"{len(stock)} ingredients tracked",
                  "count": len(e_alerts), "quantities": [("Low stock", int(len(low)), "items"), ("Expiry alerts", int(len(exp)), "lots")],
                  "alerts": e_alerts, "detail": stock[["ingredient_name", "current_stock", "unit_code", "reorder_level"]] if not stock.empty else pd.DataFrame()})
    return zones
