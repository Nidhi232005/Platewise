"""Shared lookups and typed settings."""
from datetime import date, datetime

import pandas as pd

from core import database as db
from core.validation import ValidationError


def settings() -> dict:
    s = db.get_settings()
    return {
        "canteen_name": s.get("canteen_name", "PlateWise Canteen"),
        "currency": s.get("currency_symbol", "Rs "),
        "operating_days": [int(x) for x in s.get("operating_days", "0,1,2,3,4,5").split(",") if x != ""],
        "buffer": float(s.get("buffer_pct", 0.05)),
        "buffer_after_shortage": float(s.get("buffer_pct_after_shortage", 0.10)),
        "sold_out_uplift": float(s.get("sold_out_uplift", 0.10)),
        "tol_portions": float(s.get("recon_tolerance_portions", 2)),
        "tol_pct": float(s.get("recon_tolerance_pct", 0.05)),
        "min_obs": int(s.get("min_history_obs", 8)),
        "k": int(s.get("same_weekday_k", 4)),
        "backtest_days": int(s.get("backtest_days", 14)),
        "improvement_threshold": float(s.get("model_improvement_threshold", 0.05)),
        "expiry_days": int(s.get("low_stock_expiry_days", 3)),
        "safety_mult": float(s.get("safety_mae_multiplier", 1.0)),
        "model_version": s.get("model_version", "pw-forecast-1.0"),
    }


def forecast_cfg(st: dict | None = None) -> dict:
    st = st or settings()
    return {"k": st["k"], "min_obs": st["min_obs"], "backtest_days": st["backtest_days"],
            "improvement_threshold": st["improvement_threshold"], "buffer": st["buffer"],
            "buffer_after_shortage": st["buffer_after_shortage"],
            "safety_mae_multiplier": st["safety_mult"]}


def items(active_only: bool = True) -> pd.DataFrame:
    sql = ("SELECT mi.item_id, mi.item_name, c.category_name, sp.period_name, mi.period_id, mi.selling_price, "
           "mi.portion_weight_kg, mi.portion_weight_source, mi.est_cost_per_portion, mi.rounding_step, mi.is_active "
           "FROM menu_items mi JOIN categories c ON c.category_id=mi.category_id "
           "JOIN service_periods sp ON sp.period_id=mi.period_id")
    if active_only:
        sql += " WHERE mi.is_active=1"
    return db.query_df(sql + " ORDER BY sp.start_time, mi.item_name")


def stations(station_type: str | None = None) -> pd.DataFrame:
    sql = ("SELECT s.station_id, s.station_code, s.station_name, s.station_type, z.zone_code, z.zone_name "
           "FROM stations s JOIN zones z ON z.zone_id=s.zone_id WHERE s.is_active=1")
    params = {}
    if station_type:
        sql += " AND s.station_type=:t"
        params["t"] = station_type
    return db.query_df(sql + " ORDER BY s.station_code", params)


def periods() -> pd.DataFrame:
    return db.query_df("SELECT period_id, period_name, start_time, end_time FROM service_periods ORDER BY start_time")


def get_station(station_id: int, station_type: str, conn=None) -> dict:
    df = db.query_df("SELECT station_id, station_code, station_type FROM stations WHERE station_id=:i AND is_active=1",
                     {"i": station_id}, conn)
    if df.empty or df.iloc[0]["station_type"] != station_type:
        raise ValidationError(f"Select a valid {station_type} station.")
    return df.iloc[0].to_dict()


def get_item(item_id: int, conn=None) -> dict:
    df = db.query_df("SELECT * FROM menu_items WHERE item_id=:i AND is_active=1", {"i": item_id}, conn)
    if df.empty:
        raise ValidationError("Menu item not found or inactive.")
    return df.iloc[0].to_dict()


def to_date(d) -> date:
    return d.date() if isinstance(d, datetime) else d


def daily_summary(start=None, end=None, category: str | None = None, item_id: int | None = None) -> pd.DataFrame:
    """Rows of v_daily_item_summary + reconciliation status (single source for KPIs and exports)."""
    from analytics.metrics import reconcile_frame
    sql = "SELECT * FROM v_daily_item_summary WHERE 1=1"
    p = {}
    if start:
        sql += " AND operating_date >= :s"; p["s"] = start
    if end:
        sql += " AND operating_date <= :e"; p["e"] = end
    if category and category != "All":
        sql += " AND category_name = :c"; p["c"] = category
    if item_id:
        sql += " AND item_id = :i"; p["i"] = item_id
    df = db.query_df(sql + " ORDER BY operating_date, item_name", p)
    if df.empty:
        return df.assign(recon_status=[], disposition_status=[])
    st = settings()
    return reconcile_frame(df, st["tol_portions"], st["tol_pct"])
