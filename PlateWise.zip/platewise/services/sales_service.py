"""Zone B: service counter records and footfall."""
from datetime import datetime

from core import database as db
from core.security import require
from core.validation import ValidationError, non_negative_int, not_future
from services import common
from services.audit import log


def record_service(user, operating_date, item_id, period_id, station_id, paid, complimentary=0, served_at=None,
                   unit_price=None, sold_out=False, note="", source="manual") -> dict:
    """Record portions served. paid = sold for money, complimentary = free meals (kept separate; never double counted).
    A serving cannot exceed what has been prepared so far on that date."""
    require(user, "service.write")
    paid = non_negative_int(paid, "Paid portions", 5000)
    comp = non_negative_int(complimentary, "Complimentary portions", 5000)
    if paid + comp == 0 and not sold_out:
        raise ValidationError("Enter at least one portion, or mark the item as sold out.")
    operating_date = not_future(common.to_date(operating_date), "Operating date")
    served_at = served_at or datetime.now()
    with db.transaction() as conn:
        item = common.get_item(int(item_id), conn)
        common.get_station(int(station_id), "counter", conn)
        prepared = int(db.scalar("SELECT COALESCE(SUM(qty_prepared),0) FROM prep_batches WHERE operating_date=:d AND item_id=:i",
                                 {"d": operating_date, "i": int(item_id)}, conn))
        if prepared == 0:
            raise ValidationError("No preparation batch exists for this item on this date. Record the batch first.")
        if not db.query_df("SELECT 1 FROM service_records WHERE operating_date=:d AND item_id=:i AND period_id=:p "
                           "AND portions_paid=:a AND portions_complimentary=:c AND created_at >= (NOW() - INTERVAL 60 SECOND)",
                           {"d": operating_date, "i": int(item_id), "p": int(period_id), "a": paid, "c": comp}, conn).empty:
            raise ValidationError("An identical service entry was just saved (possible double entry).")
        already = int(db.scalar("SELECT COALESCE(SUM(portions_paid+portions_complimentary),0) FROM service_records "
                                "WHERE operating_date=:d AND item_id=:i", {"d": operating_date, "i": int(item_id)}, conn))
        if already + paid + comp > prepared:
            raise ValidationError(f"Served would be {already + paid + comp}, more than the {prepared} prepared. "
                                  f"Record the missing batch or correct the number.")
        price = float(item["selling_price"]) if unit_price in (None, "") else float(unit_price)
        if price < 0:
            raise ValidationError("Price cannot be negative.")
        remaining = prepared - already - paid - comp
        try:
            sid = db.execute(
                "INSERT INTO service_records (operating_date, item_id, period_id, station_id, served_at, portions_paid, "
                "portions_complimentary, unit_price, remaining_after, sold_out_flag, source, operator_id, note) "
                "VALUES (:d,:i,:p,:s,:t,:a,:c,:pr,:r,:so,:src,:o,:n)",
                {"d": operating_date, "i": int(item_id), "p": int(period_id), "s": int(station_id), "t": served_at, "a": paid,
                 "c": comp, "pr": price, "r": remaining, "so": int(bool(sold_out)), "src": source, "o": user["user_id"],
                 "n": (note or "")[:250]}, conn).lastrowid
        except Exception as exc:  # unique slot violation
            if "uq_service_slot" in str(exc) or "Duplicate" in str(exc):
                raise ValidationError("A service entry with the same item, period and time already exists.")
            raise
        log(conn, user["user_id"], "create", "service_record", sid, {"item_id": int(item_id), "paid": paid, "comp": comp, "sold_out": bool(sold_out)})
    return {"service_id": sid, "remaining": remaining}


def record_footfall(user, operating_date, period_id, observed=None, expected=None, note="", source="manual") -> None:
    """Footfall is approximate. 'expected' is what is known BEFORE service (usable by the forecaster);
    'observed' is counted afterwards (used only as history)."""
    require(user, "service.write")
    operating_date = common.to_date(operating_date)
    obs = None if observed in (None, "") else non_negative_int(observed, "Observed footfall", 100000)
    exp = None if expected in (None, "") else non_negative_int(expected, "Expected footfall", 100000)
    if obs is None and exp is None:
        raise ValidationError("Enter an observed and/or an expected footfall count.")
    with db.transaction() as conn:
        db.execute(
            "INSERT INTO footfall (operating_date, period_id, expected_count, observed_count, source, note) "
            "VALUES (:d,:p,:e,:o,:s,:n) ON DUPLICATE KEY UPDATE "
            "expected_count=COALESCE(:e, expected_count), observed_count=COALESCE(:o, observed_count), note=:n",
            {"d": operating_date, "p": int(period_id), "e": exp, "o": obs, "s": source, "n": (note or "")[:250]}, conn)
        log(conn, user["user_id"], "upsert", "footfall", f"{operating_date}/{period_id}", {"observed": obs, "expected": exp})


def service_log(operating_date):
    return db.query_df(
        "SELECT sr.served_at, mi.item_name, sp.period_name, sr.portions_paid, sr.portions_complimentary, sr.unit_price, "
        "sr.remaining_after, sr.sold_out_flag FROM service_records sr JOIN menu_items mi ON mi.item_id=sr.item_id "
        "JOIN service_periods sp ON sp.period_id=sr.period_id WHERE sr.operating_date=:d ORDER BY sr.served_at DESC",
        {"d": operating_date})


def footfall_for(operating_date):
    return db.query_df("SELECT sp.period_name, f.expected_count, f.observed_count FROM footfall f "
                       "JOIN service_periods sp ON sp.period_id=f.period_id WHERE f.operating_date=:d ORDER BY sp.start_time",
                       {"d": operating_date})
