"""Advisory recommendations (rule-based decision engine) with manager review and measured outcome."""
import json
from datetime import date

import pandas as pd

from analytics import decisions
from analytics.cost_analysis import before_after
from core import database as db
from core.security import require
from core.validation import ValidationError, one_of, require_text
from services import common, inventory_service
from services.audit import log


def generate(user, as_of=None) -> int:
    """Run the decision rules on recent data and store NEW recommendations (no duplicates of open ones)."""
    require(user, "forecast.run")
    as_of = as_of or date.today()
    daily = common.daily_summary(end=as_of)
    spoil = inventory_service.spoilage_vs_purchases(None, as_of)
    found = decisions.generate(daily, spoil, as_of)
    added = 0
    with db.transaction() as conn:
        for r in found:
            dup = db.query_df(
                "SELECT 1 FROM advisory_recommendations WHERE rule_code=:r AND status IN ('open','approved','implemented') "
                "AND ((item_id=:i) OR (item_id IS NULL AND :i IS NULL)) AND ((ingredient_id=:g) OR (ingredient_id IS NULL AND :g IS NULL))",
                {"r": r["rule_code"], "i": r["item_id"], "g": r["ingredient_id"]}, conn)
            if not dup.empty:
                continue
            aid = db.execute(
                "INSERT INTO advisory_recommendations (generated_on, rule_code, item_id, ingredient_id, problem, metrics_json, "
                "proposed_action, expected_benefit, confidence, limitations) VALUES (:g,:r,:i,:ing,:p,:m,:a,:b,:c,:l)",
                {"g": as_of, "r": r["rule_code"], "i": r["item_id"], "ing": r["ingredient_id"], "p": r["problem"][:300], "m": r["metrics_json"],
                 "a": r["proposed_action"][:300], "b": r["expected_benefit"][:250], "c": r["confidence"], "l": r["limitations"][:300]}, conn).lastrowid
            log(conn, user["user_id"], "create", "advisory", aid, {"rule": r["rule_code"]})
            added += 1
    return added


def listing(status: str | None = None) -> pd.DataFrame:
    sql = ("SELECT a.adv_id, a.generated_on, a.rule_code, COALESCE(mi.item_name, ing.ingredient_name) AS subject, a.item_id, "
           "a.problem, a.proposed_action, a.expected_benefit, a.confidence, a.limitations, a.status, a.implemented_on, a.outcome_note, a.metrics_json "
           "FROM advisory_recommendations a LEFT JOIN menu_items mi ON mi.item_id=a.item_id "
           "LEFT JOIN ingredients ing ON ing.ingredient_id=a.ingredient_id ")
    p = {}
    if status:
        sql += "WHERE a.status=:s "; p["s"] = status
    return db.query_df(sql + "ORDER BY a.adv_id DESC", p)


def review(user, adv_id: int, status: str, note: str = "", implemented_on=None) -> None:
    require(user, "recommendations.review")
    one_of(status, ["approved", "rejected", "implemented", "closed"], "Status")
    if status in ("rejected", "closed"):
        require_text(note, "A note", 300)
    if status == "implemented" and not implemented_on:
        raise ValidationError("Enter the date the change was implemented.")
    with db.transaction() as conn:
        if db.query_df("SELECT 1 FROM advisory_recommendations WHERE adv_id=:a", {"a": adv_id}, conn).empty:
            raise ValidationError("Recommendation not found.")
        db.execute("UPDATE advisory_recommendations SET status=:s, reviewed_by=:u, reviewed_at=NOW(), "
                   "implemented_on=COALESCE(:d, implemented_on), outcome_note=COALESCE(NULLIF(:n,''), outcome_note) WHERE adv_id=:a",
                   {"s": status, "u": user["user_id"], "d": implemented_on, "n": note[:300], "a": adv_id}, conn)
        log(conn, user["user_id"], status, "advisory", adv_id, {"note": note})


def measured_outcome(adv_id: int, window_days: int = 21) -> dict | None:
    """Before/after comparison for an implemented recommendation (descriptive, not proof of cause)."""
    r = db.query_df("SELECT item_id, implemented_on FROM advisory_recommendations WHERE adv_id=:a", {"a": adv_id})
    if r.empty or pd.isna(r.iloc[0]["implemented_on"]) or pd.isna(r.iloc[0]["item_id"]):
        return None
    daily = common.daily_summary(item_id=int(r.iloc[0]["item_id"]))
    return before_after(daily, int(r.iloc[0]["item_id"]), r.iloc[0]["implemented_on"], window_days)
