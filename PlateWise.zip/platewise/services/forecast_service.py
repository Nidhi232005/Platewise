"""Demand planning: store forecasts, manager review, and evaluation against actual outcomes."""
import json
from datetime import date, timedelta

import pandas as pd

from analytics import forecasting as fc
from analytics.metrics import mae
from core import database as db
from core.security import require
from core.validation import ValidationError, non_negative_int, require_text
from services import common
from services.audit import log


def next_operating_day(after: date, operating_days: list[int]) -> date:
    d = after + timedelta(days=1)
    for _ in range(8):
        if d.weekday() in operating_days:
            return d
        d += timedelta(days=1)
    return after + timedelta(days=1)


def history_for_item(item_id: int, before_date, conn=None) -> pd.DataFrame:
    df = db.query_df(
        "SELECT v.operating_date, v.served_portions AS served, v.sold_out_flag AS sold_out, "
        "f.observed_count AS footfall_obs, f.expected_count AS footfall_exp "
        "FROM v_daily_item_summary v JOIN menu_items mi ON mi.item_id=v.item_id "
        "LEFT JOIN footfall f ON f.operating_date=v.operating_date AND f.period_id=mi.period_id "
        "WHERE v.item_id=:i AND v.operating_date < :d ORDER BY v.operating_date", {"i": item_id, "d": before_date}, conn)
    return df


def expected_footfall(item_id: int, target_date, conn=None):
    v = db.query_df("SELECT f.expected_count FROM footfall f JOIN menu_items mi ON mi.period_id=f.period_id "
                    "WHERE mi.item_id=:i AND f.operating_date=:d", {"i": item_id, "d": target_date}, conn)
    if v.empty or pd.isna(v.iloc[0, 0]):
        return None
    return int(v.iloc[0, 0])


def run_forecast(user, target_date, synthetic: bool = False, allow_past: bool = False) -> dict:
    """Generate recommendations for every active item for target_date (uses only data before that date)."""
    require(user, "forecast.run")
    st = common.settings()
    target = common.to_date(target_date)
    if target.weekday() not in st["operating_days"]:
        raise ValidationError("The canteen does not operate on that weekday (see operating_days setting).")
    if target < date.today() and not (allow_past or synthetic):
        raise ValidationError("Choose today or a future operating date for a new forecast.")
    cfg = common.forecast_cfg(st)
    created, skipped = 0, []
    with db.transaction() as conn:
        run_id = db.execute("INSERT INTO forecast_runs (target_date, model_version, training_end_date, created_by, is_synthetic) "
                            "VALUES (:t,:v,:e,:u,:s)", {"t": target, "v": st["model_version"], "e": target - timedelta(days=1),
                                                         "u": user["user_id"], "s": int(synthetic)}, conn).lastrowid
        for it in common.items().itertuples():
            existing = db.query_df("SELECT rec_id, status FROM forecast_recommendations WHERE target_date=:d AND item_id=:i "
                                   "AND status IN ('approved','adjusted')", {"d": target, "i": int(it.item_id)}, conn)
            if not existing.empty:
                skipped.append(it.item_name)
                continue
            hist = fc.prepare_history(history_for_item(int(it.item_id), target, conn), st["sold_out_uplift"])
            ef = expected_footfall(int(it.item_id), target, conn)
            cfg_i = {**cfg, "rounding_step": int(it.rounding_step)}
            res = fc.forecast_item(hist, target, ef, cfg_i)
            db.execute("UPDATE forecast_recommendations SET status='superseded' WHERE target_date=:d AND item_id=:i "
                       "AND status IN ('pending','insufficient_data')", {"d": target, "i": int(it.item_id)}, conn)
            status = "insufficient_data" if res["status"] == "insufficient_data" else "pending"
            rid = db.execute(
                "INSERT INTO forecast_recommendations (run_id, item_id, target_date, model_used, predicted_demand, buffer_pct, "
                "recommended_qty, history_points, backtest_n, mae_baseline, mae_selected, expected_footfall, inputs_json, explanation, status) "
                "VALUES (:r,:i,:d,:m,:p,:b,:q,:h,:bn,:mb,:ms,:ef,:inp,:ex,:st)",
                {"r": run_id, "i": int(it.item_id), "d": target, "m": res["model_used"], "p": res["predicted_demand"],
                 "b": res["buffer_pct"], "q": res["recommended_qty"], "h": res["history_points"], "bn": res["backtest_n"],
                 "mb": res["mae_baseline"], "ms": res["mae_selected"], "ef": ef,
                 "inp": json.dumps({"inputs": res["inputs"], "scores": res["model_scores"]}, default=float),
                 "ex": res["explanation"], "st": status}, conn).lastrowid
            created += 1
        log(conn, user["user_id"], "run_forecast", "forecast_run", run_id, {"target": str(target), "created": created, "skipped": skipped})
    return {"run_id": run_id, "created": created, "skipped_already_approved": skipped}


def review(user, rec_id: int, action: str, approved_qty=None, note: str = "") -> None:
    """action: approve | adjust | reject. The manager stays in control of the final quantity."""
    require(user, "forecast.review")
    if action not in ("approve", "adjust", "reject"):
        raise ValidationError("Unknown action.")
    with db.transaction() as conn:
        r = db.query_df("SELECT rec_id, status, recommended_qty FROM forecast_recommendations WHERE rec_id=:r", {"r": rec_id}, conn)
        if r.empty:
            raise ValidationError("Recommendation not found.")
        r = r.iloc[0]
        if r["status"] == "superseded":
            raise ValidationError("This recommendation was superseded by a newer run.")
        if action == "reject":
            qty, status = None, "rejected"
            require_text(note, "Reason for rejecting", 250)
        elif action == "approve":
            if pd.isna(r["recommended_qty"]):
                raise ValidationError("No quantity was recommended; use 'adjust' and enter a quantity.")
            qty, status = int(r["recommended_qty"]), "approved"
        else:
            qty = non_negative_int(approved_qty, "Approved quantity", 5000)
            status = "adjusted"
            require_text(note, "Reason for adjusting", 250)
        db.execute("UPDATE forecast_recommendations SET status=:s, approved_qty=:q, reviewed_by=:u, reviewed_at=NOW(), review_note=:n "
                   "WHERE rec_id=:r", {"s": status, "q": qty, "u": user["user_id"], "n": (note or "")[:250], "r": rec_id}, conn)
        log(conn, user["user_id"], action, "forecast_recommendation", rec_id, {"approved_qty": qty, "note": note})


def evaluate_outcomes(conn=None, up_to=None) -> int:
    """Compare stored forecasts with what actually happened (idempotent). Needs preparation and service records."""
    st = common.settings()
    uplift = st["sold_out_uplift"]
    df = db.query_df(
        "SELECT r.rec_id, r.target_date, r.item_id, r.predicted_demand, r.recommended_qty, r.approved_qty, "
        "v.prepared_portions, v.served_portions, v.sold_out_flag, v.discarded_portions_est "
        "FROM forecast_recommendations r JOIN v_daily_item_summary v ON v.item_id=r.item_id AND v.operating_date=r.target_date "
        "WHERE r.status IN ('approved','adjusted','pending','rejected') AND (v.served_portions>0 OR v.sold_out_flag=1) "
        "AND (:u IS NULL OR r.target_date <= :u)", {"u": up_to}, conn)
    def _write(c):
        n = 0
        for r in df.itertuples():
            actual = float(r.served_portions) * (1 + uplift if r.sold_out_flag else 1)
            err = None if pd.isna(r.predicted_demand) else abs(actual - float(r.predicted_demand))
            db.execute(
                "INSERT INTO actual_outcomes (rec_id, target_date, item_id, predicted_demand, recommended_qty, approved_qty, prepared_qty, "
                "served_qty, actual_demand_est, surplus_qty, discarded_portions_est, shortage_flag, abs_error) "
                "VALUES (:r,:d,:i,:p,:rq,:aq,:pq,:sq,:ad,:su,:di,:sh,:er) ON DUPLICATE KEY UPDATE prepared_qty=:pq, served_qty=:sq, "
                "actual_demand_est=:ad, surplus_qty=:su, discarded_portions_est=:di, shortage_flag=:sh, abs_error=:er, evaluated_at=NOW()",
                {"r": int(r.rec_id), "d": r.target_date, "i": int(r.item_id), "p": None if pd.isna(r.predicted_demand) else float(r.predicted_demand),
                 "rq": None if pd.isna(r.recommended_qty) else int(r.recommended_qty), "aq": None if pd.isna(r.approved_qty) else int(r.approved_qty),
                 "pq": int(r.prepared_portions), "sq": int(r.served_portions), "ad": round(actual, 2),
                 "su": int(r.prepared_portions - r.served_portions), "di": round(float(r.discarded_portions_est), 2),
                 "sh": int(r.sold_out_flag), "er": None if err is None else round(err, 2)}, c)
            n += 1
        return n
    if conn is not None:
        return _write(conn)
    with db.transaction() as c:
        return _write(c)


def pending_for(target_date) -> pd.DataFrame:
    return db.query_df(
        "SELECT r.rec_id, r.item_id, mi.item_name, sp.period_name, r.model_used, r.predicted_demand, r.recommended_qty, r.status, "
        "r.approved_qty, r.history_points, r.mae_baseline, r.mae_selected, r.expected_footfall, r.explanation "
        "FROM forecast_recommendations r JOIN menu_items mi ON mi.item_id=r.item_id JOIN service_periods sp ON sp.period_id=mi.period_id "
        "WHERE r.target_date=:d AND r.status <> 'superseded' ORDER BY sp.start_time, mi.item_name", {"d": target_date})


def accuracy_summary(start=None, end=None) -> pd.DataFrame:
    df = db.query_df("SELECT * FROM v_forecast_vs_actual WHERE predicted_demand IS NOT NULL "
                     "AND (:s IS NULL OR target_date>=:s) AND (:e IS NULL OR target_date<=:e)", {"s": start, "e": end})
    if df.empty:
        return df
    g = df.groupby("item_name").apply(lambda x: pd.Series({
        "forecasts": len(x), "mae": mae(x["actual_demand_est"], x["predicted_demand"]),
        "bias": float((x["predicted_demand"] - x["actual_demand_est"]).mean()),
        "avg_actual": float(x["actual_demand_est"].mean())}), include_groups=False).reset_index()
    return g.sort_values("mae", ascending=False)


def series_for_item(item_id: int, limit: int = 60) -> pd.DataFrame:
    return db.query_df("SELECT target_date, predicted_demand, actual_demand_est, recommended_qty, approved_qty, prepared_qty "
                       "FROM v_forecast_vs_actual WHERE item_id=:i ORDER BY target_date DESC LIMIT :n", {"i": item_id, "n": limit}).sort_values("target_date")
