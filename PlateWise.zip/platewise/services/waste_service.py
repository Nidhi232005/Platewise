"""Zones C and D: weighing leftovers and recording what happens to them."""
from datetime import datetime

from analytics.metrics import kg_to_portions, reconcile, to_kg
from core import database as db
from core.security import require
from core.validation import ValidationError, not_future, one_of, positive_number
from services import common
from services.audit import log

REASONS = ["overproduction", "low_demand", "quality_issue", "spillage", "plate_return", "other"]
DISPOSITIONS = ["donated", "discarded", "retained", "other_loss"]
TOL_KG = 0.0015


def _validate_dispositions(condition: str, total_kg: float, disps: list[dict]) -> None:
    used = 0.0
    for d in disps:
        one_of(d["type"], DISPOSITIONS, "Disposition")
        kg = positive_number(d["weight_kg"], "Disposition weight (kg)", 5000)
        used += kg
        if condition == "not_edible" and d["type"] in ("donated", "retained"):
            raise ValidationError("Food that is not edible cannot be donated or retained; it must be discarded.")
        if d["type"] == "donated":
            dn = d.get("donation") or {}
            if not (dn.get("recipient_name") or "").strip():
                raise ValidationError("A donation needs a recipient name.")
            if not dn.get("food_safety_checked"):
                raise ValidationError("Confirm the food-safety check before donating.")
    if used > total_kg + TOL_KG:
        raise ValidationError(f"Dispositions total {used:.3f} kg, more than the {total_kg:.3f} kg weighed.")


def _insert_disposition(conn, user, weigh_id, d, station_id, when):
    did = db.execute("INSERT INTO waste_dispositions (weigh_id, disposition_type, weight_kg, reason, decided_at, station_id, operator_id) "
                     "VALUES (:w,:t,:k,:r,:when,:s,:o)",
                     {"w": weigh_id, "t": d["type"], "k": float(d["weight_kg"]), "r": (d.get("reason") or "")[:200],
                      "when": when, "s": station_id, "o": user["user_id"]}, conn).lastrowid
    if d["type"] == "donated":
        dn = d["donation"]
        db.execute("INSERT INTO donations (disposition_id, recipient_name, handed_over_at, food_safety_checked, note) "
                   "VALUES (:i,:n,:t,1,:no)", {"i": did, "n": dn["recipient_name"].strip()[:100],
                                               "t": dn.get("handed_over_at") or when, "no": (dn.get("note") or "")[:250]}, conn)
    log(conn, user["user_id"], "create", "disposition", did, {"weigh_id": weigh_id, "type": d["type"], "kg": float(d["weight_kg"])})
    return did


def record_weighing(user, operating_date, item_id, scale_station_id, weight_value, unit, condition, reason_code,
                    dispositions=None, weighed_at=None, note="", surplus_station_id=None, synthetic=False) -> dict:
    """Weigh leftovers (measured, manual entry) and optionally record the disposition split in one transaction."""
    require(user, "waste.write")
    value = positive_number(weight_value, "Measured weight", 10000)
    one_of(condition, ["edible", "not_edible"], "Food condition")
    one_of(reason_code, REASONS, "Reason")
    try:
        kg = round(to_kg(value, unit), 3)
    except ValueError as exc:
        raise ValidationError(str(exc))
    if kg <= 0:
        raise ValidationError("Weight rounds to zero kg; enter a larger value.")
    operating_date = not_future(common.to_date(operating_date), "Operating date")
    weighed_at = weighed_at or datetime.now()
    dispositions = dispositions or []
    _validate_dispositions(condition, kg, dispositions)
    with db.transaction() as conn:
        item = common.get_item(int(item_id), conn)
        scale = common.get_station(int(scale_station_id), "scale", conn)
        prepared = int(db.scalar("SELECT COALESCE(SUM(qty_prepared),0) FROM prep_batches WHERE operating_date=:d AND item_id=:i",
                                 {"d": operating_date, "i": int(item_id)}, conn))
        if prepared == 0:
            raise ValidationError("No batch was prepared for this item on this date, so there is nothing to weigh.")
        pw = float(item["portion_weight_kg"])
        already = float(db.scalar("SELECT COALESCE(SUM(weight_kg),0) FROM weighing_records WHERE operating_date=:d AND item_id=:i",
                                  {"d": operating_date, "i": int(item_id)}, conn))
        if already + kg > prepared * pw * 1.5:
            raise ValidationError(f"Total weighed ({already + kg:.2f} kg) is implausibly high compared with {prepared} prepared portions "
                                  f"(about {prepared * pw:.1f} kg). Check the unit and that the container weight was removed (tare).")
        wid = db.execute(
            "INSERT INTO weighing_records (operating_date, item_id, station_id, scale_id, weight_value, unit_code, weight_kg, "
            "food_condition, reason_code, weighed_at, operator_id, note, is_synthetic) VALUES (:d,:i,:s,:sc,:v,:u,:k,:c,:r,:t,:o,:n,:syn)",
            {"d": operating_date, "i": int(item_id), "s": int(scale_station_id), "sc": scale["station_code"], "v": value, "u": unit,
             "k": kg, "c": condition, "r": reason_code, "t": weighed_at, "o": user["user_id"], "n": (note or "")[:250], "syn": int(synthetic)}, conn).lastrowid
        log(conn, user["user_id"], "create", "weighing", wid, {"item_id": int(item_id), "kg": kg, "condition": condition})
        if dispositions:
            sid = int(surplus_station_id) if surplus_station_id else int(common.stations("surplus").iloc[0]["station_id"])
            for d in dispositions:
                _insert_disposition(conn, user, wid, d, sid, weighed_at)
    return {"weigh_id": wid, "weight_kg": kg, "portions_est": round(kg_to_portions(kg, pw), 2),
            "reconciliation": item_reconciliation(operating_date, int(item_id))}


def add_disposition(user, weigh_id: int, dtype, weight_kg, reason="", donation=None, when=None) -> int:
    """Handle a weighing that is still pending: record donate/discard/retain later."""
    require(user, "waste.write")
    kg = positive_number(weight_kg, "Weight (kg)", 5000)
    with db.transaction() as conn:
        w = db.query_df("SELECT weigh_id, weight_kg, food_condition FROM weighing_records WHERE weigh_id=:w", {"w": weigh_id}, conn)
        if w.empty:
            raise ValidationError("Weighing record not found.")
        done = float(db.scalar("SELECT COALESCE(SUM(weight_kg),0) FROM waste_dispositions WHERE weigh_id=:w", {"w": weigh_id}, conn))
        if done + kg > float(w.iloc[0]["weight_kg"]) + TOL_KG:
            raise ValidationError(f"Only {float(w.iloc[0]['weight_kg']) - done:.3f} kg of this weighing is still unallocated.")
        d = {"type": dtype, "weight_kg": kg, "reason": reason, "donation": donation}
        _validate_dispositions(w.iloc[0]["food_condition"], float(w.iloc[0]["weight_kg"]) - done, [d])
        sid = int(common.stations("surplus").iloc[0]["station_id"])
        return _insert_disposition(conn, user, weigh_id, d, sid, when or datetime.now())


def item_reconciliation(operating_date, item_id) -> dict:
    df = common.daily_summary(operating_date, operating_date, item_id=item_id)
    if df.empty:
        return {"status": "no_batch"}
    r = df.iloc[0]
    st = common.settings()
    disposed = float(r.donated_kg + r.discarded_kg + r.retained_kg + r.other_loss_kg)
    res = reconcile(int(r.prepared_portions), int(r.served_portions), float(r.measured_kg) if r.weigh_count else None,
                    float(r.portion_weight_kg), disposed if r.weigh_count else None, st["tol_portions"], st["tol_pct"])
    res.update(prepared=int(r.prepared_portions), served=int(r.served_portions), measured_kg=float(r.measured_kg), disposed_kg=disposed)
    return res


def pending_dispositions(operating_date=None):
    sql = ("SELECT w.weigh_id, w.operating_date, mi.item_name, w.weight_kg, w.food_condition, "
           "w.weight_kg - COALESCE(SUM(d.weight_kg),0) AS unallocated_kg FROM weighing_records w "
           "JOIN menu_items mi ON mi.item_id=w.item_id LEFT JOIN waste_dispositions d ON d.weigh_id=w.weigh_id ")
    p = {}
    if operating_date:
        sql += "WHERE w.operating_date=:d "; p["d"] = operating_date
    sql += "GROUP BY w.weigh_id, w.operating_date, mi.item_name, w.weight_kg, w.food_condition HAVING unallocated_kg > 0.05 ORDER BY w.operating_date DESC"
    return db.query_df(sql, p)


def weighing_log(operating_date):
    return db.query_df(
        "SELECT w.weighed_at, mi.item_name, w.scale_id, w.weight_value, w.unit_code, w.weight_kg, w.food_condition, w.reason_code, "
        "COALESCE(SUM(CASE WHEN d.disposition_type='donated' THEN d.weight_kg END),0) AS donated_kg, "
        "COALESCE(SUM(CASE WHEN d.disposition_type='discarded' THEN d.weight_kg END),0) AS discarded_kg, "
        "COALESCE(SUM(CASE WHEN d.disposition_type='retained' THEN d.weight_kg END),0) AS retained_kg, "
        "COALESCE(SUM(CASE WHEN d.disposition_type='other_loss' THEN d.weight_kg END),0) AS other_loss_kg "
        "FROM weighing_records w JOIN menu_items mi ON mi.item_id=w.item_id "
        "LEFT JOIN waste_dispositions d ON d.weigh_id=w.weigh_id WHERE w.operating_date=:d "
        "GROUP BY w.weigh_id, w.weighed_at, mi.item_name, w.scale_id, w.weight_value, w.unit_code, w.weight_kg, w.food_condition, w.reason_code "
        "ORDER BY w.weighed_at DESC", {"d": operating_date})


def donations(start=None, end=None):
    return db.query_df(
        "SELECT dn.donation_id, dn.handed_over_at, dn.recipient_name, mi.item_name, d.weight_kg, "
        "d.weight_kg / mi.portion_weight_kg AS portions_est, dn.food_safety_checked FROM donations dn "
        "JOIN waste_dispositions d ON d.disposition_id=dn.disposition_id JOIN weighing_records w ON w.weigh_id=d.weigh_id "
        "JOIN menu_items mi ON mi.item_id=w.item_id WHERE (:s IS NULL OR w.operating_date>=:s) AND (:e IS NULL OR w.operating_date<=:e) "
        "ORDER BY dn.handed_over_at DESC", {"s": start, "e": end})
