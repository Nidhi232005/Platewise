"""Audit trail: every important change writes a row inside the same transaction."""
import json

from core import database as db


def log(conn, user_id, action: str, entity: str, entity_id, details: dict | None = None) -> None:
    db.execute(
        "INSERT INTO audit_log (user_id, action, entity, entity_id, details) VALUES (:u,:a,:e,:i,:d)",
        {"u": user_id, "a": action, "e": entity, "i": str(entity_id),
         "d": json.dumps(details or {}, default=str)[:4000]}, conn)


def recent(limit: int = 200, entity: str | None = None):
    sql = ("SELECT a.audit_id, a.created_at, COALESCE(u.username,'system') AS user, a.action, a.entity, "
           "a.entity_id, a.details FROM audit_log a LEFT JOIN users u ON u.user_id=a.user_id ")
    params = {"n": int(limit)}
    if entity:
        sql += "WHERE a.entity = :e "
        params["e"] = entity
    sql += "ORDER BY a.audit_id DESC LIMIT :n"
    return db.query_df(sql, params)
