"""Analysis-ready datasets used by the SQL report page, Excel and Tableau exports.
Every dataset is derived from the same views/tables so exported totals match MySQL."""
import re
from pathlib import Path

import pandas as pd

from core import database as db
from services import common

QUERY_FILE = db.SQL_DIR / "analytical_queries.sql"


def named_queries() -> dict:
    text = QUERY_FILE.read_text(encoding="utf-8")
    out = {}
    for block in re.split(r"(?m)^-- name:\s*", text)[1:]:
        header, _, body = block.partition("\n")
        key, _, title = header.partition("|")
        sql_lines = [ln for ln in body.splitlines() if not ln.strip().startswith("--")]
        out[key.strip()] = {"title": title.strip(), "sql": "\n".join(sql_lines).strip().rstrip(";")}
    return out


def run_named_query(key: str) -> pd.DataFrame:
    q = named_queries()
    if key not in q:
        raise KeyError(key)
    return db.query_df(q[key]["sql"])


def pivot_base(start=None, end=None) -> pd.DataFrame:
    """Flat, one-row-per (date, item) table: the PivotTable source."""
    d = common.daily_summary(start, end)
    if d.empty:
        return pd.DataFrame()
    dt = pd.to_datetime(d["operating_date"])
    out = pd.DataFrame({
        "Date": dt.dt.date, "Year": dt.dt.year, "Month": dt.dt.strftime("%Y-%m"), "WeekdayNo": dt.dt.weekday,
        "Weekday": dt.dt.day_name(), "Category": d["category_name"], "Item": d["item_name"], "Batches": d["batches"].astype(int),
        "Prepared_Portions": d["prepared_portions"].astype(int), "Paid_Portions": d["paid_portions"].astype(int),
        "Complimentary_Portions": d["comp_portions"].astype(int), "Served_Portions": d["served_portions"].astype(int),
        "Expected_Leftover_Portions": d["expected_leftover_portions"].astype(int), "SoldOut_Flag": d["sold_out_flag"].astype(int),
        "Measured_Leftover_Kg": d["measured_kg"].round(3), "Donated_Kg": d["donated_kg"].round(3),
        "Discarded_Kg": d["discarded_kg"].round(3), "Retained_Kg": d["retained_kg"].round(3), "Other_Loss_Kg": d["other_loss_kg"].round(3),
        "Measured_Leftover_Portions_Est": d["measured_portions_est"].round(2), "Donated_Portions_Est": d["donated_portions_est"].round(2),
        "Discarded_Portions_Est": d["discarded_portions_est"].round(2), "Unexplained_Portions_Est": d["unexplained_portions_est"].round(2),
        "Avg_Unit_Cost": d["avg_unit_cost"].round(2), "Production_Cost": d["prep_cost_total"].round(2),
        "Waste_Cost_Est": d["discarded_cost_est"].round(2), "Avoidable_Cost_Est": d["avoidable_cost_est"].round(2),
        "Donated_Value_Est": d["donated_value_est"].round(2), "Revenue": d["revenue"].round(2),
        "Recon_Status": d["recon_status"], "Disposition_Status": d["disposition_status"],
    })
    return out


def ds_prep_vs_served(start=None, end=None):
    b = pivot_base(start, end)
    return b[["Date", "Weekday", "Category", "Item", "Batches", "Prepared_Portions", "Paid_Portions", "Complimentary_Portions",
              "Served_Portions", "Expected_Leftover_Portions", "SoldOut_Flag"]] if not b.empty else b


def ds_waste_by_item(start=None, end=None):
    b = pivot_base(start, end)
    if b.empty:
        return b
    g = b.groupby(["Category", "Item"], as_index=False).agg(
        Days=("Date", "count"), Prepared_Portions=("Prepared_Portions", "sum"), Served_Portions=("Served_Portions", "sum"),
        Discarded_Kg=("Discarded_Kg", "sum"), Discarded_Portions_Est=("Discarded_Portions_Est", "sum"),
        Donated_Portions_Est=("Donated_Portions_Est", "sum"), Waste_Cost_Est=("Waste_Cost_Est", "sum"))
    g["Waste_Pct"] = (g["Discarded_Portions_Est"] / g["Prepared_Portions"] * 100).round(2)
    return g.round(2).sort_values("Waste_Pct", ascending=False)


def ds_waste_by_day(start=None, end=None):
    b = pivot_base(start, end)
    if b.empty:
        return b
    g = b.groupby(["Date", "Weekday"], as_index=False).agg(
        Prepared_Portions=("Prepared_Portions", "sum"), Served_Portions=("Served_Portions", "sum"),
        Discarded_Kg=("Discarded_Kg", "sum"), Discarded_Portions_Est=("Discarded_Portions_Est", "sum"),
        Donated_Kg=("Donated_Kg", "sum"), Waste_Cost_Est=("Waste_Cost_Est", "sum"))
    g["Waste_Pct"] = (g["Discarded_Portions_Est"] / g["Prepared_Portions"] * 100).round(2)
    return g.round(2)


def ds_waste_cost(start=None, end=None):
    b = pivot_base(start, end)
    return b[["Date", "Month", "Category", "Item", "Discarded_Portions_Est", "Avg_Unit_Cost", "Waste_Cost_Est",
              "Avoidable_Cost_Est", "Donated_Value_Est", "Production_Cost", "Revenue"]] if not b.empty else b


def ds_ingredient_consumption(start=None, end=None):
    return db.query_df(
        "SELECT DATE_FORMAT(m.movement_date,'%Y-%m') AS Month, i.ingredient_name AS Ingredient, i.unit_code AS Unit, "
        "ROUND(SUM(CASE WHEN m.movement_type='purchase' THEN m.quantity_change ELSE 0 END),3) AS Purchased_Qty, "
        "ROUND(SUM(CASE WHEN m.movement_type='usage' THEN -m.quantity_change ELSE 0 END),3) AS Used_Qty, "
        "ROUND(SUM(CASE WHEN m.movement_type='spoilage' THEN -m.quantity_change ELSE 0 END),3) AS Spoiled_Qty, "
        "ROUND(SUM(CASE WHEN m.movement_type='purchase' THEN m.quantity_change*m.unit_cost ELSE 0 END),2) AS Purchase_Cost, "
        "ROUND(SUM(CASE WHEN m.movement_type='usage' THEN -m.quantity_change*m.unit_cost ELSE 0 END),2) AS Usage_Cost, "
        "ROUND(SUM(CASE WHEN m.movement_type='spoilage' THEN -m.quantity_change*m.unit_cost ELSE 0 END),2) AS Spoilage_Cost "
        "FROM inventory_movements m JOIN ingredients i ON i.ingredient_id=m.ingredient_id "
        "WHERE (:s IS NULL OR m.movement_date>=:s) AND (:e IS NULL OR m.movement_date<=:e) "
        "GROUP BY DATE_FORMAT(m.movement_date,'%Y-%m'), i.ingredient_name, i.unit_code ORDER BY Month, Ingredient", {"s": start, "e": end})


def ds_forecast_vs_actual(start=None, end=None):
    df = db.query_df("SELECT target_date AS Date, item_name AS Item, model_used AS Model, status AS Status, predicted_demand AS Predicted_Demand, "
                     "recommended_qty AS Recommended_Qty, approved_qty AS Approved_Qty, prepared_qty AS Prepared_Qty, served_qty AS Served_Qty, "
                     "actual_demand_est AS Actual_Demand_Est, surplus_qty AS Surplus_Qty, discarded_portions_est AS Discarded_Portions_Est, "
                     "shortage_flag AS Shortage_Flag, abs_error AS Abs_Error FROM v_forecast_vs_actual "
                     "WHERE (:s IS NULL OR target_date>=:s) AND (:e IS NULL OR target_date<=:e) ORDER BY target_date, item_name",
                     {"s": start, "e": end})
    if not df.empty:
        df["Weekday"] = pd.to_datetime(df["Date"]).dt.day_name()
    return df


def ds_donations_disposition(start=None, end=None):
    return db.query_df(
        "SELECT w.operating_date AS Date, mi.item_name AS Item, w.food_condition AS Food_Condition, w.reason_code AS Reason, "
        "d.disposition_type AS Disposition, d.weight_kg AS Weight_Kg, ROUND(d.weight_kg/mi.portion_weight_kg,2) AS Portions_Est, "
        "COALESCE(dn.recipient_name,'') AS Recipient FROM waste_dispositions d JOIN weighing_records w ON w.weigh_id=d.weigh_id "
        "JOIN menu_items mi ON mi.item_id=w.item_id LEFT JOIN donations dn ON dn.disposition_id=d.disposition_id "
        "WHERE (:s IS NULL OR w.operating_date>=:s) AND (:e IS NULL OR w.operating_date<=:e) ORDER BY w.operating_date, mi.item_name",
        {"s": start, "e": end})


def ds_inventory_purchases(start=None, end=None):
    return db.query_df(
        "SELECT p.purchase_date AS Date, s.supplier_name AS Supplier, p.invoice_no AS Invoice, i.ingredient_name AS Ingredient, "
        "i.unit_code AS Unit, m.quantity_change AS Quantity, m.unit_cost AS Unit_Cost, ROUND(m.quantity_change*m.unit_cost,2) AS Line_Cost, "
        "m.expiry_date AS Expiry_Date FROM inventory_movements m JOIN purchases p ON p.purchase_id=m.purchase_id "
        "JOIN suppliers s ON s.supplier_id=p.supplier_id JOIN ingredients i ON i.ingredient_id=m.ingredient_id "
        "WHERE m.movement_type='purchase' AND (:s IS NULL OR p.purchase_date>=:s) AND (:e IS NULL OR p.purchase_date<=:e) "
        "ORDER BY p.purchase_date, i.ingredient_name", {"s": start, "e": end})


def ds_footfall(start=None, end=None):
    """Expected and observed footfall per period joined with portions served in that period (for footfall vs sales)."""
    return db.query_df(
        "SELECT f.operating_date AS Date, sp.period_name AS Period, f.expected_count AS Expected_Footfall, f.observed_count AS Observed_Footfall, "
        "COALESCE(s.served,0) AS Served_Portions FROM footfall f JOIN service_periods sp ON sp.period_id=f.period_id "
        "LEFT JOIN (SELECT sr.operating_date, sr.period_id, SUM(sr.portions_paid+sr.portions_complimentary) AS served FROM service_records sr "
        "GROUP BY sr.operating_date, sr.period_id) s ON s.operating_date=f.operating_date AND s.period_id=f.period_id "
        "WHERE (:s IS NULL OR f.operating_date>=:s) AND (:e IS NULL OR f.operating_date<=:e) ORDER BY f.operating_date, sp.start_time", {"s": start, "e": end})


def ds_dim_item():
    return common.items(False)[["item_id", "item_name", "category_name", "period_name", "selling_price", "portion_weight_kg", "portion_weight_source"]]


def database_totals(start=None, end=None) -> dict:
    """Independent totals straight from base tables (NOT from the view) used to verify exports."""
    p = {"s": start, "e": end}
    prep = db.scalar("SELECT COALESCE(SUM(qty_prepared),0) FROM prep_batches WHERE (:s IS NULL OR operating_date>=:s) AND (:e IS NULL OR operating_date<=:e)", p)
    served = db.scalar("SELECT COALESCE(SUM(portions_paid+portions_complimentary),0) FROM service_records WHERE (:s IS NULL OR operating_date>=:s) AND (:e IS NULL OR operating_date<=:e)", p)
    disc = db.scalar("SELECT COALESCE(SUM(d.weight_kg),0) FROM waste_dispositions d JOIN weighing_records w ON w.weigh_id=d.weigh_id "
                     "WHERE d.disposition_type='discarded' AND (:s IS NULL OR w.operating_date>=:s) AND (:e IS NULL OR w.operating_date<=:e)", p)
    don = db.scalar("SELECT COALESCE(SUM(d.weight_kg),0) FROM waste_dispositions d JOIN weighing_records w ON w.weigh_id=d.weigh_id "
                    "WHERE d.disposition_type='donated' AND (:s IS NULL OR w.operating_date>=:s) AND (:e IS NULL OR w.operating_date<=:e)", p)
    return {"prepared": int(prep), "served": int(served), "discarded_kg": round(float(disc), 3), "donated_kg": round(float(don), 3)}
