"""Generate a reproducible SYNTHETIC dataset for PlateWise (NOT real canteen data).

Usage:  python -m scripts.seed_synthetic --reset [--days 90] [--seed 42] [--end-date YYYY-MM-DD]

Assumptions (also documented in docs/synthetic_data.md):
 * Demand per item/day = base x weekday factor x trend x exam-week factor x random noise.
 * Before the "intervention" the canteen cooks a fixed multiple of a typical day (some items over-produced,
   Chole Bhature under-produced). In the last --intervention-days operating days the manager follows the
   forecasting module's recommendation (approved as-is 85% of the time, otherwise adjusted by +/-5).
   This lets the project DEMONSTRATE the feedback loop; the numbers prove nothing about a real canteen.
 * Expected footfall (known in advance) is a noisy estimate of the real footfall; some values are missing.
 * ~10% of weighed leftovers lose 20-40% of their mass (spillage/staff meals) -> reconciliation flags;
   ~12% of leftovers are not weighed.
"""
import argparse
import os
import secrets
import sys
from datetime import date, datetime, timedelta
from pathlib import Path

import numpy as np
import pandas as pd
from sqlalchemy import text

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from analytics import forecasting as fc  # noqa: E402
from core import database as db  # noqa: E402
from core import security  # noqa: E402
from services import common, forecast_service, recommendation_service  # noqa: E402

# name, category, period, price, portion_kg, base, weekday factors Mon..Sat, cv, over-production factor, step
ITEMS = [
    ("Poha", "Breakfast", "Breakfast", 25, 0.25, 85, [1.0, 1.0, 0.95, 1.0, 1.05, 0.8], 0.12, 1.12, 5),
    ("Idli Sambar", "Breakfast", "Breakfast", 30, 0.30, 70, [1.1, 1.0, 0.9, 0.95, 1.0, 0.85], 0.15, 1.10, 5),
    ("Veg Biryani", "Main meal", "Lunch", 70, 0.35, 140, [1.1, 1.0, 0.95, 0.95, 1.15, 0.7], 0.10, 1.10, 5),
    ("Rajma Chawal", "Main meal", "Lunch", 55, 0.40, 90, [0.8, 1.0, 1.0, 0.9, 1.0, 0.9], 0.14, 1.30, 5),
    ("Chole Bhature", "Main meal", "Lunch", 60, 0.38, 100, [0.9, 1.2, 1.0, 0.95, 1.0, 0.9], 0.12, 0.92, 5),
    ("Dal Tadka Thali", "Main meal", "Lunch", 65, 0.45, 75, [1.0, 1.0, 1.0, 1.0, 0.95, 0.85], 0.30, 1.12, 5),
    ("Samosa", "Snacks", "Evening snacks", 15, 0.10, 160, [1.0, 1.0, 1.0, 1.05, 1.1, 0.9], 0.12, 1.10, 10),
    ("Veg Sandwich", "Snacks", "Evening snacks", 35, 0.20, 60, [1.0, 0.95, 1.0, 1.0, 1.1, 0.9], 0.15, 1.08, 5),
]
# name, unit, cost per unit (Rs), reorder level, shelf life days
INGREDIENTS = [
    ("Basmati Rice", "kg", 110, 20, 365), ("Idli Rice", "kg", 55, 10, 365), ("Rajma", "kg", 130, 10, 365),
    ("Chickpeas", "kg", 115, 10, 365), ("Paneer", "kg", 320, 3, 7), ("Potato", "kg", 30, 15, 20),
    ("Onion", "kg", 35, 15, 20), ("Tomato", "kg", 40, 8, 6), ("Maida", "kg", 42, 15, 180), ("Atta", "kg", 40, 15, 180),
    ("Cooking Oil", "l", 140, 10, 180), ("Mixed Vegetables", "kg", 60, 8, 5), ("Poha (flattened rice)", "kg", 70, 8, 180),
    ("Toor Dal", "kg", 140, 10, 365), ("Bread", "kg", 55, 4, 4), ("Spice Mix", "kg", 400, 1, 365),
]
RECIPES = {
    "Poha": {"Poha (flattened rice)": .08, "Onion": .03, "Potato": .03, "Cooking Oil": .01, "Spice Mix": .002},
    "Idli Sambar": {"Idli Rice": .09, "Toor Dal": .04, "Mixed Vegetables": .05, "Cooking Oil": .008, "Spice Mix": .003},
    "Veg Biryani": {"Basmati Rice": .10, "Mixed Vegetables": .08, "Onion": .03, "Cooking Oil": .015, "Paneer": .02, "Spice Mix": .006},
    "Rajma Chawal": {"Rajma": .06, "Basmati Rice": .08, "Onion": .03, "Tomato": .04, "Cooking Oil": .012, "Spice Mix": .004},
    "Chole Bhature": {"Chickpeas": .07, "Maida": .08, "Onion": .03, "Tomato": .04, "Cooking Oil": .03, "Spice Mix": .005},
    "Dal Tadka Thali": {"Toor Dal": .06, "Basmati Rice": .08, "Atta": .06, "Mixed Vegetables": .05, "Cooking Oil": .012, "Spice Mix": .003},
    "Samosa": {"Maida": .03, "Potato": .05, "Cooking Oil": .02, "Spice Mix": .002},
    "Veg Sandwich": {"Bread": .06, "Potato": .03, "Tomato": .02, "Onion": .015, "Cooking Oil": .005},
}
BATCH_TIMES = {"Breakfast": ((7, 0), (7, 45)), "Lunch": ((11, 0), (11, 40)), "Evening snacks": ((15, 15), (15, 50))}
SERVICE_TIMES = {"Breakfast": ((8, 0), (9, 30)), "Lunch": ((12, 30), (14, 15)), "Evening snacks": ((16, 20), (17, 40))}
WEIGH_TIMES = {"Breakfast": (10, 45), "Lunch": (15, 15), "Evening snacks": (18, 45)}
BASE_FOOTFALL = {"Breakfast": 150, "Lunch": 420, "Evening snacks": 220}


def last_operating_day(before: date, days_ok: list[int]) -> date:
    d = before
    while d.weekday() not in days_ok:
        d -= timedelta(days=1)
    return d


def dt(d: date, hm):
    return datetime(d.year, d.month, d.day, hm[0], hm[1])


def split_kg(total: float, parts: list[float]) -> list[float]:
    """Round parts to 3 decimals and make them sum exactly to total."""
    out = [round(p, 3) for p in parts]
    out[-1] = round(total - sum(out[:-1]), 3)
    return out


def seed(engine, days=90, end_date=None, intervention_days=28, rng_seed=42, password=None, reset=True, verbose=True) -> dict:
    db.set_engine(engine)
    rng = np.random.default_rng(rng_seed)
    if reset:
        db.create_schema(engine, reset=True)
    st = common.settings()
    op_days = st["operating_days"]
    end_date = end_date or last_operating_day(date.today() - timedelta(days=1), op_days)
    # operating calendar: last `days` operating days minus 3 random closed days (holidays)
    cal, d = [], end_date
    while len(cal) < days:
        if d.weekday() in op_days:
            cal.append(d)
        d -= timedelta(days=1)
    cal = sorted(cal)
    closed = set(rng.choice(range(5, len(cal) - 5), size=3, replace=False).tolist())
    exam_days = set(rng.choice(range(10, len(cal) - 10), size=4, replace=False).tolist())
    days_list = [c for i, c in enumerate(cal) if i not in closed]
    intervention_start = days_list[-intervention_days] if intervention_days else None

    password = password or os.getenv("PLATEWISE_DEMO_PASSWORD") or (secrets.token_urlsafe(9) + "a1")
    users = {}
    for uname, full, role in [("admin", "Demo Administrator", "admin"), ("manager", "Demo Canteen Manager", "manager"),
                              ("operator", "Demo Data-entry Operator", "operator"), ("analyst", "Demo Analyst", "analyst")]:
        users[uname] = security.create_user(None, uname, full, password, role, bootstrap=True)
    mgr = {"user_id": users["manager"], "role": "manager", "username": "manager"}
    op_id = users["operator"]

    with engine.begin() as c:
        def q(sql, **p):
            return c.execute(text(sql), p)
        cats = {r[1]: r[0] for r in q("SELECT category_id, category_name FROM categories").fetchall()}
        pers = {r[1]: r[0] for r in q("SELECT period_id, period_name FROM service_periods").fetchall()}
        st_ids = {r[1]: r[0] for r in q("SELECT station_id, station_code FROM stations").fetchall()}
        ing_ids, ing_cost, ing_life = {}, {}, {}
        for n, u, cost, ro, life in INGREDIENTS:
            ing_ids[n] = q("INSERT INTO ingredients (ingredient_name, unit_code, cost_per_unit, reorder_level, shelf_life_days) "
                           "VALUES (:n,:u,:c,:r,:l)", n=n, u=u, c=cost, r=ro, l=life).lastrowid
            ing_cost[n], ing_life[n] = float(cost), life
        sup = [q("INSERT INTO suppliers (supplier_name, phone) VALUES (:n,:p)", n=n, p=p).lastrowid
               for n, p in [("Synthetic Fresh Produce Co.", "0000000001"), ("Synthetic Grain & Pulses Traders", "0000000002")]]
        item_ids = {}
        for n, cat, per, price, pw, base, wf, cv, over, step in ITEMS:
            item_ids[n] = q("INSERT INTO menu_items (item_name, category_id, period_id, selling_price, portion_weight_kg, portion_weight_source, "
                            "est_cost_per_portion, rounding_step) VALUES (:n,:c,:p,:pr,:pw,:src,NULL,:st)", n=n, c=cats[cat], p=pers[per], pr=price, pw=pw,
                            src="Synthetic assumption (standard serving, not measured)", st=step).lastrowid
            for ing, qpp in RECIPES[n].items():
                q("INSERT INTO recipe_ingredients (item_id, ingredient_id, qty_per_portion) VALUES (:i,:g,:q)", i=item_ids[n], g=ing_ids[ing], q=qpp)
        unit_cost = {n: round(sum(qpp * ing_cost[g] for g, qpp in RECIPES[n].items()), 2) for n in RECIPES}

        stock = {n: 0.0 for n in ing_ids}
        spoil_events = []  # (date, ingredient, qty)
        history = {n: [] for n in item_ids}  # rows for forecasting
        stats = {"days": len(days_list), "batches": 0, "weighings": 0, "recs": 0}

        def buy(day, ing, qty):
            qty = round(qty, 1)
            pid = q("INSERT INTO purchases (supplier_id, purchase_date, invoice_no) VALUES (:s,:d,:n)",
                    s=sup[0] if ing_life[ing] <= 20 else sup[1], d=day, n=f"SYN-{day:%y%m%d}-{ing_ids[ing]}").lastrowid
            q("INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date, expiry_date, purchase_id, note) "
              "VALUES (:g,'purchase',:q,:c,:d,:x,:p,'synthetic purchase')", g=ing_ids[ing], q=qty, c=ing_cost[ing], d=day,
              x=day + timedelta(days=ing_life[ing]), p=pid)
            stock[ing] += qty
            if ing_life[ing] <= 7 and rng.random() < 0.30 and day + timedelta(days=min(ing_life[ing], 4)) <= end_date:
                spoil_events.append((day + timedelta(days=min(ing_life[ing], 4)), ing, qty * rng.uniform(0.10, 0.25)))

        for di, day in enumerate(days_list):
            trend_days = max(di - 40, 0)
            exam = 0.8 if cal.index(day) in exam_days else 1.0
            # ---- demand (true, unobserved) ----
            demand = {}
            for n, cat, per, price, pw, base, wf, cv, over, step in ITEMS:
                tr = 1 + (0.004 * trend_days if n == "Samosa" else 0.0)
                demand[n] = max(int(round(base * wf[day.weekday()] * tr * exam * (1 + rng.normal(0, cv)))), 0)
            # ---- footfall ----
            ff = {}
            for per in BASE_FOOTFALL:
                tot = sum(demand[n] for n, *rest in ITEMS if rest[1] == per)
                obs = int(round(tot * rng.uniform(0.95, 1.15)))
                exp = int(round(obs * (1 + rng.normal(0, 0.06))))
                ff[per] = (None if rng.random() < 0.06 else exp, None if rng.random() < 0.03 else obs)
                q("INSERT INTO footfall (operating_date, period_id, expected_count, observed_count, source, note) VALUES (:d,:p,:e,:o,'synthetic','SYNTHETIC')",
                  d=day, p=pers[per], e=ff[per][0], o=ff[per][1])
            # ---- decide preparation quantities ----
            plan = {}
            following = intervention_start is not None and day >= intervention_start
            if following:
                run_id = q("INSERT INTO forecast_runs (target_date, model_version, training_end_date, created_by, is_synthetic) VALUES (:t,:v,:e,:u,1)",
                           t=day, v=st["model_version"], e=day - timedelta(days=1), u=users["manager"]).lastrowid
            for n, cat, per, price, pw, base, wf, cv, over, step in ITEMS:
                if following:
                    hdf = pd.DataFrame(history[n], columns=["operating_date", "served", "sold_out", "footfall_obs", "footfall_exp"])
                    h = fc.prepare_history(hdf, st["sold_out_uplift"])
                    cfg = {**common.forecast_cfg(st), "rounding_step": step}
                    res = fc.forecast_item(h, day, ff[per][0], cfg)
                    rec_qty = res["recommended_qty"]
                    if rec_qty is None:
                        rec_qty, status, appr = int(round(base * wf[day.weekday()] * over / step) * step), "adjusted", None
                        appr = rec_qty
                    elif rng.random() < 0.85:
                        status, appr = "approved", rec_qty
                    else:
                        status, appr = "adjusted", max(rec_qty + int(rng.choice([-5, 5])), 0)
                    import json
                    rid = q("INSERT INTO forecast_recommendations (run_id, item_id, target_date, model_used, predicted_demand, buffer_pct, recommended_qty, "
                            "history_points, backtest_n, mae_baseline, mae_selected, expected_footfall, inputs_json, explanation, status, approved_qty, "
                            "reviewed_by, reviewed_at, review_note) VALUES (:r,:i,:d,:m,:p,:b,:q,:h,:bn,:mb,:ms,:ef,:inp,:ex,:s,:a,:u,:t,:rn)",
                            r=run_id, i=item_ids[n], d=day, m=res["model_used"], p=res["predicted_demand"], b=res["buffer_pct"], q=rec_qty,
                            h=res["history_points"], bn=res["backtest_n"], mb=res["mae_baseline"], ms=res["mae_selected"], ef=ff[per][0],
                            inp=json.dumps({"inputs": res["inputs"], "scores": res["model_scores"]}, default=float), ex=res["explanation"], s=status,
                            a=appr, u=users["manager"], t=dt(day, (6, 30)), rn="SYNTHETIC review").lastrowid
                    stats["recs"] += 1
                    plan[n] = (appr, rid)
                else:
                    p = base * wf[day.weekday()] * over * (1 + rng.normal(0, 0.03))
                    plan[n] = (max(int(round(p / step) * step), step), None)
            # ---- ingredient purchasing so stock never goes negative ----
            need = {g: 0.0 for g in ing_ids}
            for n in item_ids:
                for g, qpp in RECIPES[n].items():
                    need[g] += qpp * plan[n][0]
            for g in ing_ids:
                if stock[g] < need[g] * 1.02:
                    horizon = 2 if ing_life[g] <= 7 else 4
                    buy(day, g, need[g] * horizon * 1.1 + 1)
            # ---- cook, serve, weigh ----
            for n, cat, per, price, pw, base, wf, cv, over, step in ITEMS:
                iid = item_ids[n]
                P, rid = plan[n]
                if P <= 0:
                    continue
                if P > 100:
                    qtys = [int(round(P * 0.55 / 5) * 5), 0]
                    qtys[1] = P - qtys[0]
                else:
                    qtys = [P]
                bids = []
                for bi, bq in enumerate(qtys):
                    if bq <= 0:
                        continue
                    code = f"B-{day:%y%m%d}-{iid:02d}-{bi + 1}"
                    bid = q("INSERT INTO prep_batches (batch_code, operating_date, item_id, batch_no, station_id, prepared_at, qty_prepared, unit_cost, "
                            "cost_source, operator_id, rec_id, notes, is_synthetic) VALUES (:c,:d,:i,:n,:s,:t,:q,:u,'recipe',:o,:r,'SYNTHETIC',1)",
                            c=code, d=day, i=iid, n=bi + 1, s=st_ids["PREP-A" if bi == 0 else "PREP-B"], t=dt(day, BATCH_TIMES[per][bi]), q=bq,
                            u=unit_cost[n], o=op_id, r=rid).lastrowid
                    bids.append(bid)
                    stats["batches"] += 1
                    for g, qpp in RECIPES[n].items():
                        q("INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date, batch_id, note) "
                          "VALUES (:g,'usage',:q,:c,:d,:b,'synthetic recipe usage')", g=ing_ids[g], q=-round(qpp * bq, 3), c=ing_cost[g], d=day, b=bid)
                        stock[g] -= round(qpp * bq, 3)
                D = demand[n]
                S = min(D, P)
                sold_out = D > P
                comp = int(round(S * 0.03))
                paid = S - comp
                if S > 0:
                    first = int(round(S * rng.uniform(0.45, 0.65)))
                    half = int(round(comp * 0.5))
                    segs = [(sp, sc) for sp, sc in [(first, half), (S - first, comp - half)] if sp > 0]
                    served_so_far = 0
                    for si, (sp, sc) in enumerate(segs):
                        served_so_far += sp
                        q("INSERT INTO service_records (operating_date, item_id, period_id, station_id, served_at, portions_paid, portions_complimentary, "
                          "unit_price, remaining_after, sold_out_flag, source, operator_id, note) VALUES (:d,:i,:p,:s,:t,:a,:c,:u,:r,:so,'synthetic',:o,'SYNTHETIC')",
                          d=day, i=iid, p=pers[per], s=st_ids["COUNTER-1"], t=dt(day, SERVICE_TIMES[per][si]), a=sp - sc, c=sc, u=price,
                          r=P - served_so_far, so=int(sold_out and si == len(segs) - 1), o=op_id)
                history[n].append((pd.Timestamp(day), S, int(sold_out), ff[per][1], ff[per][0]))
                # ---- leftover weighing (Zone C) and disposition (Zone D) ----
                L = P - S
                if L <= 0 or rng.random() < 0.12:
                    continue
                true_kg = L * pw * (1 + rng.normal(0, 0.03))
                r = rng.random()
                kg = true_kg * (rng.uniform(0.6, 0.8) if r < 0.10 else (1.3 if r > 0.97 else 1.0))
                kg = max(kg, 0.05)
                ne_share = rng.uniform(0.04, 0.12) if cat != "Snacks" else 0.03
                parts = [("edible", kg * (1 - ne_share), "overproduction" if L > 0.05 * P else "low_demand")]
                if kg * ne_share >= 0.05:
                    parts.append(("not_edible", kg * ne_share, "plate_return" if rng.random() < 0.6 else "quality_issue"))
                for cond, wkg, reason in parts:
                    wkg = round(wkg, 3)
                    if wkg <= 0:
                        continue
                    wid = q("INSERT INTO weighing_records (operating_date, item_id, batch_id, station_id, scale_id, weight_value, unit_code, weight_kg, food_condition, "
                            "reason_code, weighed_at, operator_id, note, is_synthetic) VALUES (:d,:i,:b,:s,'SCALE-01',:w,'kg',:w,:c,:r,:t,:o,'SYNTHETIC',1)",
                            d=day, i=iid, b=bids[-1], s=st_ids["SCALE-01"], w=wkg, c=cond, r=reason, t=dt(day, WEIGH_TIMES[per]) + timedelta(minutes=int(rng.integers(0, 15))),
                            o=op_id).lastrowid
                    stats["weighings"] += 1
                    when = dt(day, WEIGH_TIMES[per]) + timedelta(minutes=30)
                    if cond == "not_edible":
                        q("INSERT INTO waste_dispositions (weigh_id, disposition_type, weight_kg, reason, decided_at, station_id, operator_id) "
                          "VALUES (:w,'discarded',:k,'not fit for consumption',:t,:s,:o)", w=wid, k=wkg, t=when, s=st_ids["SURPLUS-1"], o=op_id)
                        continue
                    donate_p = 0.7 if cat == "Main meal" else 0.3
                    if wkg >= 1.0 and rng.random() < donate_p:
                        dk = wkg * rng.uniform(0.4, 0.9)
                        rest = wkg - dk
                        rk = rest * 0.2 if rng.random() < 0.08 else 0.0
                        sizes = [dk, rest - rk, rk] if rk > 0.05 else [dk, rest, 0.0]
                        sizes = split_kg(wkg, sizes)
                    else:
                        sizes = [0.0, wkg, 0.0]
                    for typ, kgv in zip(["donated", "discarded", "retained"], sizes):
                        if kgv <= 0.0:
                            continue
                        did = q("INSERT INTO waste_dispositions (weigh_id, disposition_type, weight_kg, reason, decided_at, station_id, operator_id) "
                                "VALUES (:w,:t,:k,:r,:when,:s,:o)", w=wid, t=typ, k=kgv, when=when, s=st_ids["SURPLUS-1"], o=op_id,
                                r={"donated": "passed food-safety check", "discarded": "surplus not suitable for reuse", "retained": "chilled for next-day staff meal"}[typ]).lastrowid
                        if typ == "donated":
                            q("INSERT INTO donations (disposition_id, recipient_name, handed_over_at, food_safety_checked, note) VALUES (:i,:n,:t,1,'SYNTHETIC')",
                              i=did, n="Synthetic City Food Bank", t=when + timedelta(minutes=20))
            # ---- spoilage events due today ----
            for ev in [e for e in spoil_events if e[0] == day]:
                _, g, qty = ev
                qty = round(min(qty, max(stock[g], 0)), 2)
                if qty > 0.05:
                    q("INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date, note) "
                      "VALUES (:g,'spoilage',:q,:c,:d,'synthetic spoilage')", g=ing_ids[g], q=-qty, c=ing_cost[g], d=day)
                    stock[g] -= qty
            spoil_events = [e for e in spoil_events if e[0] != day]
            if verbose and di % 15 == 0:
                print(f"  simulated {di + 1}/{len(days_list)} operating days...", flush=True)

    n_eval = forecast_service.evaluate_outcomes()
    stats["outcomes"] = n_eval
    # advisory recommendations: first set generated just before the intervention (marked implemented), then current ones
    adv = 0
    if intervention_start:
        before = intervention_start - timedelta(days=1)
        adv += recommendation_service.generate(mgr, before)
        for r in recommendation_service.listing("open").itertuples():
            if r.rule_code in ("repeated_surplus", "repeated_shortage"):
                recommendation_service.review(mgr, int(r.adv_id), "approved")
                recommendation_service.review(mgr, int(r.adv_id), "implemented", "synthetic: implemented via forecast-based planning", intervention_start)
    adv += recommendation_service.generate(mgr, end_date)
    stats.update(advisory=adv, end_date=str(end_date), intervention_start=str(intervention_start), demo_password=password)
    return stats


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--days", type=int, default=90)
    ap.add_argument("--end-date", type=date.fromisoformat, default=None)
    ap.add_argument("--intervention-days", type=int, default=28)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--reset", action="store_true", help="drop and recreate all tables first (destroys data)")
    a = ap.parse_args()
    ok, msg = db.check_connection()
    if not ok:
        sys.exit(msg)
    if not a.reset and not db.query_df("SELECT 1 FROM users LIMIT 1").empty:
        sys.exit("Database already has data. Use --reset to recreate it.")
    stats = seed(db.get_engine(), a.days, a.end_date, a.intervention_days, a.seed)
    print("\nSYNTHETIC data loaded:", {k: v for k, v in stats.items() if k != "demo_password"})
    if not os.getenv("PLATEWISE_DEMO_PASSWORD"):
        print(f"\nDemo users: admin, manager, operator, analyst  |  password (shown once): {stats['demo_password']}")
    else:
        print("\nDemo users: admin, manager, operator, analyst  |  password: the value of PLATEWISE_DEMO_PASSWORD")


if __name__ == "__main__":
    main()
