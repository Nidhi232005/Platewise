"""Create the PlateWise schema, reference data and views, and (optionally) the first admin user.

Usage:  python -m scripts.init_db [--reset] [--admin-user admin]
The admin password is read from PLATEWISE_ADMIN_PASSWORD or typed at a hidden prompt (never stored in code).
"""
import argparse
import getpass
import os
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core import database as db  # noqa: E402
from core import security  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--reset", action="store_true", help="DROP all PlateWise tables first (destroys data)")
    ap.add_argument("--admin-user", default=None, help="create an admin account with this username")
    a = ap.parse_args()
    ok, msg = db.check_connection()
    if not ok:
        sys.exit(msg)
    if a.reset and input("This deletes ALL data in the configured database. Type YES to continue: ") != "YES":
        sys.exit("Cancelled.")
    db.create_schema(reset=a.reset)
    print("Schema, reference data and views are ready.")
    if a.admin_user:
        pw = os.getenv("PLATEWISE_ADMIN_PASSWORD") or getpass.getpass("Admin password (min 8, letters+digits): ")
        security.create_user(None, a.admin_user, "Administrator", pw, "admin", bootstrap=True)
        print(f"Admin user '{a.admin_user}' created.")


if __name__ == "__main__":
    main()
