"""Generate docs/data_dictionary.md from the live MySQL schema, plus assets/ (logo and a sample zone map SVG).
Usage: python -m scripts.gen_docs_assets"""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core import database as db  # noqa: E402
from core import ui  # noqa: E402

TABLES = {
    "users": "Application accounts. Passwords are stored only as bcrypt hashes.", "zones": "The five physical canteen zones A-E (configurable).",
    "stations": "Named stations inside zones: Prep Bay A/B, counter, SCALE-01, surplus table, store.", "units": "Measurement units and their factor to the base unit.",
    "service_periods": "Breakfast, Lunch, Evening snacks with operating hours.", "config_settings": "Tunable settings (buffers, tolerances, forecast parameters).",
    "categories": "Menu categories.", "menu_items": "Menu items with price, portion weight (kg per portion, with documented source) and rounding step.",
    "ingredients": "Ingredient master with unit, latest cost, reorder level and shelf life.", "recipe_ingredients": "Quantity of each ingredient per portion of a menu item.",
    "suppliers": "Ingredient suppliers.", "purchases": "Purchase headers (supplier, date, invoice).",
    "inventory_movements": "Signed stock ledger: purchase (+), usage (-), spoilage (-), adjustment (+/-). Current stock = SUM(quantity_change).",
    "prep_batches": "Zone A: one row per cooked batch (several per item per day allowed).", "service_records": "Zone B: portions served (paid vs complimentary), time, remaining, sold-out flag.",
    "footfall": "Approximate students per service period: expected (known in advance) and observed (counted afterwards).",
    "weighing_records": "Zone C: leftover weighed manually on a scale, with condition (edible / not edible) and reason.",
    "waste_dispositions": "Zone D: what happened to each weighed quantity (donated, discarded, retained, other loss).", "donations": "Donation details: recipient and mandatory food-safety confirmation.",
    "forecast_runs": "One row per forecast generation (target date, model version, training end date).",
    "forecast_recommendations": "Per-item forecast and recommended quantity, model used, explanation, manager decision.",
    "actual_outcomes": "What actually happened for each evaluated recommendation (prepared, served, surplus, shortage, error).",
    "advisory_recommendations": "Rule-based advice with problem, evidence, action, benefit, confidence, limitations, status and outcome.",
    "audit_log": "Who changed what and when (written in the same transaction as the change).",
    "v_daily_item_summary": "VIEW: one row per date x item reconciling prepared, served, weighed, donated, discarded; costs; estimates labelled *_est.",
    "v_inventory_stock": "VIEW: current stock per ingredient (sum of movements) with low-stock flag.", "v_forecast_vs_actual": "VIEW: stored forecasts joined to actual outcomes.",
}
COLS = {
    "qty_prepared": "Portions cooked in the batch (counted).", "portions_paid": "Portions sold for money (counted).", "portions_complimentary": "Free portions (counted, no revenue).",
    "weight_value": "Weight as typed by the operator, in unit_code.", "weight_kg": "Weight converted to kg (MEASURED, manual entry).",
    "portion_weight_kg": "Documented kg per portion; converts kg to portions (ESTIMATE).", "portion_weight_source": "Where the portion weight came from.",
    "unit_cost": "Production cost per portion (batch) or cost per ingredient unit (movement).", "cost_source": "recipe, manual, or menu_estimate.",
    "quantity_change": "Signed ingredient quantity in the ingredient's own unit.", "sold_out_flag": "1 if the item sold out (demand is then under-counted).",
    "expected_count": "Expected students, known BEFORE service (allowed as a forecast input).", "observed_count": "Students counted afterwards (history only).",
    "food_condition": "edible or not_edible (not edible food can only be discarded).", "reason_code": "Why food was left over.", "disposition_type": "donated, discarded, retained or other_loss.",
    "food_safety_checked": "Must be 1 for a donation (database CHECK).", "predicted_demand": "Forecast demand in portions (an estimate).", "recommended_qty": "Suggested preparation quantity.",
    "approved_qty": "Quantity approved or entered by the manager.", "mae_baseline": "Backtest MAE of the same-weekday baseline.", "mae_selected": "Backtest MAE of the model used.",
    "actual_demand_est": "Served portions, uplifted on sold-out days (censored demand assumption).", "abs_error": "Absolute difference between actual_demand_est and predicted_demand.",
    "is_synthetic": "1 = generated test data, not a real observation.", "source": "manual, import or synthetic.", "rounding_step": "Recommendations are rounded to multiples of this many portions.",
    "password_hash": "bcrypt hash, never the password.", "metrics_json": "Evidence behind a recommendation (JSON).", "inputs_json": "Forecast inputs and backtest scores (JSON).",
    "expected_leftover_portions": "prepared - served (counted).", "measured_portions_est": "measured kg / portion weight (ESTIMATE).",
    "unexplained_portions_est": "expected leftover - measured portions (reconciliation gap).", "discarded_cost_est": "Discarded portions x average batch cost (ESTIMATE; not selling price).",
    "avoidable_cost_est": "Part of discarded cost that was edible when discarded.", "rec_id": "Link to the forecast recommendation behind a batch or outcome.",
}


def main():
    cols = db.query_df("SELECT table_name AS t, column_name AS c, column_type AS ty, is_nullable AS n, column_key AS k, column_default AS d "
                       "FROM information_schema.columns WHERE table_schema=DATABASE() ORDER BY table_name, ordinal_position")
    kinds = db.query_df("SELECT table_name AS t, table_type AS k FROM information_schema.tables WHERE table_schema=DATABASE()")
    kind = dict(zip(kinds["t"], kinds["k"]))
    fks = db.query_df("SELECT table_name AS t, column_name AS c, referenced_table_name AS r, referenced_column_name AS rc FROM information_schema.key_column_usage "
                      "WHERE table_schema=DATABASE() AND referenced_table_name IS NOT NULL")
    fkmap = {(r.t, r.c): f"FK -> {r.r}.{r.rc}" for r in fks.itertuples()}
    out = ["# PlateWise Data Dictionary", "", "Generated from the live MySQL schema by `python -m scripts.gen_docs_assets`.",
           "Quantities are COUNTED (portions) or MEASURED (kg). Columns ending `_est` are ESTIMATES. `is_synthetic = 1` marks generated test data.", ""]
    for t, g in cols.groupby("t", sort=False):
        out += [f"## {t}" + (" (view)" if kind.get(t) == "VIEW" else ""), "", TABLES.get(t, ""), "", "| Column | Type | Null | Key | Meaning |", "|---|---|---|---|---|"]
        for r in g.itertuples():
            key = {"PRI": "PK", "UNI": "UNIQUE", "MUL": "index"}.get(r.k, "")
            meaning = COLS.get(r.c, "")
            if (t, r.c) in fkmap:
                meaning = (meaning + " " if meaning else "") + fkmap[(t, r.c)]
            out.append(f"| {r.c} | {r.ty} | {r.n} | {key} | {meaning} |")
        out.append("")
    (ROOT / "docs" / "data_dictionary.md").write_text("\n".join(out), encoding="utf-8")
    (ROOT / "assets" / "platewise_logo.svg").write_text(ui.LOGO_SVG.replace('width="38" height="38"', 'width="160" height="160"').replace("<svg ", '<svg xmlns="http://www.w3.org/2000/svg" ', 1), encoding="utf-8")
    from services import zone_service
    from views.zone_map import _svg
    day = db.query_df("SELECT MAX(operating_date) AS d FROM prep_batches").iloc[0, 0]
    if day is not None:
        svg = _svg(zone_service.zone_status(day)).replace('width="100%"', 'width="910" height="440"', 1)
        svg = svg.replace("</svg>", f'<text x="20" y="432" font-size="11" fill="#5A5A63">Sample rendering for {day} from SYNTHETIC data</text></svg>')
        (ROOT / "assets" / "zone_map_sample.svg").write_text(svg, encoding="utf-8")
    print("written: docs/data_dictionary.md, assets/platewise_logo.svg, assets/zone_map_sample.svg")


if __name__ == "__main__":
    main()
