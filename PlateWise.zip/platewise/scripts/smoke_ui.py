"""Headless smoke test: opens every page as every role with Streamlit's AppTest and reports exceptions/errors.
Usage: python -m scripts.smoke_ui   (needs a seeded database)"""
import logging
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
logging.disable(logging.WARNING)

from streamlit.testing.v1 import AppTest  # noqa: E402

from core import database as db  # noqa: E402

PAGES = ["overview", "zones", "batches", "service", "waste", "demand", "recs", "intel", "sql", "inventory", "menu", "reports", "users", "audit"]
ROLE_USERS = ["admin", "manager", "operator", "analyst"]
DAY_WITH_DATA = "--data-day" in sys.argv


def main() -> int:
    bad = 0
    data_day = db.query_df("SELECT MAX(operating_date) AS d FROM prep_batches").iloc[0, 0]
    for uname in ROLE_USERS:
        row = db.query_df("SELECT user_id, username, full_name, role FROM users WHERE username=:u", {"u": uname}).iloc[0]
        user = {"user_id": int(row.user_id), "username": row.username, "full_name": row.full_name, "role": row.role}
        for pg in PAGES:
            at = AppTest.from_file(str(ROOT / "app.py"), default_timeout=90)
            at.session_state["user"], at.session_state["page"] = user, pg
            if DAY_WITH_DATA and data_day is not None:
                at.session_state["op_date"] = data_day
            at.run()
            errs = [str(e.value) for e in at.exception] + [str(e.value) for e in at.error]
            shown = at.session_state["page"] if "page" in at.session_state else pg
            note = "" if shown == pg else f"(redirected to {shown}: role not allowed)"
            if errs:
                bad += 1
            print(f"{row.role:9s} {pg:10s} {'ERR' if errs else 'ok '} {note} {errs[0][:160] if errs else ''}")
    print(f"\nPages/roles with errors: {bad}")
    return bad


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
