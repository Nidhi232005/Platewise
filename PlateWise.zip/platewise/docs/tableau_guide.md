# Tableau Guide

**Status:** Tableau-ready data sources are generated and checked. **No `.twbx` workbook is included**: Tableau Desktop was not
available, so the dashboards below are a build plan, not finished artifacts.

## Data sources
Reports & Exports > Tableau data sources > download ZIP. It contains:

| File | Grain | Use |
|---|---|---|
| fact_daily_item.csv | date x item | prepared, served, leftovers, kg, portions (est.), costs, revenue, reconciliation status |
| fact_forecast_vs_actual.csv | forecast x item | predicted, recommended, approved, prepared, served, error, shortage |
| fact_dispositions.csv | disposition | donated / discarded / retained kg, condition, reason, recipient |
| fact_ingredients_monthly.csv | month x ingredient | purchased, used, spoiled quantity and cost |
| fact_purchases.csv | purchase line | supplier, cost, expiry |
| fact_footfall.csv | date x period | expected and observed footfall with portions served |
| dim_item.csv | item | category, period, price, portion weight |
| control_totals.csv | one row | totals from the MySQL base tables |

Connect with Data > New Data Source > Text File. Relate `fact_daily_item.Item` to `dim_item.item_name`.
Alternatively connect to MySQL and use the views `v_daily_item_summary`, `v_forecast_vs_actual`, `v_inventory_stock`.
**Check:** `SUM([Prepared_Portions])` and `SUM([Served_Portions])` must equal `control_totals.csv`.

## Calculated fields
```
Waste %            = SUM([Discarded_Portions_Est]) / SUM([Prepared_Portions])
Shortage rate      = SUM([SoldOut_Flag]) / COUNT([Item])
Surplus            = SUM([Prepared_Portions]) - SUM([Served_Portions])
Forecast MAE       = AVG([Abs_Error])
Forecast bias      = AVG([Predicted_Demand] - [Actual_Demand_Est])
Edible kg (fact_dispositions) = SUM(IF [Food_Condition]='edible' THEN [Weight_Kg] END)
```

## Dashboards
**1. Executive.** KPI tiles: prepared, served, surplus, discarded kg, donated kg, Waste %, Waste_Cost_Est, Avoidable_Cost_Est.
Date range filter, Category filter. Title notes that costs are estimates.

**2. Demand.** Line: Predicted_Demand vs Actual_Demand_Est by Date (filter Item). Bar: AVG(Abs_Error) by Item. Bar: AVG(Served_Portions)
by Weekday. Scatter: Observed_Footfall vs Served_Portions from fact_footfall.csv.

**3. Waste.** Bar: Waste % by Item (sorted). Stacked bar by Category. Weekly trend of Waste_Cost_Est. Table of Recon_Status exceptions
with unexplained portions. Heat map: Item x Weekday coloured by surplus %.

**4. Impact.** Reference line at the change date (parameter). Before/after Waste % and shortage rate for a chosen item. Preparation
changes (Prepared_Portions vs Approved_Qty). Avoidable cost trend. Always show sold-out days beside waste: lower waste with more
sold-out days is a trade-off.

Use tooltips with units (portions, kg) and label every estimate. Keep a neutral palette (navy, periwinkle, light blue) with text labels,
not red/green.
