# Excel Pivot Table Guide

**What the workbook contains.** `PlateWise_Report_*.xlsx` (Reports & Exports page) holds nine Excel Tables ready for PivotTables,
a `Summary` sheet whose figures are SUMIFS formulas (a formula summary, **not** a PivotTable), and a `Pivot_Guide` sheet.

**What it does not contain.** Native PivotTable objects. The Python library used (openpyxl) cannot create them, and ordinary
summary tables are not presented as PivotTables. Creating a PivotTable in Excel takes under a minute:

## Create
1. Open the sheet **Pivot_Base** and click inside the table `tbl_PivotBase` (one row per date and menu item).
2. Insert > PivotTable > From Table/Range > New Worksheet.
3. Suggested pivots

| Question | Rows | Columns | Values |
|---|---|---|---|
| Waste by item | Item | | Sum of Prepared_Portions, Sum of Discarded_Portions_Est, Sum of Waste_Cost_Est |
| Weekday demand | Weekday (sort by WeekdayNo) | Item | Average of Served_Portions |
| Monthly waste trend | Month | | Sum of Discarded_Portions_Est (add a PivotChart) |
| Prepared versus served | Category, Item | | Sum of Prepared_Portions, Sum of Served_Portions |
| Reconciliation problems | Recon_Status | Item | Count of Date |

4. **Waste %** needs a calculated field: PivotTable Analyze > Fields, Items & Sets > Calculated Field, name `Waste_Pct`,
   formula `= Discarded_Portions_Est / Prepared_Portions`, then format as percentage.
5. Slicers: PivotTable Analyze > Insert Slicer > Category, Weekday, Month.

Other sheets (`tbl_ForecastVsActual`, `tbl_Ingredients`, `tbl_Donations`, `tbl_InventoryPurchases`, `tbl_WasteCost`) work the same way.

## Refresh
Export again from PlateWise, paste the new rows over the table (the table expands), then Data > Refresh All.

## Check the totals
The Reports page shows control totals computed straight from the MySQL base tables and verifies that the file matches them.
A PivotTable grand total of Prepared_Portions and Served_Portions must equal those control totals.
In this build's verification, the workbook totals equalled the MySQL totals, and the `Summary` formulas recalculated in
LibreOffice gave the same values (see `docs/testing.md`).
