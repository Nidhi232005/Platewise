# PlateWise: Architecture, Design and Methodology

## 1. Problem statement
College canteens usually cook by habit. They rarely record what was cooked, sold, left over, donated or thrown away in one
place, so waste, shortages and cost are invisible and tomorrow's quantity is a guess. PlateWise records the physical flow of
food through five zones, reconciles the numbers, estimates demand from history, lets the manager decide the quantity, and
then checks whether the decision worked.

**Central workflow:** record operations, validate quantities, analyse history, estimate demand, recommend preparation,
manager approves, record the actual outcome, evaluate, repeat.

## 2. Scope
In scope: manual data entry, MySQL storage, reconciliation, explainable forecasting, advisory rules, Excel/Tableau data, roles, audit.
Out of scope: live scale or POS integration, payments, mobile app, multi-canteen support, real-world deployment results.

## 3. System architecture

```mermaid
flowchart LR
  U[Operator / Manager / Analyst] --> UI[Streamlit pages: views/*.py]
  UI --> SV[Services: rules, permissions, transactions, audit]
  SV --> AN[Analytics: metrics, forecasting, decisions, costs]
  SV --> DB[(MySQL: tables + views)]
  AN -. pure functions .-> SV
  SV --> EX[Exports: Excel, Tableau CSV]
  EX --> XL[Excel / Pivot Tables]
  EX --> TB[Tableau Desktop]
  DB --> TB
```
Layers: **views** show things and collect input; **services** apply business rules, check permissions, run SQL in transactions
and write the audit log; **analytics** are pure functions that are easy to unit test; **core** holds configuration, database
access, security, validation and the visual identity.

## 4. Physical zones and the data they create

| Zone | Station codes | Writes to | Key rule |
|---|---|---|---|
| A Preparation Bay | PREP-A, PREP-B | prep_batches, inventory_movements (recipe usage) | several batches per item per day; cost from recipe, manual entry or menu estimate |
| B Service Counter | COUNTER-1 | service_records, footfall | cannot serve more than prepared; paid and complimentary kept apart; duplicate entries rejected |
| C Weigh & Return | SCALE-01 | weighing_records | manual weight, kg or g, edible vs not edible, plausibility check against prepared quantity |
| D Surplus Handling | SURPLUS-1 | waste_dispositions, donations | not-edible food can only be discarded; donation needs recipient and food-safety confirmation |
| E Ingredient Store | STORE-1 | inventory_movements, purchases | stock is the sum of signed movements, never an editable number |

Zones, stations, service periods, units and settings live in MySQL tables (`sql/reference_data.sql`), not in code.

## 5. ER diagram

```mermaid
erDiagram
  zones ||--o{ stations : contains
  categories ||--o{ menu_items : groups
  service_periods ||--o{ menu_items : "served in"
  menu_items ||--o{ recipe_ingredients : uses
  ingredients ||--o{ recipe_ingredients : "used in"
  units ||--o{ ingredients : measured_in
  suppliers ||--o{ purchases : supplies
  purchases ||--o{ inventory_movements : "creates lots"
  ingredients ||--o{ inventory_movements : tracked_by
  menu_items ||--o{ prep_batches : cooked_as
  stations ||--o{ prep_batches : "cooked at"
  prep_batches ||--o{ inventory_movements : "consumes"
  menu_items ||--o{ service_records : served_as
  service_periods ||--o{ footfall : counted_in
  menu_items ||--o{ weighing_records : leftover_of
  weighing_records ||--o{ waste_dispositions : "split into"
  waste_dispositions ||--o| donations : "may be"
  forecast_runs ||--o{ forecast_recommendations : produces
  menu_items ||--o{ forecast_recommendations : "planned for"
  forecast_recommendations ||--o| actual_outcomes : "evaluated by"
  forecast_recommendations ||--o{ prep_batches : "followed by"
  menu_items ||--o{ advisory_recommendations : "advice on"
  users ||--o{ audit_log : performs
```
The full column list with types, keys and meanings is in `docs/data_dictionary.md` (generated from the live schema).

## 6. KPI definitions

Counted = portions typed in. Measured = scale kg. Estimated = derived (kg / portion weight, or cost from recipe).

| KPI | Formula | Type |
|---|---|---|
| Surplus (expected leftover) | prepared − served | counted |
| Measured leftover portions | weighed kg ÷ `portion_weight_kg` | estimate |
| Unexplained portions | expected leftover − measured leftover portions | estimate |
| Reconciliation status | balanced if \|unexplained\| ≤ max(2, 5% of prepared); otherwise unexplained_loss, over_measured, not_weighed or invalid_counts | rule |
| Waste % | discarded portions (est.) ÷ prepared × 100 | estimate |
| Shortage rate | item-days flagged sold out ÷ item-days prepared × 100 | counted |
| Production cost | Σ batch qty × batch unit cost (recipe cost, manual cost or menu estimate) | estimate |
| Waste cost | discarded portions (est.) × average batch unit cost | estimate |
| Avoidable cost | the part of waste cost that was **edible** when discarded | estimate |
| Foregone revenue | selling price × discarded portions. An opportunity figure, **not** a cash loss | estimate |
| Donated value | donated portions (est.) × average batch unit cost | estimate |
| Forecast error | \|actual demand estimate − forecast\|; MAE = mean; RMSE = √mean(square) | estimate |
| Actual demand estimate | served; on sold-out days served × (1 + 10%) because sales understate demand | assumption |
| Waste per student | discarded portions (est.) ÷ observed footfall | estimate |

Tolerances and the sold-out uplift are rows in `config_settings`.

## 7. Forecasting methodology

1. **History per item:** daily served portions (with the sold-out uplift), observed footfall (history) and expected footfall.
2. **Validation:** fewer than 8 operating days gives "insufficient data" and no number is invented. All-zero history gives a recommendation of 0 for the manager to confirm.
3. **Candidate models** (each uses only dates before the target date):
   * `baseline`: mean of the last 4 same weekdays
   * `moving_avg_7`: mean of the last 7 operating days
   * `footfall_ratio`: baseline × expected footfall of the target day ÷ mean observed footfall on those days. Used **only** when expected footfall for the target day exists
   * `ridge`: scikit-learn Ridge on weekday, last same-weekday demand and 7-day mean (needs 28+ days)
4. **Chronological validation:** walk-forward over the last 14 operating days. Each day is predicted from earlier days only. Models are compared on the same days. MAE and RMSE are stored.
5. **Selection:** a candidate replaces the baseline only if its MAE is at least 5% lower and it was tested on 8+ days. Otherwise the simple baseline stays.
6. **Recommended quantity:** prediction + safety stock, where safety stock = the larger of a fixed buffer (5%, or 10% if the item sold out on a comparable day) and 1.0 × the item's backtest MAE. It is rounded to the item's step (5 or 10 portions) and never below the prediction. Items with erratic demand therefore get more cover.
7. **Manager control:** approve, adjust (reason required) or reject. The recommendation, the model, its inputs, the explanation, the approved quantity and later the actual outcome are all stored.
8. **Outcome evaluation:** after a day has batches and service records, `actual_outcomes` stores prepared, served, surplus, shortage and absolute error.

## 8. Decision engine (advisory rules)
Repeated surplus (suppressed when the item often sells out), repeated shortage, variable demand, unexplained discrepancies,
edible food discarded (donation opportunity) and ingredient spoilage. Each stores the problem, evidence (JSON), action,
expected benefit, confidence (by sample size), limitations, review status and, once implemented, a before/after comparison.
Food safety rules are enforced in the services: not-edible food cannot be donated or retained.

## 9. Security design
bcrypt password hashes; credentials only in `.env`; parameterised SQL everywhere; role checks inside services; audit rows written
in the same transaction as the change; error messages do not reveal credentials or SQL. Limitations are listed in the README.

## 10. Assumptions and risks

| Assumption / risk | Handling |
|---|---|
| Operators type quantities and weights correctly | validation, plausibility checks, reconciliation flags, audit trail |
| Portion weights are approximate | stored per item with a source note; all kg-to-portion figures labelled estimates |
| Sold-out days hide true demand | flagged; 10% uplift assumption (configurable); shortage rate reported separately |
| Demand shifts (exams, events) | not modelled; the manager can adjust and every change is recorded |
| Only 90 synthetic days exist | confidence labelled by sample size; no accuracy claims beyond the measured backtests |
| Forecast reduces waste but raises shortages | both are reported side by side; the safety multiplier is a setting |

## 11. Test strategy
Unit tests for formulas and forecasting (including leakage checks), integration tests against a real MySQL-compatible database for
constraints, business rules, permissions and transactions, end-to-end workflow tests, export-versus-MySQL reconciliation tests,
and a headless UI smoke test over every page and role. See `docs/testing.md` for the actual results.
