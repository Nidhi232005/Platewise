# Synthetic data

`python -m scripts.seed_synthetic --reset` creates a **synthetic** dataset (random seed 42 by default, fully reproducible).
Every batch, weighing and forecast it writes is flagged `is_synthetic = 1` (services records use `source = 'synthetic'`).
It is not data from any real college.

## Contents (default run)
87 operating days (Mon-Sat; 90 minus 3 random holidays) ending on the last operating day before today, 8 menu items in 3 categories,
16 ingredients with recipes, 2 suppliers, about 700 item-days, 940+ batches, 800+ weighings, donations, spoilage, 4 demo users.

## Generation rules
* **Demand** = base x weekday factor x trend (Samosa grows after day 40) x exam-week factor (4 days at 80%) x random noise (item-specific variation, Dal Tadka Thali deliberately erratic).
* **Before the intervention** (first ~59 days) the canteen cooks a fixed multiple of a typical day: Rajma Chawal 30% over (chronic overproduction), Chole Bhature 8% under (frequent sell-outs), others 8-12% over.
* **After the intervention** (last 28 operating days) preparation follows the forecasting module's recommendation, approved as-is 85% of the time and otherwise adjusted by 5 portions. The forecasts, approvals and outcomes are real outputs of the project's code on this synthetic history.
* **Footfall:** observed ~ demand x 0.95-1.15; expected = observed + 6% noise (so expected footfall is informative **by construction**); 6% of expected and 3% of observed values are missing.
* **Service:** 3% complimentary portions; two service entries per item per day; sold-out flag when demand exceeds preparation.
* **Leftovers:** 12% of leftovers are not weighed; 10% lose 20-40% of mass (spillage or staff meals) and 3% are over-measured, so reconciliation flags appear; 3-12% of weighed food is not edible; main meals are donated 70% of the time when at least 1 kg is edible.
* **Ingredients:** bought when stock is short (perishables for 2 days, others for 4); 30% of perishable lots lose 10-25% to spoilage; stock never goes negative.
* **Advisory rules** are run just before the intervention (surplus and shortage advice marked implemented on the intervention date) and again at the end.

Invalid quantities, duplicate entries and reconciliation errors are exercised in the pytest suite rather than loaded into the demo database.
