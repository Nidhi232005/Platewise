# PlateWise Data Dictionary

Generated from the live MySQL schema by `python -m scripts.gen_docs_assets`.
Quantities are COUNTED (portions) or MEASURED (kg). Columns ending `_est` are ESTIMATES. `is_synthetic = 1` marks generated test data.

## actual_outcomes

What actually happened for each evaluated recommendation (prepared, served, surplus, shortage, error).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| outcome_id | int(11) | NO | PK |  |
| rec_id | int(11) | NO | UNIQUE | Link to the forecast recommendation behind a batch or outcome. FK -> forecast_recommendations.rec_id |
| target_date | date | NO |  |  |
| item_id | int(11) | NO | index | FK -> menu_items.item_id |
| predicted_demand | decimal(9,2) | YES |  | Forecast demand in portions (an estimate). |
| recommended_qty | int(11) | YES |  | Suggested preparation quantity. |
| approved_qty | int(11) | YES |  | Quantity approved or entered by the manager. |
| prepared_qty | int(11) | NO |  |  |
| served_qty | int(11) | NO |  |  |
| actual_demand_est | decimal(9,2) | NO |  | Served portions, uplifted on sold-out days (censored demand assumption). |
| surplus_qty | int(11) | NO |  |  |
| discarded_portions_est | decimal(9,2) | NO |  |  |
| shortage_flag | tinyint(1) | NO |  |  |
| abs_error | decimal(9,2) | YES |  | Absolute difference between actual_demand_est and predicted_demand. |
| evaluated_at | datetime | NO |  |  |

## advisory_recommendations

Rule-based advice with problem, evidence, action, benefit, confidence, limitations, status and outcome.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| adv_id | int(11) | NO | PK |  |
| generated_on | date | NO |  |  |
| rule_code | varchar(40) | NO |  |  |
| item_id | int(11) | YES | index | FK -> menu_items.item_id |
| ingredient_id | int(11) | YES | index | FK -> ingredients.ingredient_id |
| problem | varchar(300) | NO |  |  |
| metrics_json | text | YES |  | Evidence behind a recommendation (JSON). |
| proposed_action | varchar(300) | NO |  |  |
| expected_benefit | varchar(250) | YES |  |  |
| confidence | enum('low','medium','high') | NO |  |  |
| limitations | varchar(300) | YES |  |  |
| status | enum('open','approved','rejected','implemented','closed') | NO | index |  |
| reviewed_by | int(11) | YES | index | FK -> users.user_id |
| reviewed_at | datetime | YES |  |  |
| implemented_on | date | YES |  |  |
| outcome_note | varchar(300) | YES |  |  |

## audit_log

Who changed what and when (written in the same transaction as the change).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| audit_id | int(11) | NO | PK |  |
| user_id | int(11) | YES | index | FK -> users.user_id |
| action | varchar(40) | NO |  |  |
| entity | varchar(40) | NO | index |  |
| entity_id | varchar(40) | YES |  |  |
| details | text | YES |  |  |
| created_at | datetime | NO |  |  |

## categories

Menu categories.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| category_id | int(11) | NO | PK |  |
| category_name | varchar(50) | NO | UNIQUE |  |

## config_settings

Tunable settings (buffers, tolerances, forecast parameters).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| setting_key | varchar(50) | NO | PK |  |
| setting_value | varchar(200) | NO |  |  |
| description | varchar(250) | YES |  |  |

## donations

Donation details: recipient and mandatory food-safety confirmation.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| donation_id | int(11) | NO | PK |  |
| disposition_id | int(11) | NO | UNIQUE | FK -> waste_dispositions.disposition_id |
| recipient_name | varchar(100) | NO |  |  |
| handed_over_at | datetime | NO |  |  |
| food_safety_checked | tinyint(1) | NO |  | Must be 1 for a donation (database CHECK). |
| note | varchar(250) | YES |  |  |

## footfall

Approximate students per service period: expected (known in advance) and observed (counted afterwards).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| footfall_id | int(11) | NO | PK |  |
| operating_date | date | NO | index |  |
| period_id | int(11) | NO | index | FK -> service_periods.period_id |
| expected_count | int(11) | YES |  | Expected students, known BEFORE service (allowed as a forecast input). |
| observed_count | int(11) | YES |  | Students counted afterwards (history only). |
| source | enum('manual','import','synthetic') | NO |  | manual, import or synthetic. |
| note | varchar(250) | YES |  |  |

## forecast_recommendations

Per-item forecast and recommended quantity, model used, explanation, manager decision.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| rec_id | int(11) | NO | PK | Link to the forecast recommendation behind a batch or outcome. |
| run_id | int(11) | NO | index | FK -> forecast_runs.run_id |
| item_id | int(11) | NO | index | FK -> menu_items.item_id |
| target_date | date | NO | index |  |
| model_used | varchar(40) | NO |  |  |
| predicted_demand | decimal(9,2) | YES |  | Forecast demand in portions (an estimate). |
| buffer_pct | decimal(5,3) | NO |  |  |
| recommended_qty | int(11) | YES |  | Suggested preparation quantity. |
| history_points | int(11) | NO |  |  |
| backtest_n | int(11) | NO |  |  |
| mae_baseline | decimal(9,3) | YES |  | Backtest MAE of the same-weekday baseline. |
| mae_selected | decimal(9,3) | YES |  | Backtest MAE of the model used. |
| expected_footfall | int(11) | YES |  |  |
| inputs_json | text | YES |  | Forecast inputs and backtest scores (JSON). |
| explanation | text | YES |  |  |
| status | enum('pending','approved','adjusted','rejected','superseded','insufficient_data') | NO |  |  |
| approved_qty | int(11) | YES |  | Quantity approved or entered by the manager. |
| reviewed_by | int(11) | YES | index | FK -> users.user_id |
| reviewed_at | datetime | YES |  |  |
| review_note | varchar(250) | YES |  |  |

## forecast_runs

One row per forecast generation (target date, model version, training end date).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| run_id | int(11) | NO | PK |  |
| target_date | date | NO | index |  |
| model_version | varchar(30) | NO |  |  |
| training_end_date | date | YES |  |  |
| created_by | int(11) | YES | index | FK -> users.user_id |
| created_at | datetime | NO |  |  |
| is_synthetic | tinyint(1) | NO |  | 1 = generated test data, not a real observation. |

## ingredients

Ingredient master with unit, latest cost, reorder level and shelf life.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| ingredient_id | int(11) | NO | PK |  |
| ingredient_name | varchar(80) | NO | UNIQUE |  |
| unit_code | varchar(10) | NO | index | FK -> units.unit_code |
| cost_per_unit | decimal(10,2) | NO |  |  |
| reorder_level | decimal(12,3) | NO |  |  |
| shelf_life_days | int(11) | NO |  |  |
| is_active | tinyint(1) | NO |  |  |

## inventory_movements

Signed stock ledger: purchase (+), usage (-), spoilage (-), adjustment (+/-). Current stock = SUM(quantity_change).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| movement_id | int(11) | NO | PK |  |
| ingredient_id | int(11) | NO | index | FK -> ingredients.ingredient_id |
| movement_type | enum('purchase','usage','spoilage','adjustment') | NO | index |  |
| quantity_change | decimal(12,3) | NO |  | Signed ingredient quantity in the ingredient's own unit. |
| unit_cost | decimal(10,2) | NO |  | Production cost per portion (batch) or cost per ingredient unit (movement). |
| movement_date | date | NO |  |  |
| expiry_date | date | YES |  |  |
| purchase_id | int(11) | YES | index | FK -> purchases.purchase_id |
| batch_id | int(11) | YES | index | FK -> prep_batches.batch_id |
| note | varchar(200) | YES |  |  |
| created_by | int(11) | YES | index | FK -> users.user_id |
| created_at | datetime | NO |  |  |

## menu_items

Menu items with price, portion weight (kg per portion, with documented source) and rounding step.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| item_id | int(11) | NO | PK |  |
| item_name | varchar(80) | NO | UNIQUE |  |
| category_id | int(11) | NO | index | FK -> categories.category_id |
| period_id | int(11) | NO | index | FK -> service_periods.period_id |
| selling_price | decimal(8,2) | NO |  |  |
| portion_weight_kg | decimal(6,3) | NO |  | Documented kg per portion; converts kg to portions (ESTIMATE). |
| portion_weight_source | varchar(200) | NO |  | Where the portion weight came from. |
| est_cost_per_portion | decimal(8,2) | YES |  |  |
| rounding_step | int(11) | NO |  | Recommendations are rounded to multiples of this many portions. |
| is_active | tinyint(1) | NO |  |  |
| created_at | datetime | NO |  |  |

## prep_batches

Zone A: one row per cooked batch (several per item per day allowed).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| batch_id | int(11) | NO | PK |  |
| batch_code | varchar(40) | NO | UNIQUE |  |
| operating_date | date | NO | index |  |
| item_id | int(11) | NO | index | FK -> menu_items.item_id |
| batch_no | int(11) | NO |  |  |
| station_id | int(11) | NO | index | FK -> stations.station_id |
| prepared_at | datetime | NO |  |  |
| qty_prepared | int(11) | NO |  | Portions cooked in the batch (counted). |
| unit_cost | decimal(8,2) | NO |  | Production cost per portion (batch) or cost per ingredient unit (movement). |
| cost_source | enum('recipe','manual','menu_estimate') | NO |  | recipe, manual, or menu_estimate. |
| operator_id | int(11) | YES | index | FK -> users.user_id |
| rec_id | int(11) | YES | index | Link to the forecast recommendation behind a batch or outcome. FK -> forecast_recommendations.rec_id |
| notes | varchar(250) | YES |  |  |
| is_synthetic | tinyint(1) | NO |  | 1 = generated test data, not a real observation. |
| created_at | datetime | NO |  |  |

## purchases

Purchase headers (supplier, date, invoice).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| purchase_id | int(11) | NO | PK |  |
| supplier_id | int(11) | NO | index | FK -> suppliers.supplier_id |
| purchase_date | date | NO |  |  |
| invoice_no | varchar(40) | YES |  |  |

## recipe_ingredients

Quantity of each ingredient per portion of a menu item.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| item_id | int(11) | NO | PK | FK -> menu_items.item_id |
| ingredient_id | int(11) | NO | PK | FK -> ingredients.ingredient_id |
| qty_per_portion | decimal(10,4) | NO |  |  |

## service_periods

Breakfast, Lunch, Evening snacks with operating hours.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| period_id | int(11) | NO | PK |  |
| period_name | varchar(30) | NO | UNIQUE |  |
| start_time | time | NO |  |  |
| end_time | time | NO |  |  |

## service_records

Zone B: portions served (paid vs complimentary), time, remaining, sold-out flag.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| service_id | int(11) | NO | PK |  |
| operating_date | date | NO | index |  |
| item_id | int(11) | NO | index | FK -> menu_items.item_id |
| period_id | int(11) | NO | index | FK -> service_periods.period_id |
| station_id | int(11) | NO | index | FK -> stations.station_id |
| served_at | datetime | NO |  |  |
| portions_paid | int(11) | NO |  | Portions sold for money (counted). |
| portions_complimentary | int(11) | NO |  | Free portions (counted, no revenue). |
| unit_price | decimal(8,2) | NO |  |  |
| remaining_after | int(11) | YES |  |  |
| sold_out_flag | tinyint(1) | NO |  | 1 if the item sold out (demand is then under-counted). |
| source | enum('manual','import','synthetic') | NO |  | manual, import or synthetic. |
| operator_id | int(11) | YES | index | FK -> users.user_id |
| note | varchar(250) | YES |  |  |
| created_at | datetime | NO |  |  |

## stations

Named stations inside zones: Prep Bay A/B, counter, SCALE-01, surplus table, store.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| station_id | int(11) | NO | PK |  |
| station_code | varchar(20) | NO | UNIQUE |  |
| station_name | varchar(60) | NO |  |  |
| zone_id | int(11) | NO | index | FK -> zones.zone_id |
| station_type | enum('prep','counter','scale','surplus','store') | NO |  |  |
| is_active | tinyint(1) | NO |  |  |

## suppliers

Ingredient suppliers.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| supplier_id | int(11) | NO | PK |  |
| supplier_name | varchar(80) | NO | UNIQUE |  |
| phone | varchar(20) | YES |  |  |

## units

Measurement units and their factor to the base unit.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| unit_code | varchar(10) | NO | PK |  |
| unit_name | varchar(30) | NO |  |  |
| unit_type | enum('count','mass','volume') | NO |  |  |
| to_base_factor | decimal(12,6) | NO |  |  |

## users

Application accounts. Passwords are stored only as bcrypt hashes.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| user_id | int(11) | NO | PK |  |
| username | varchar(50) | NO | UNIQUE |  |
| full_name | varchar(100) | NO |  |  |
| password_hash | varchar(100) | NO |  | bcrypt hash, never the password. |
| role | enum('admin','manager','operator','analyst') | NO |  |  |
| is_active | tinyint(1) | NO |  |  |
| created_at | datetime | NO |  |  |

## v_daily_item_summary (view)

VIEW: one row per date x item reconciling prepared, served, weighed, donated, discarded; costs; estimates labelled *_est.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| operating_date | date | NO |  |  |
| item_id | int(11) | NO |  |  |
| item_name | varchar(80) | NO |  |  |
| category_name | varchar(50) | NO |  |  |
| portion_weight_kg | decimal(6,3) | NO |  | Documented kg per portion; converts kg to portions (ESTIMATE). |
| selling_price | decimal(8,2) | NO |  |  |
| batches | bigint(21) | NO |  |  |
| prepared_portions | decimal(32,0) | YES |  |  |
| avg_unit_cost | decimal(44,6) | YES |  |  |
| prep_cost_total | decimal(40,2) | YES |  |  |
| paid_portions | decimal(32,0) | NO |  |  |
| comp_portions | decimal(32,0) | NO |  |  |
| served_portions | decimal(33,0) | NO |  |  |
| revenue | decimal(40,2) | NO |  |  |
| sold_out_flag | int(4) | NO |  | 1 if the item sold out (demand is then under-counted). |
| expected_leftover_portions | decimal(34,0) | YES |  | prepared - served (counted). |
| weigh_count | bigint(21) | NO |  |  |
| measured_kg | decimal(31,3) | NO |  |  |
| edible_kg | decimal(31,3) | NO |  |  |
| not_edible_kg | decimal(31,3) | NO |  |  |
| donated_kg | decimal(31,3) | NO |  |  |
| discarded_kg | decimal(31,3) | NO |  |  |
| discarded_edible_kg | decimal(31,3) | NO |  |  |
| retained_kg | decimal(31,3) | NO |  |  |
| other_loss_kg | decimal(31,3) | NO |  |  |
| measured_portions_est | decimal(38,7) | YES |  | measured kg / portion weight (ESTIMATE). |
| donated_portions_est | decimal(38,7) | YES |  |  |
| discarded_portions_est | decimal(38,7) | YES |  |  |
| retained_portions_est | decimal(38,7) | YES |  |  |
| unexplained_portions_est | decimal(42,7) | YES |  | expected leftover - measured portions (reconciliation gap). |
| discarded_cost_est | decimal(65,13) | YES |  | Discarded portions x average batch cost (ESTIMATE; not selling price). |
| avoidable_cost_est | decimal(65,13) | YES |  | Part of discarded cost that was edible when discarded. |
| donated_value_est | decimal(65,13) | YES |  |  |

## v_forecast_vs_actual (view)

VIEW: stored forecasts joined to actual outcomes.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| rec_id | int(11) | NO |  | Link to the forecast recommendation behind a batch or outcome. |
| target_date | date | NO |  |  |
| item_id | int(11) | NO |  |  |
| item_name | varchar(80) | NO |  |  |
| model_used | varchar(40) | NO |  |  |
| status | enum('pending','approved','adjusted','rejected','superseded','insufficient_data') | NO |  |  |
| predicted_demand | decimal(9,2) | YES |  | Forecast demand in portions (an estimate). |
| recommended_qty | int(11) | YES |  | Suggested preparation quantity. |
| approved_qty | int(11) | YES |  | Quantity approved or entered by the manager. |
| prepared_qty | int(11) | NO |  |  |
| served_qty | int(11) | NO |  |  |
| actual_demand_est | decimal(9,2) | NO |  | Served portions, uplifted on sold-out days (censored demand assumption). |
| surplus_qty | int(11) | NO |  |  |
| discarded_portions_est | decimal(9,2) | NO |  |  |
| shortage_flag | tinyint(1) | NO |  |  |
| abs_error | decimal(9,2) | YES |  | Absolute difference between actual_demand_est and predicted_demand. |

## v_inventory_stock (view)

VIEW: current stock per ingredient (sum of movements) with low-stock flag.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| ingredient_id | int(11) | NO |  |  |
| ingredient_name | varchar(80) | NO |  |  |
| unit_code | varchar(10) | NO |  |  |
| cost_per_unit | decimal(10,2) | NO |  |  |
| reorder_level | decimal(12,3) | NO |  |  |
| current_stock | decimal(34,3) | NO |  |  |
| stock_value | decimal(44,5) | NO |  |  |
| last_purchase_date | date | YES |  |  |
| low_stock_flag | int(1) | NO |  |  |

## waste_dispositions

Zone D: what happened to each weighed quantity (donated, discarded, retained, other loss).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| disposition_id | int(11) | NO | PK |  |
| weigh_id | int(11) | NO | index | FK -> weighing_records.weigh_id |
| disposition_type | enum('donated','discarded','retained','other_loss') | NO | index | donated, discarded, retained or other_loss. |
| weight_kg | decimal(9,3) | NO |  | Weight converted to kg (MEASURED, manual entry). |
| reason | varchar(200) | YES |  |  |
| decided_at | datetime | NO |  |  |
| station_id | int(11) | NO | index | FK -> stations.station_id |
| operator_id | int(11) | YES | index | FK -> users.user_id |

## weighing_records

Zone C: leftover weighed manually on a scale, with condition (edible / not edible) and reason.

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| weigh_id | int(11) | NO | PK |  |
| operating_date | date | NO | index |  |
| item_id | int(11) | NO | index | FK -> menu_items.item_id |
| batch_id | int(11) | YES | index | FK -> prep_batches.batch_id |
| station_id | int(11) | NO | index | FK -> stations.station_id |
| scale_id | varchar(20) | NO |  |  |
| weight_value | decimal(9,3) | NO |  | Weight as typed by the operator, in unit_code. |
| unit_code | varchar(10) | NO | index | FK -> units.unit_code |
| weight_kg | decimal(9,3) | NO |  | Weight converted to kg (MEASURED, manual entry). |
| food_condition | enum('edible','not_edible') | NO |  | edible or not_edible (not edible food can only be discarded). |
| reason_code | enum('overproduction','low_demand','quality_issue','spillage','plate_return','other') | NO |  | Why food was left over. |
| weighed_at | datetime | NO |  |  |
| operator_id | int(11) | YES | index | FK -> users.user_id |
| note | varchar(250) | YES |  |  |
| is_synthetic | tinyint(1) | NO |  | 1 = generated test data, not a real observation. |
| created_at | datetime | NO |  |  |

## zones

The five physical canteen zones A-E (configurable).

| Column | Type | Null | Key | Meaning |
|---|---|---|---|---|
| zone_id | int(11) | NO | PK |  |
| zone_code | char(1) | NO | UNIQUE |  |
| zone_name | varchar(60) | NO |  |  |
| description | varchar(200) | YES |  |  |
| sort_order | int(11) | NO |  |  |
