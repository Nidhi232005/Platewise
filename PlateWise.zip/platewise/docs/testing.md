# Testing: actual results

All figures below were produced by running the commands on this code base on **23 Oct 2026**, using **MariaDB 10.11.14**
(MySQL-compatible), Python 3.12, pandas 3.0, SQLAlchemy 2.1, Streamlit 1.66. Oracle MySQL was not available, so the suite has **not** been run on it.

## 1. Automated test suite
```
$ python -m pytest -q
97 passed in 31.95s
```

| File | Tests | What it checks |
|---|---|---|
| test_metrics.py | 13 | waste %, surplus, unit conversion, MAE/RMSE, shortage rate, every reconciliation status, FIFO batch allocation, cost breakdown, before/after, FIFO lots and expiry alerts, zero preparation / zero sales |
| test_forecasting.py | 15 | baseline value, only the last k same weekdays used, **no future leakage** (poisoning data on/after the target date changes nothing), walk-forward backtest uses earlier rows only, insufficient data, new item, zero demand, sold-out uplift, rounding, safety stock grows with error, model selection rules, footfall used only when expected footfall exists, missing footfall fallback |
| test_security_validation.py | 13 | bcrypt hashing, permission matrix for all roles, unknown role / anonymous denied, input validation rules |
| test_decisions.py | 5 | each advisory rule, surplus cuts blocked when an item often sells out, short history ignored |
| test_database.py | 36 | schema objects, configuration stored in MySQL, 9 CHECK/FK/UNIQUE violations rejected by the database, recipe cost and ingredient usage, multiple batches, duplicate double-click prevented with no partial save, invalid quantities, future dates, station types, batch correction with stock adjustment and audit, served cannot exceed prepared, paid vs complimentary (no revenue for free meals), kg/g conversion, unexplained gap flagged, food-safety rules, over-allocated dispositions, stock ledger equals sum of movements, spoilage rules, roles enforced in services, login (including SQL-injection string), audit trail, **connection failure handled without leaking credentials** |
| test_workflow.py | 13 | **end to end:** history, forecast, manager approve/adjust/reject, rerun keeps approved plans, batches linked to the recommendation, service, evaluation of the actual outcome (idempotent), sold-out day counted as shortage, advisory lifecycle with measured outcome, all 13 SQL reports run, Excel totals equal MySQL totals, tampered workbook detected, date-filtered export matches filtered MySQL, Tableau ZIP control totals |
| test_seed.py | 2 | generator is reproducible (same seed gives identical data, different seed differs), everything labelled synthetic, stock never negative, nothing served beyond prepared, controlled data-quality problems present |

Database tests run against a separate database (`platewise_test`) that they drop and recreate. If no server is reachable they are skipped.

## 2. UI smoke test
```
$ python -m scripts.smoke_ui             # default date (today, no data: empty states)  -> Pages/roles with errors: 0
$ python -m scripts.smoke_ui --data-day  # latest date with data                         -> Pages/roles with errors: 0
```
All 14 pages were opened as each of the 4 roles (56 combinations per run, 112 page loads) with Streamlit's `AppTest`. No exception or error element appeared.
Pages a role may not open redirect to Operations Overview (manager: Users; operator: SQL reports, Reports, Users, Audit; analyst: Users, Audit).
**This is a smoke test of rendering, not a test of every button.** Form actions are covered by the service-level tests above.

## 3. Reconciliation checks run by hand
* Excel workbook built from the demo database (73,670 prepared / 64,421 served): column sums equal the MySQL base-table totals, including discarded kg (1,506.743) and donated kg (904.933).
* The workbook's `Summary` formulas were recalculated in LibreOffice: TOTAL prepared 73,670, served 64,421, waste 7.194%, no formula errors. Waste cost 86,546.31 in Excel versus 86,546.32 in Python (per-row rounding to 2 decimals).
* Tableau ZIP: `control_totals.csv` equals the sum of `fact_daily_item.csv` (tested).

## 4. Problems found while testing (and fixed)
1. A forecast test used the wrong cutoff date (a test error, not a code error).
2. A duplicate service entry was rejected with the "more than prepared" message instead of the duplicate message; the check order was changed.
3. The first stand-alone zone-map SVG was invalid XML (duplicate `xmlns`), and its arrow heads and labels were oversized or clipped. Found by rendering the SVG to an image; fixed.
4. After the first seed run, following the forecast cut waste but raised sold-out days. The recommendation now adds safety stock proportional to each item's measured forecast error (`safety_mae_multiplier`). See the report for the measured effect.

## 5. Not tested
* Oracle MySQL; Windows; Tableau; Excel desktop (only LibreOffice); real browsers or screenshots; load or concurrency; HTTPS deployment; real canteen data.
