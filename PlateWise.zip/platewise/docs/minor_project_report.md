# PlateWise: Smart Canteen Food Waste & Demand Intelligence System
### MCA Minor Project Report

> **Evidence labels used in this report.** *Implemented* = exists in the code and is covered by the tests in `docs/testing.md`.
> *Simulated* = measured on the synthetic dataset only. *Planned* = not built. *Real-world result* = none; the system has not been deployed.
> Names, canteen ("The Daily Table - Campus Kitchen") and all data are fictional.
> **Screenshots:** none are included because no browser was available when the project was built. See Appendix A for the shots you must capture yourself from the running application.

---

## 1. Abstract
Canteens decide how much to cook from habit and rarely record cooked, sold, left-over, donated and discarded quantities together. PlateWise is a
Python / Streamlit / MySQL application that records this flow through five physical zones (preparation, service, weighing, surplus handling, ingredient store),
reconciles counted portions with weighed leftovers, estimates next-day demand with an explainable forecasting module that is validated chronologically, lets the
manager approve or change each quantity, and then stores what actually happened so that forecasts and advice can be judged. It also produces Excel and Tableau-ready
data that reconcile to the database. On 87 days of **synthetic** data, forecasts selected by walk-forward validation had a mean absolute error of 11.4 portions against 13.1
for a same-weekday baseline (about 14% lower, partly because the synthetic footfall is informative by design). Planning from forecasts changed waste from 7.2% to 7.3% and
sold-out days from 25% to 23% of item-days: a shift in the waste/shortage balance, not a clear improvement. No real-world result is claimed.

## 2. Introduction
Food waste has financial, environmental and ethical costs; the UNEP Food Waste Index Report 2021 estimates that a large share of food produced is wasted, with
households and food service contributing heavily. A college canteen is a small, controllable setting in which better preparation decisions are possible if the right records exist.

## 3. Problem statement
1. Preparation quantities are decided without systematic use of history.
2. Leftovers are not measured, so waste cannot be separated from edible surplus or unexplained loss.
3. Over-production (waste) and under-production (sold out) are not tracked together.
4. Recommendations, if any, are never compared with outcomes.

## 4. Objectives
1. Model the canteen's physical workflow in a relational database.
2. Record preparation, service, leftovers, dispositions, donations and ingredient stock with validation.
3. Reconcile counted and measured quantities and flag unexplained differences.
4. Produce explainable, chronologically validated demand estimates and let the manager decide.
5. Store every recommendation and its actual outcome.
6. Provide cost, waste and shortage analytics, Excel reports and Tableau-ready data.
7. Provide authentication, role-based access and an audit trail.

## 5. Scope and limitations
In scope: single canteen, manual data entry, local deployment. Out of scope: scale/POS integration, payments, multiple canteens, mobile app.
Limitations are listed in Section 22.

## 6. Limitations of the existing (manual) system
Paper registers or memory; no link between preparation and sales; no weights; no cost view; no feedback loop; waste known only by eye.

## 7. Proposed system
A Streamlit application with 14 pages (Operations Overview, Zone Map, Batch Board, Service Counter, Waste Desk, Demand Studio, Recommendation Review, Waste Intelligence,
SQL Reports, Inventory, Menu, Reports & Exports, Users, Audit), a service layer enforcing business rules, an analytics layer of pure functions, and MySQL storage. *Implemented.*

## 8. Requirements
**Functional:** FR1 record batches (several per item per day); FR2 record served portions (paid / complimentary) and footfall; FR3 record weighed leftovers (kg or g) with condition and reason;
FR4 record donated / discarded / retained / other loss with food-safety rules; FR5 stock ledger with spoilage, expiry and recipes; FR6 forecasts with explanation; FR7 manager approval or adjustment;
FR8 outcome evaluation; FR9 advisory rules; FR10 reports, Excel and Tableau data; FR11 login, roles, audit.
**Non-functional:** correctness (constraints, transactions), explainability, security (hashing, parameterised SQL, role checks), maintainability (layers, tests), usability (validation messages, empty states), configurability (zones and settings in the database).

## 9. Feasibility
Technical: all components are open source and run on a laptop. Economic: no licence cost (Tableau Desktop optional). Operational: needs a tablet or PC in the kitchen and a scale; entry effort is the main risk. Time: suitable for one semester.

## 10. System architecture
See `docs/architecture.md`: views (UI) → services (rules, permissions, transactions, audit) → analytics (pure functions) → MySQL; exports feed Excel and Tableau.

## 11. Use-case diagram
```mermaid
flowchart LR
  OP([Operator]) --> U1(Record batch) & U2(Record service and footfall) & U3(Weigh leftovers) & U4(Record disposition / donation) & U5(Record stock and spoilage)
  MG([Manager]) --> U6(Generate and review forecast) & U7(Review advisory rules) & U8(Edit menu and recipes) & U1 & U3
  AN([Analyst]) --> U9(View analytics) & U10(Export Excel / Tableau data)
  AD([Administrator]) --> U11(Manage users) & U12(View audit history)
```

## 12. Data-flow diagrams
**Level 0**
```mermaid
flowchart LR
  Staff[Canteen staff] -->|quantities, weights| P((PlateWise))
  P -->|plans, alerts, reports| Staff
  P <--> DB[(MySQL)]
  P -->|Excel / CSV| Ext[Excel, Tableau]
```
**Level 1**
```mermaid
flowchart TD
  A[1 Record operations] --> D1[(prep, service, weighing, disposition)]
  D1 --> B[2 Validate and reconcile]
  B --> D2[(views: daily summary)]
  D2 --> C[3 Forecast and backtest]
  C --> D3[(forecast recommendations)]
  D3 --> E[4 Manager review]
  E --> A
  D1 --> F[5 Evaluate outcome]
  D3 --> F
  F --> D4[(actual outcomes)]
  D2 & D4 --> G[6 Analytics, advice, exports]
```

## 13. ER diagram
Mermaid ER diagram in `docs/architecture.md`; column-level detail in `docs/data_dictionary.md`.

## 14. Relational schema and normalization
24 tables. Reference tables (zones, stations, units, service_periods, categories, config_settings) remove repeated text from transactions. `menu_items` holds item attributes only; recipes are a
junction table (`recipe_ingredients`, composite primary key) resolving the many-to-many between items and ingredients (3NF: every non-key column depends on the whole key and nothing else).
Stock is **derived** (`SUM(quantity_change)` in view `v_inventory_stock`) instead of stored, avoiding update anomalies and conflicting copies. Weighings and dispositions are separate (one weighing can be split into donated / discarded / retained).
Deliberate denormalisation: `prep_batches.unit_cost` stores the cost at the time of cooking so history is not rewritten when ingredient prices change; `weight_kg` is stored next to the typed value and unit.
Integrity: primary keys on every table; 39 foreign keys; 26 CHECK constraints (positive quantities, movement sign, donation requires food-safety confirmation); 14 UNIQUE constraints (batch per day, service slot, footfall per period); 14 named secondary indexes on date/item lookups (counts read from the live schema).

## 15. Forecasting algorithm
Described in `docs/architecture.md` §7. Summary: same-weekday mean of the last 4 weeks as the reference; moving average, footfall ratio and Ridge regression as candidates; walk-forward validation over the last 14 days using only earlier data;
a candidate is adopted only if its MAE is at least 5% lower on 8+ test days; recommended quantity = prediction + safety stock (larger of a 5% / 10% buffer and 1 × backtest MAE), rounded to the item's step; insufficient data and zero demand handled explicitly; sold-out days uplifted by 10% because observed sales understate demand. *Implemented.*

## 16. SQL query explanations
`sql/analytical_queries.sql` holds 13 named queries run by the SQL Reports page, for example:
* *Highest-waste items*: `GROUP BY item` over the view with `HAVING SUM(prepared) > 0`, ordered by waste %.
* *Weekday demand*: `GROUP BY WEEKDAY(date), item` with `AVG`.
* *Above-average waste*: a **subquery** in `HAVING` compares each item with the overall waste ratio.
* *Variable demand*: `STDDEV_SAMP / AVG` (coefficient of variation) with `HAVING COUNT(*) >= 10`.
* *Donations by recipient*: four-table `JOIN`.
* *Reconciliation exceptions*: subquery in `FROM`, `GREATEST` for the tolerance.
`v_daily_item_summary` joins four pre-aggregated subqueries (batches, service, weighings, dispositions) to avoid the row multiplication that occurs when several one-to-many tables are joined directly.

## 17. Python implementation
`core/` (configuration, SQLAlchemy engine, bcrypt security, validation, UI kit), `services/` (one module per business area; every write checks permission, validates, runs in a transaction and logs to `audit_log`),
`analytics/` (pure, unit-tested), `exports/`, `views/` (UI only), `scripts/` (schema creation, synthetic data, smoke test, documentation assets).

## 18. Excel reporting methodology
Datasets are produced from the same views and tables as the dashboards, written with pandas and openpyxl as nine Excel Tables with typed columns and date formats, a README sheet defining every calculated field, a SUMIFS summary and a PivotTable guide.
The workbook is verified against independent totals from the base tables. **It contains no native PivotTable objects**; the guide shows how to create them. *Implemented; Excel desktop was not available, LibreOffice recalculation was used.*

## 19. Tableau dashboard design
Four dashboards (Executive, Demand, Waste, Impact) are specified with fields and calculated fields in `docs/tableau_guide.md`; CSV data sources and control totals are generated. **No Tableau workbook exists.** *Planned (build in Tableau Desktop).*

## 20. Test cases
97 automated tests plus a 112-page-load UI smoke test; categories, counts and actual output in `docs/testing.md`.

## 21. Results and evaluation (all SIMULATED on synthetic data)

**Dataset:** 87 operating days, 8 items, 696 item-days; 59 days cooked by a fixed rule ("before"), the last 28 operating days planned from stored forecasts ("after"), all generated by `scripts/seed_synthetic.py` (seed 42).

**A. Forecast accuracy** (224 forecast-days, error against actual demand estimate, out of sample):

| Method | MAE (portions) | RMSE |
|---|---|---|
| Selected model per item/day (as used) | **11.36** | **14.68** |
| Same-weekday baseline | 13.14 | 18.35 |
| 7-day moving average | 14.28 | 20.41 |

Mean demand was 97.1 portions per item-day, so the selected-model error is about 12% of demand. By selected model: footfall ratio (75 forecasts) MAE 11.70 vs baseline 16.58; Ridge (85) 10.30 vs 10.90;
baseline (46) 13.03; moving average (18) 10.65 vs baseline 9.62 (here the choice was **worse** than the baseline). *Caveat:* synthetic expected footfall is a noisy copy of real footfall, so the footfall model's advantage is built into the data and may not appear in a real canteen.

**B. Waste and shortage, before vs after planning from forecasts** (descriptive, not causal):

| | Item-days | Waste % (est.) | Sold-out item-days | Est. waste cost |
|---|---|---|---|---|
| Before (fixed rule) | 472 | 7.17% | 25.0% | Rs 59,401 over 59 days |
| After (forecast-planned) | 224 | 7.25% | 23.2% | Rs 27,145 over 28 days |

Per item the effects are mixed: Chole Bhature sold out on 73% of days before and 21% after (waste 1.3% to 3.4%); Rajma Chawal waste fell 10.9% to 6.4% but it started to sell out (0% to 14%); Poha and Veg Sandwich waste rose.
With the first version of the recommendation rule (a fixed 5% buffer) waste fell from 7.2% to about 5.5% but sold-out days rose from 25% to about 33%, which is why the safety stock is now tied to each item's forecast error. **Conclusion:** on this synthetic data the system
can move the balance between waste and shortage and makes the trade-off visible, but it did not reduce both at once. The multiplier is a manager-controlled setting.

**C. Data quality:** 615 of 696 item-days reconciled, 57 were not weighed, 16 had an unexplained loss and 8 were over-measured; these are generated problems, so the proportions only show that the flags work.

**D. Integrity checks:** Excel and CSV totals equal MySQL totals (tested); `Summary` formulas recalculated in LibreOffice match.

## 22. Limitations
* All results are synthetic and simulated; no real canteen data or deployment result exists.
* Operators type weights and counts; errors are caught only by validation and reconciliation.
* kg to portions is an estimate from documented portion weights; costs come from recipes and are estimates.
* Sold-out demand uses a 10% assumption; real lost demand is unknown. Exam weeks and events are not modelled.
* The before/after comparison is descriptive; demand and other factors also change.
* Tested on MariaDB 10.11, Python 3.12; not on Oracle MySQL, Windows, Excel desktop or Tableau. No native PivotTables, no Tableau workbook, no screenshots.
* Security is for a local demonstration: no HTTPS, no database lockout, no e-mail password reset.

## 23. Future enhancements
Scale and POS integration (the schema already stores `scale_id`); holiday / exam calendar as a forecast input; item-level service-level targets; mobile entry; native PivotTables via Excel automation; Tableau workbook; multi-canteen support; photo-based portion estimation.

## 24. Conclusion
PlateWise demonstrates a complete, tested feedback loop (record, reconcile, forecast, decide, observe, evaluate) on a relational database with honest labelling of counted, measured and estimated quantities.
Its synthetic evaluation shows both the promise of validated forecasting (lower error than the baseline) and the practical trade-off between waste and shortages. Real value can only be shown by running it on real canteen records.

## 25. References
1. Hyndman, R. J. and Athanasopoulos, G., *Forecasting: Principles and Practice*, 3rd ed., OTexts, 2021 (forecast accuracy measures, time-series cross-validation).
2. UNEP, *Food Waste Index Report 2021*, United Nations Environment Programme, 2021.
3. Elmasri, R. and Navathe, S. B., *Fundamentals of Database Systems*, Pearson (relational model, normalization).
4. Pedregosa, F. et al., "Scikit-learn: Machine Learning in Python", *Journal of Machine Learning Research* 12, 2011.
5. McKinney, W., "Data Structures for Statistical Computing in Python", *Proceedings of the 9th Python in Science Conference*, 2010.
6. Official documentation: MySQL 8.0 Reference Manual; SQLAlchemy 2.0; Streamlit; openpyxl; pytest; Tableau Desktop help.

---
## Appendix A: Screenshots to capture from the running application
Run `streamlit run app.py` on the seeded database and capture: (1) login; (2) Operations Overview on the latest data date; (3) Canteen Floor & Zones; (4) Batch Preparation Board; (5) Waste Measurement Desk with a weighing and reconciliation result;
(6) Demand Planning Studio with explanations and the model check tab; (7) Waste Intelligence "Before / after" tab; (8) Reports & Exports after building the workbook ("Verified" message). Mark them "synthetic data".

## Appendix B: Evidence status summary

| Item | Status |
|---|---|
| 14-page Streamlit application, roles, audit | Implemented, tested (suite + smoke) |
| MySQL schema, views, 13 SQL reports | Implemented, tested on MariaDB 10.11 |
| Reconciliation, cost, shortage metrics | Implemented, tested |
| Forecast, backtest, approval, outcome evaluation | Implemented, tested |
| Excel workbook with pivot-ready tables | Implemented, verified against MySQL |
| Native PivotTables | Not implemented (guide provided) |
| Tableau CSVs and guide | Implemented |
| Tableau workbook | Not created |
| Application screenshots | Not included |
| Forecast accuracy, waste/shortage figures | Simulated (synthetic data) |
| Real canteen results | None |
