"""Decision-engine rule tests (no database)."""
import pandas as pd

from analytics import decisions


def daily(prep, served, sold_out_days=0, n=21):
    return pd.DataFrame({
        "operating_date": pd.date_range("2026-10-01", periods=n), "item_id": 1, "item_name": "Rajma", "prepared_portions": prep, "served_portions": served,
        "sold_out_flag": [1 if i < sold_out_days else 0 for i in range(n)], "discarded_portions_est": 10.0, "avg_unit_cost": 20.0,
        "recon_status": "balanced", "discarded_edible_kg": 0.0, "portion_weight_kg": 0.4})


def rules(df):
    return {r["rule_code"] for r in decisions.generate(df)}


def test_repeated_surplus_triggers_reduce():
    r = decisions.generate(daily(100, 70))
    assert "repeated_surplus" in {x["rule_code"] for x in r}
    rec = next(x for x in r if x["rule_code"] == "repeated_surplus")
    for key in ("problem", "metrics_json", "proposed_action", "expected_benefit", "confidence", "limitations"):
        assert rec[key]


def test_surplus_rule_blocked_when_item_often_sells_out():
    assert "repeated_surplus" not in rules(daily(100, 70, sold_out_days=10))  # safety: no cuts while running short


def test_repeated_shortage_rule():
    assert "repeated_shortage" in rules(daily(100, 98, sold_out_days=8))


def test_balanced_item_triggers_nothing_and_short_history_is_ignored():
    assert rules(daily(100, 97)) == set()
    assert decisions.generate(daily(100, 70, n=4)) == []
    assert decisions.generate(pd.DataFrame()) == []


def test_unexplained_discrepancy_and_donation_rules():
    d = daily(100, 97)
    d.loc[:4, "recon_status"] = "unexplained_loss"
    d["discarded_edible_kg"] = 0.5
    assert {"unexplained_discrepancy", "donation_opportunity"} <= rules(d)
