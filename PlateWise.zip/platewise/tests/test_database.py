"""Integration tests against a real MySQL/MariaDB test database."""
from datetime import datetime, timedelta

import pytest
from sqlalchemy import text
from sqlalchemy.exc import DBAPIError, SQLAlchemyError, IntegrityError

from analytics import metrics
from core import database as db
from core import security
from core.security import PermissionDenied
from core.validation import ValidationError
from services import audit, common, inventory_service as inv, preparation_service as prep, sales_service as sales, waste_service as ws
from tests.conftest import PASSWORD, operating_days_back


def run(engine, sql, **p):
    with engine.begin() as c:
        return c.execute(text(sql), p)


# ---------- constraints ----------
def test_schema_has_expected_objects(world):
    names = set(db.query_df("SELECT table_name AS n FROM information_schema.tables WHERE table_schema=DATABASE()")["n"].str.lower())
    for t in ["users", "zones", "stations", "menu_items", "ingredients", "recipe_ingredients", "prep_batches", "service_records", "footfall", "weighing_records",
              "waste_dispositions", "donations", "inventory_movements", "forecast_runs", "forecast_recommendations", "actual_outcomes", "audit_log",
              "v_daily_item_summary", "v_inventory_stock", "v_forecast_vs_actual"]:
        assert t in names, t


def test_reference_data_is_configurable_in_database(world):
    z = db.query_df("SELECT zone_code FROM zones ORDER BY zone_code")["zone_code"].tolist()
    assert z == ["A", "B", "C", "D", "E"]
    assert set(common.stations()["station_code"]) >= {"PREP-A", "PREP-B", "COUNTER-1", "SCALE-01", "SURPLUS-1", "STORE-1"}
    assert common.settings()["tol_portions"] == 2.0


@pytest.mark.parametrize("sql", [
    "INSERT INTO prep_batches (batch_code, operating_date, item_id, batch_no, station_id, prepared_at, qty_prepared, unit_cost, cost_source) VALUES ('X1','2026-01-01',:i,1,:s,NOW(),0,1,'manual')",
    "INSERT INTO prep_batches (batch_code, operating_date, item_id, batch_no, station_id, prepared_at, qty_prepared, unit_cost, cost_source) VALUES ('X2','2026-01-01',:i,1,:s,NOW(),5,-1,'manual')",
    "INSERT INTO prep_batches (batch_code, operating_date, item_id, batch_no, station_id, prepared_at, qty_prepared, unit_cost, cost_source) VALUES ('X3','2026-01-01',99999,1,:s,NOW(),5,1,'manual')",
    "UPDATE menu_items SET selling_price=-5 WHERE item_id=:i",
    "UPDATE menu_items SET portion_weight_kg=0 WHERE item_id=:i",
    "INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date) VALUES (1,'usage',5,1,'2026-01-01')",
    "INSERT INTO inventory_movements (ingredient_id, movement_type, quantity_change, unit_cost, movement_date) VALUES (1,'purchase',-5,1,'2026-01-01')",
    "INSERT INTO users (username, full_name, password_hash, role) VALUES ('admin','dup','h','admin')",
    "INSERT INTO users (username, full_name, password_hash, role) VALUES ('newuser','n','h','superuser')",
])
def test_database_rejects_invalid_rows(world, sql):
    with pytest.raises(DBAPIError):
        run(world["engine"], sql, i=world["item_a"], s=world["st"]["PREP-A"])


def test_service_row_needs_portions_unless_sold_out(world):
    base = ("INSERT INTO service_records (operating_date, item_id, period_id, station_id, served_at, portions_paid, portions_complimentary, unit_price, sold_out_flag) "
            "VALUES ('2026-01-02',:i,:p,:s,'2026-01-02 12:00:00',0,0,10,:so)")
    with pytest.raises(DBAPIError):
        run(world["engine"], base, i=world["item_a"], p=world["lunch"], s=world["st"]["COUNTER-1"], so=0)
    run(world["engine"], base, i=world["item_a"], p=world["lunch"], s=world["st"]["COUNTER-1"], so=1)  # sold-out marker is allowed


def test_donation_requires_safety_check_at_database_level(world):
    with pytest.raises(DBAPIError):
        run(world["engine"], "INSERT INTO donations (disposition_id, recipient_name, handed_over_at, food_safety_checked) VALUES (1,'x',NOW(),0)")


# ---------- preparation ----------
def test_create_batch_cost_usage_and_multiple_batches(world):
    op, d = world["users"]["operator"], operating_days_back(30)[0]
    r1 = prep.create_batch(op, d, world["item_a"], world["st"]["PREP-A"], 100, datetime.combine(d, datetime.min.time()).replace(hour=11))
    assert r1["cost_source"] == "recipe" and r1["unit_cost"] == pytest.approx(11.40)
    r2 = prep.create_batch(op, d, world["item_a"], world["st"]["PREP-B"], 60, datetime.combine(d, datetime.min.time()).replace(hour=11, minute=40))
    assert r1["batch_code"].endswith("-1") and r2["batch_code"].endswith("-2")
    usage = db.query_df("SELECT ingredient_id, SUM(quantity_change) AS q FROM inventory_movements WHERE movement_type='usage' AND movement_date=:d GROUP BY ingredient_id", {"d": d})
    got = {int(r.ingredient_id): float(r.q) for r in usage.itertuples()}
    assert got[world["rice"]] == pytest.approx(-16.0) and got[world["oil"]] == pytest.approx(-1.6)
    stock = inv.stock().set_index("ingredient_id")
    assert float(stock.loc[world["rice"], "current_stock"]) == pytest.approx(500 - 16.0 - 0.0, abs=20)  # other tests may add usage; sign/size checked above
    summary = common.daily_summary(d, d, item_id=world["item_a"]).iloc[0]
    assert summary["prepared_portions"] == 160 and summary["batches"] == 2 and summary["avg_unit_cost"] == pytest.approx(11.4)


def test_batch_without_recipe_uses_menu_estimate_and_missing_cost_is_rejected(world):
    op, d = world["users"]["operator"], operating_days_back(30)[1]
    r = prep.create_batch(op, d, world["item_b"], world["st"]["PREP-A"], 200)
    assert r["cost_source"] == "menu_estimate" and r["unit_cost"] == 6.0
    admin = world["users"]["admin"]
    from services import menu_service as ms
    cat = int(ms.categories().iloc[0]["category_id"])
    nocost = ms.save_item(admin, "No Cost Item", cat, world["lunch"], 10, 0.2, "test", None, 5)
    with pytest.raises(ValidationError, match="No cost"):
        prep.create_batch(op, d, nocost, world["st"]["PREP-A"], 10)


def test_duplicate_batch_double_click_is_prevented_and_nothing_partial_is_saved(world):
    op, d = world["users"]["operator"], operating_days_back(30)[2]
    prep.create_batch(op, d, world["item_a"], world["st"]["PREP-A"], 50)
    before = db.scalar("SELECT COUNT(*) FROM inventory_movements")
    with pytest.raises(ValidationError, match="identical batch"):
        prep.create_batch(op, d, world["item_a"], world["st"]["PREP-A"], 50)
    assert db.scalar("SELECT COUNT(*) FROM inventory_movements") == before
    assert db.scalar("SELECT COUNT(*) FROM prep_batches WHERE operating_date=:d AND item_id=:i", {"d": d, "i": world["item_a"]}) == 1


@pytest.mark.parametrize("qty", [0, -5, "abc", 10**7])
def test_invalid_quantity_rejected(world, qty):
    with pytest.raises(ValidationError):
        prep.create_batch(world["users"]["operator"], operating_days_back(30)[3], world["item_a"], world["st"]["PREP-A"], qty)


def test_future_date_rejected_and_wrong_station_type_rejected(world):
    op = world["users"]["operator"]
    with pytest.raises(ValidationError, match="future"):
        prep.create_batch(op, datetime.now().date() + timedelta(days=2), world["item_a"], world["st"]["PREP-A"], 10)
    with pytest.raises(ValidationError, match="prep station"):
        prep.create_batch(op, operating_days_back(30)[3], world["item_a"], world["st"]["SCALE-01"], 10)


def test_update_batch_quantity_adjusts_stock_and_writes_audit(world):
    op, d = world["users"]["operator"], operating_days_back(30)[4]
    b = prep.create_batch(op, d, world["item_a"], world["st"]["PREP-A"], 100)
    rice_before = float(inv.stock().set_index("ingredient_id").loc[world["rice"], "current_stock"])
    prep.update_batch_qty(op, b["batch_id"], 80, "counted wrongly")
    rice_after = float(inv.stock().set_index("ingredient_id").loc[world["rice"], "current_stock"])
    assert rice_after - rice_before == pytest.approx(2.0)  # 20 fewer portions x 0.10 kg returned to stock
    a = audit.recent(5, "prep_batch")
    assert "counted wrongly" in " ".join(a["details"])
    with pytest.raises(ValidationError):
        prep.update_batch_qty(op, b["batch_id"], 80, "same")
    with pytest.raises(ValidationError):
        prep.update_batch_qty(op, b["batch_id"], 70, "")


# ---------- service ----------
def test_service_rules_paid_vs_complimentary_no_double_count_and_cap(world):
    op, d = world["users"]["operator"], operating_days_back(30)[5]
    prep.create_batch(op, d, world["item_a"], world["st"]["PREP-A"], 100)
    r = sales.record_service(op, d, world["item_a"], world["lunch"], world["st"]["COUNTER-1"], 60, 4, datetime.combine(d, datetime.min.time()).replace(hour=12, minute=30))
    assert r["remaining"] == 36
    with pytest.raises(ValidationError, match="more than the 100 prepared"):
        sales.record_service(op, d, world["item_a"], world["lunch"], world["st"]["COUNTER-1"], 40, 0, datetime.combine(d, datetime.min.time()).replace(hour=13))
    with pytest.raises(ValidationError, match="double entry"):
        sales.record_service(op, d, world["item_a"], world["lunch"], world["st"]["COUNTER-1"], 60, 4, datetime.combine(d, datetime.min.time()).replace(hour=13, minute=5))
    row = common.daily_summary(d, d, item_id=world["item_a"]).iloc[0]
    assert row["served_portions"] == 64 and row["paid_portions"] == 60 and row["comp_portions"] == 4
    assert row["revenue"] == pytest.approx(60 * 70.0)  # complimentary meals earn no revenue


def test_service_needs_a_batch_and_some_quantity(world):
    op, d = world["users"]["operator"], operating_days_back(30)[6]
    with pytest.raises(ValidationError, match="No preparation batch"):
        sales.record_service(op, d, world["item_a"], world["lunch"], world["st"]["COUNTER-1"], 5, 0)
    prep.create_batch(op, d, world["item_a"], world["st"]["PREP-A"], 20)
    with pytest.raises(ValidationError, match="at least one"):
        sales.record_service(op, d, world["item_a"], world["lunch"], world["st"]["COUNTER-1"], 0, 0)


def test_zero_sales_day_is_reported_without_errors(world):
    op, d = world["users"]["operator"], operating_days_back(30)[7]
    prep.create_batch(op, d, world["item_b"], world["st"]["PREP-A"], 30)
    row = common.daily_summary(d, d, item_id=world["item_b"]).iloc[0]
    assert row["served_portions"] == 0 and row["expected_leftover_portions"] == 30 and row["recon_status"] == "not_weighed"
    assert metrics.waste_pct(row["discarded_portions_est"], row["prepared_portions"]) == 0


# ---------- weighing / disposition ----------
def _day_with_leftover(world, idx, prepared=100, served=70):
    op, d = world["users"]["operator"], operating_days_back(30)[idx]
    prep.create_batch(op, d, world["item_a"], world["st"]["PREP-A"], prepared)
    sales.record_service(op, d, world["item_a"], world["lunch"], world["st"]["COUNTER-1"], served, 0, datetime.combine(d, datetime.min.time()).replace(hour=13))
    return op, d


def test_weighing_with_dispositions_reconciles_and_matches_python(world):
    op, d = _day_with_leftover(world, 8)  # expected leftover 30 portions = 10.5 kg
    r = ws.record_weighing(op, d, world["item_a"], world["st"]["SCALE-01"], 10.5, "kg", "edible", "overproduction",
                           [{"type": "donated", "weight_kg": 4.0, "donation": {"recipient_name": "Test Food Bank", "food_safety_checked": True}},
                            {"type": "discarded", "weight_kg": 6.5}])
    assert r["portions_est"] == pytest.approx(30.0) and r["reconciliation"]["status"] == "balanced"
    row = common.daily_summary(d, d, item_id=world["item_a"]).iloc[0]
    assert row["donated_kg"] == pytest.approx(4.0) and row["discarded_kg"] == pytest.approx(6.5) and row["disposition_status"] == "complete"
    assert row["discarded_portions_est"] == pytest.approx(6.5 / 0.35, rel=1e-6)
    assert row["discarded_cost_est"] == pytest.approx(6.5 / 0.35 * 11.4, rel=1e-6)  # production cost, not selling price
    assert row["avoidable_cost_est"] == pytest.approx(row["discarded_cost_est"])      # edible food that was discarded
    k = metrics.summarize(common.daily_summary(d, d, item_id=world["item_a"]))
    assert k["waste_pct"] == pytest.approx(6.5 / 0.35 / 100 * 100, rel=1e-6)


def test_grams_are_converted_and_unexplained_gap_is_flagged(world):
    op, d = _day_with_leftover(world, 9)
    r = ws.record_weighing(op, d, world["item_a"], world["st"]["SCALE-01"], 5000, "g", "edible", "low_demand")
    assert r["weight_kg"] == pytest.approx(5.0)
    rec = r["reconciliation"]
    assert rec["status"] == "unexplained_loss" and rec["unexplained_portions_est"] > 5
    assert rec["disposition_status"] == "pending_disposition"
    assert any(p.weigh_id == r["weigh_id"] for p in ws.pending_dispositions(d).itertuples())


def test_food_safety_rules(world):
    op, d = _day_with_leftover(world, 10)
    args = (op, d, world["item_a"], world["st"]["SCALE-01"])
    with pytest.raises(ValidationError, match="not edible"):
        ws.record_weighing(*args, 2.0, "kg", "not_edible", "quality_issue", [{"type": "donated", "weight_kg": 2.0, "donation": {"recipient_name": "x", "food_safety_checked": True}}])
    with pytest.raises(ValidationError, match="food-safety"):
        ws.record_weighing(*args, 2.0, "kg", "edible", "low_demand", [{"type": "donated", "weight_kg": 2.0, "donation": {"recipient_name": "x", "food_safety_checked": False}}])
    with pytest.raises(ValidationError, match="recipient"):
        ws.record_weighing(*args, 2.0, "kg", "edible", "low_demand", [{"type": "donated", "weight_kg": 2.0, "donation": {"recipient_name": " ", "food_safety_checked": True}}])
    assert db.scalar("SELECT COUNT(*) FROM weighing_records WHERE operating_date=:d", {"d": d}) == 0  # failed validations saved nothing


def test_disposition_cannot_exceed_weighed_and_weight_sanity(world):
    op, d = _day_with_leftover(world, 11)
    args = (op, d, world["item_a"], world["st"]["SCALE-01"])
    with pytest.raises(ValidationError, match="more than"):
        ws.record_weighing(*args, 3.0, "kg", "edible", "low_demand", [{"type": "discarded", "weight_kg": 3.5}])
    with pytest.raises(ValidationError, match="implausibly high"):
        ws.record_weighing(*args, 500, "kg", "edible", "low_demand")
    for bad in (0, -1):
        with pytest.raises(ValidationError):
            ws.record_weighing(*args, bad, "kg", "edible", "low_demand")
    with pytest.raises(ValidationError):
        ws.record_weighing(*args, 1, "lb", "edible", "low_demand")


def test_pending_weighing_can_be_resolved_later_but_not_over_allocated(world):
    op, d = _day_with_leftover(world, 12)
    r = ws.record_weighing(op, d, world["item_a"], world["st"]["SCALE-01"], 4.0, "kg", "edible", "low_demand")
    ws.add_disposition(op, r["weigh_id"], "discarded", 1.0)
    with pytest.raises(ValidationError, match="unallocated"):
        ws.add_disposition(op, r["weigh_id"], "discarded", 3.5)
    ws.add_disposition(op, r["weigh_id"], "donated", 3.0, donation={"recipient_name": "Test Food Bank", "food_safety_checked": True})
    assert common.daily_summary(d, d, item_id=world["item_a"]).iloc[0]["disposition_status"] == "complete"
    assert not ws.donations(d, d).empty


# ---------- inventory ----------
def test_inventory_transaction_ledger_and_unit_conversion(world):
    admin = world["users"]["admin"]
    before = float(inv.stock().set_index("ingredient_id").loc[world["rice"], "current_stock"])
    inv.receive_stock(admin, world["rice"], 2000, "g", 100, operating_days_back(5)[0], world["sup"])  # 2000 g = 2 kg
    after = float(inv.stock().set_index("ingredient_id").loc[world["rice"], "current_stock"])
    assert after - before == pytest.approx(2.0)
    ledger = float(db.scalar("SELECT SUM(quantity_change) FROM inventory_movements WHERE ingredient_id=:i", {"i": world["rice"]}))
    assert ledger == pytest.approx(after)  # one source of truth: stock == sum of movements
    with pytest.raises(ValidationError, match="different measurement types"):
        inv.receive_stock(admin, world["rice"], 1, "l", 100, operating_days_back(5)[0], world["sup"])


def test_spoilage_rules_and_expiry_default(world):
    op = world["users"]["operator"]
    with pytest.raises(ValidationError, match="more than the stock"):
        inv.record_spoilage(op, world["oil"], 100000, "l", operating_days_back(5)[0])
    inv.record_spoilage(op, world["oil"], 1, "l", operating_days_back(5)[0], "leaked")
    sp = inv.spoilage_vs_purchases()
    assert float(sp.set_index("ingredient_name").loc["Test Oil", "spoiled_cost"]) == pytest.approx(140.0)
    exp = db.query_df("SELECT expiry_date, movement_date FROM inventory_movements WHERE ingredient_id=:i AND movement_type='purchase' ORDER BY movement_id LIMIT 1", {"i": world["oil"]}).iloc[0]
    assert (exp["expiry_date"] - exp["movement_date"]).days == 180  # shelf life from ingredient master
    with pytest.raises(ValidationError):
        inv.adjust_stock(op, world["oil"], 1, operating_days_back(5)[0], "")
    with pytest.raises(ValidationError):
        inv.adjust_stock(op, world["oil"], 0, operating_days_back(5)[0], "zero")


# ---------- permissions and login ----------
def test_services_enforce_roles_not_just_menus(world):
    an, op, mg = world["users"]["analyst"], world["users"]["operator"], world["users"]["manager"]
    d = operating_days_back(30)[13]
    with pytest.raises(PermissionDenied):
        prep.create_batch(an, d, world["item_a"], world["st"]["PREP-A"], 10)
    with pytest.raises(PermissionDenied):
        sales.record_service(an, d, world["item_a"], world["lunch"], world["st"]["COUNTER-1"], 1, 0)
    with pytest.raises(PermissionDenied):
        ws.record_weighing(an, d, world["item_a"], world["st"]["SCALE-01"], 1, "kg", "edible", "low_demand")
    with pytest.raises(PermissionDenied):
        inv.receive_stock(an, world["rice"], 1, "kg", 1, d, world["sup"])
    with pytest.raises(PermissionDenied):
        security.create_user(mg, "sneaky", "S", "Sneaky-123", "admin")
    with pytest.raises(PermissionDenied):
        security.set_user_active(op, world["users"]["analyst"]["user_id"], False)
    with pytest.raises(PermissionDenied):
        from services import forecast_service
        forecast_service.review(op, 1, "approve")


def test_authentication(world):
    assert security.authenticate("manager", PASSWORD)["role"] == "manager"
    assert security.authenticate("manager", "wrong-password1") is None
    assert security.authenticate("ghost", PASSWORD) is None
    assert security.authenticate("", "") is None
    assert security.authenticate("manager' OR '1'='1", "x") is None  # parameterised query, no injection
    h = db.query_df("SELECT password_hash FROM users WHERE username='manager'").iloc[0, 0]
    assert PASSWORD not in h and h.startswith("$2")
    admin = world["users"]["admin"]
    security.create_user(admin, "temp_user", "Temp", "Temp-pass-1", "operator")
    uid = int(db.scalar("SELECT user_id FROM users WHERE username='temp_user'"))
    security.set_user_active(admin, uid, False)
    assert security.authenticate("temp_user", "Temp-pass-1") is None
    with pytest.raises(ValidationError):
        security.set_user_active(admin, admin["user_id"], False)
    with pytest.raises(ValidationError):
        security.create_user(admin, "temp_user", "Dup", "Temp-pass-1", "operator")


def test_audit_trail_records_changes(world):
    a = audit.recent(500)
    assert {"create", "update_qty", "purchase", "spoilage"} <= set(a["action"])
    assert (a["user"] != "").all()


def test_database_connection_failure_is_handled(world):
    from sqlalchemy import create_engine
    good = db.get_engine()
    try:
        db.set_engine(create_engine("mysql+pymysql://nobody:nothing@127.0.0.1:1/none", connect_args={"connect_timeout": 1}))
        ok, msg = db.check_connection()
        assert ok is False and "Cannot connect" in msg and "nothing" not in msg  # no credentials leaked
        with pytest.raises(Exception):
            db.query_df("SELECT 1")
    finally:
        db.set_engine(good)
    assert db.check_connection()[0] is True
