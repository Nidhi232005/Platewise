"""Pure calculation tests (no database)."""
import math

import pandas as pd
import pytest

from analytics import cost_analysis as ca
from analytics import metrics as m
from analytics.inventory import expiry_alerts, fifo_remaining_lots


def test_waste_pct_and_surplus():
    assert m.waste_pct(2, 155) == pytest.approx(1.2903, abs=1e-3)
    assert m.surplus(155, 150) == 5


def test_zero_preparation_does_not_divide_by_zero():
    assert m.waste_pct(0, 0) == 0.0
    assert m.shortage_rate(0, 0) == 0.0
    assert m.safe_div(5, 0) == 0.0


def test_unit_conversion():
    assert m.kg_to_portions(1.5, 0.30) == pytest.approx(5.0)
    assert m.to_kg(500, "g") == pytest.approx(0.5)
    with pytest.raises(ValueError):
        m.to_kg(1, "lb")
    with pytest.raises(ValueError):
        m.kg_to_portions(1, 0)


def test_mae_rmse():
    assert m.mae([150, 152], [147.5, 149.5]) == pytest.approx(2.5)
    assert m.rmse([10, 10], [7, 13]) == pytest.approx(3.0)
    assert m.mae([], []) is None


def test_shortage_rate():
    assert m.shortage_rate(2, 8) == pytest.approx(25.0)


def test_reconcile_balanced():
    r = m.reconcile(155, 150, 1.5, 0.30, disposed_kg=1.5)
    assert r["expected_leftover"] == 5 and r["status"] == "balanced" and r["disposition_status"] == "complete"


def test_reconcile_unexplained_loss():
    r = m.reconcile(180, 150, 4.5, 0.30)  # expected 30, measured 15 -> gap 15 > tolerance 9
    assert r["measured_portions_est"] == pytest.approx(15.0) and r["unexplained_portions_est"] == pytest.approx(15.0)
    assert r["status"] == "unexplained_loss"


def test_reconcile_over_measured_not_weighed_invalid():
    assert m.reconcile(100, 90, 5.0, 0.30)["status"] == "over_measured"
    assert m.reconcile(100, 80, None, 0.30)["status"] == "not_weighed"
    assert m.reconcile(100, 100, None, 0.30)["status"] == "balanced"  # nothing left, nothing to weigh
    assert m.reconcile(100, 120, None, 0.30)["status"] == "invalid_counts"


def test_reconcile_pending_and_over_allocated_disposition():
    assert m.reconcile(155, 150, 1.5, 0.30, disposed_kg=0.5)["disposition_status"] == "pending_disposition"
    assert m.reconcile(155, 150, 1.5, 0.30, disposed_kg=2.0)["disposition_status"] == "over_allocated"


def test_allocate_served_fifo_oldest_first_and_order_preserved():
    b = [{"prepared_at": 2, "qty_prepared": 60}, {"prepared_at": 1, "qty_prepared": 100}]
    assert m.allocate_served_fifo(b, 120) == [20, 100]
    assert m.allocate_served_fifo(b, 0) == [0, 0]
    assert m.allocate_served_fifo(b, 500) == [60, 100]


def _daily():
    return pd.DataFrame({
        "operating_date": pd.to_datetime(["2026-10-01", "2026-10-02"]), "item_id": [1, 1], "prepared_portions": [100, 100], "served_portions": [90, 100],
        "sold_out_flag": [0, 1], "discarded_portions_est": [5.0, 0.0], "discarded_cost_est": [50.0, 0.0], "avoidable_cost_est": [40.0, 0.0],
        "donated_portions_est": [3.0, 0.0], "donated_value_est": [30.0, 0.0], "revenue": [900.0, 1000.0], "prep_cost_total": [1000.0, 1000.0],
        "selling_price": [10.0, 10.0], "discarded_kg": [1.5, 0], "donated_kg": [0.9, 0], "measured_kg": [3.0, 0],
        "recon_status": ["balanced", "balanced"]})


def test_summarize_and_cost_breakdown():
    s = m.summarize(_daily())
    assert s["prepared"] == 200 and s["served"] == 190 and s["surplus"] == 10
    assert s["waste_pct"] == pytest.approx(2.5) and s["shortage_rate"] == pytest.approx(50.0)
    c = ca.cost_breakdown(_daily())
    assert c["waste_cost"] == 50 and c["avoidable_cost"] == 40 and c["foregone_revenue"] == pytest.approx(50.0)
    assert m.summarize(pd.DataFrame())["prepared"] == 0


def test_recipe_cost_and_before_after():
    assert ca.recipe_unit_cost([(0.10, 100), (0.01, 140)]) == pytest.approx(11.4)
    d = _daily()
    out = ca.before_after(d, 1, "2026-10-02", window_days=5)
    assert out["before"]["days"] == 1 and out["after"]["days"] == 1
    assert out["waste_pct_change"] == pytest.approx(0 - 5.0)
    assert out["shortage_rate_change"] == pytest.approx(100.0)


def test_fifo_lots_and_expiry_alerts():
    mv = pd.DataFrame({"movement_id": [1, 2, 3], "ingredient_id": [1, 1, 1], "movement_type": ["purchase", "purchase", "usage"],
                       "quantity_change": [10.0, 10.0, -12.0], "movement_date": pd.to_datetime(["2026-10-01", "2026-10-05", "2026-10-06"]),
                       "expiry_date": pd.to_datetime(["2026-10-08", "2026-10-20", None])})
    lots = fifo_remaining_lots(mv)
    assert len(lots) == 1 and lots.iloc[0]["remaining_qty"] == pytest.approx(8.0)  # oldest lot fully used, newer lot has 8 left
    assert expiry_alerts(lots, "2026-10-19", 3).iloc[0]["alert"] == "expiring_soon"
    assert expiry_alerts(lots, "2026-10-25", 3).iloc[0]["alert"] == "expired"
    assert expiry_alerts(lots, "2026-10-01", 3).empty
