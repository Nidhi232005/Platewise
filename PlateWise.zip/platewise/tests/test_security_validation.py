"""Hashing, permission matrix and input validation (no database)."""
import pytest

from core import security as sec
from core import validation as v


def test_password_hash_is_not_plaintext_and_verifies():
    h = sec.hash_password("Secret-123")
    assert h != "Secret-123" and h.startswith("$2") and sec.verify_password("Secret-123", h)
    assert not sec.verify_password("wrong", h) and not sec.verify_password("x", "not-a-hash")
    assert sec.hash_password("Secret-123") != h  # salted


@pytest.mark.parametrize("role,perm,allowed", [
    ("admin", "users.manage", True), ("admin", "anything.at.all", True),
    ("manager", "forecast.review", True), ("manager", "users.manage", False),
    ("operator", "prep.write", True), ("operator", "forecast.review", False), ("operator", "export", False),
    ("analyst", "export", True), ("analyst", "prep.write", False), ("analyst", "waste.write", False),
])
def test_permission_matrix(role, perm, allowed):
    assert sec.can({"role": role}, perm) is allowed


def test_unknown_role_and_anonymous_are_denied():
    assert not sec.can({"role": "hacker"}, "view") and not sec.can(None, "view")
    with pytest.raises(sec.PermissionDenied):
        sec.require(None, "view")


def test_validation_helpers():
    assert v.positive_int("5", "Qty") == 5
    for bad in (0, -1, "abc", None, 10**9):
        with pytest.raises(v.ValidationError):
            v.positive_int(bad, "Qty")
    with pytest.raises(v.ValidationError):
        v.positive_number(float("nan"), "Weight")
    with pytest.raises(v.ValidationError):
        v.non_negative_number(-0.1, "Price")
    assert v.non_negative_int(0, "x") == 0
    with pytest.raises(v.ValidationError):
        v.require_text("   ", "Name")
    with pytest.raises(v.ValidationError):
        v.one_of("x", ["a", "b"], "Choice")
    with pytest.raises(v.ValidationError):
        v.valid_password("short1")
    with pytest.raises(v.ValidationError):
        v.valid_password("onlyletters")
    assert v.valid_password("Good-pass1")
