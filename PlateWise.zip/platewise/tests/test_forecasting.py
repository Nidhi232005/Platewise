"""Forecasting tests: baseline correctness, no data leakage, edge cases, model selection."""
import math

import numpy as np
import pandas as pd
import pytest

from analytics import forecasting as fc

BASE = {0: 150, 1: 140, 2: 130, 3: 135, 4: 160, 5: 100}


def series(weeks=10, start="2026-07-06", demand_fn=None, **extra):
    dates = [d for d in pd.date_range(start, periods=weeks * 7) if d.weekday() != 6]
    df = pd.DataFrame({"operating_date": dates})
    df["served"] = [demand_fn(d) if demand_fn else BASE[d.weekday()] for d in dates]
    df["sold_out"] = 0
    for k, v in extra.items():
        df[k] = v
    return fc.prepare_history(df)


def test_baseline_is_mean_of_last_k_same_weekdays():
    h = series()
    target = pd.Timestamp("2026-09-14")  # a Monday after the history
    h = h[h["operating_date"] < target]
    assert fc.predict_baseline(h, target, fc.DEFAULT_CFG) == pytest.approx(150.0)


def test_baseline_uses_only_k_most_recent():
    def f(d):
        return 100 if d < pd.Timestamp("2026-08-17") else 200
    h = series(demand_fn=f)
    target = pd.Timestamp("2026-09-14")
    p = fc.predict_baseline(h[h["operating_date"] < target], target, fc.DEFAULT_CFG)
    assert p == pytest.approx(200.0)  # old values (100) ignored once 4 newer Mondays exist


def test_no_future_leakage_in_forecast():
    h = series()
    target = pd.Timestamp("2026-08-31")
    a = fc.forecast_item(h, target)
    h2 = h.copy()
    h2.loc[h2["operating_date"] >= target, "demand"] = 99999.0  # poison everything on/after the target date
    b = fc.forecast_item(h2, target)
    assert a["predicted_demand"] == b["predicted_demand"] and a["recommended_qty"] == b["recommended_qty"]
    assert a["history_points"] == b["history_points"] == int((h["operating_date"] < target).sum())


def test_backtest_uses_only_earlier_rows():
    h = series(weeks=9)
    # make the LAST day an extreme outlier; forecasts for earlier days must not change
    h2 = h.copy()
    h2.loc[h2.index[-1], "demand"] = 5000.0
    cfg = {**fc.DEFAULT_CFG}
    for i in range(len(h) - 10, len(h) - 1):
        p1 = fc.predict_baseline(h.iloc[:i], h.loc[i, "operating_date"], cfg)
        p2 = fc.predict_baseline(h2.iloc[:i], h2.loc[i, "operating_date"], cfg)
        assert p1 == p2


def test_insufficient_history_is_explicit():
    h = series(weeks=1).head(5)
    r = fc.forecast_item(h, "2026-08-01")
    assert r["status"] == "insufficient_data" and r["recommended_qty"] is None and "manager" in r["explanation"].lower()


def test_new_item_with_no_history():
    empty = fc.prepare_history(pd.DataFrame({"operating_date": [], "served": [], "sold_out": []}))
    assert fc.forecast_item(empty, "2026-08-01")["status"] == "insufficient_data"


def test_zero_demand_item():
    h = series(demand_fn=lambda d: 0)
    r = fc.forecast_item(h, "2026-09-14")
    assert r["model_used"] == "zero_demand" and r["recommended_qty"] == 0


def test_sold_out_days_are_uplifted():
    df = pd.DataFrame({"operating_date": pd.to_datetime(["2026-10-01", "2026-10-02"]), "served": [100, 100], "sold_out": [0, 1]})
    h = fc.prepare_history(df, sold_out_uplift=0.10)
    assert list(h["demand"]) == [100.0, pytest.approx(110.0)]


def test_recommendation_is_at_least_prediction_and_rounded():
    h = series(demand_fn=lambda d: BASE[d.weekday()] + (3 if d.day % 2 else -3))
    r = fc.forecast_item(h, "2026-09-14", cfg={"rounding_step": 5})
    assert r["recommended_qty"] >= math.ceil(r["predicted_demand"])
    assert r["recommended_qty"] % 5 == 0 or r["recommended_qty"] == math.ceil(r["predicted_demand"])
    assert "estimate" in r["explanation"].lower()


def test_safety_stock_grows_with_forecast_error():
    rng = np.random.default_rng(0)
    calm = series(demand_fn=lambda d: BASE[d.weekday()] + int(rng.normal(0, 2)))
    wild = series(demand_fn=lambda d: BASE[d.weekday()] + int(rng.normal(0, 25)))
    a, b = fc.forecast_item(calm, "2026-09-14"), fc.forecast_item(wild, "2026-09-14")
    assert b["buffer_pct"] > a["buffer_pct"]


def test_round_to_step():
    assert fc.round_to_step(147.5, 5) == 150 and fc.round_to_step(152.4, 5) == 150 and fc.round_to_step(152.5, 5) == 155


def test_select_model_requires_clear_improvement_and_enough_data():
    scores = {"baseline": {"mae": 10, "n": 14}, "ridge": {"mae": 8.0, "baseline_mae": 10.0, "n": 14}}
    assert fc.select_model(scores, 0.05) == "ridge"
    scores["ridge"]["mae"] = 9.8  # only 2% better
    assert fc.select_model(scores, 0.05) == "baseline"
    scores["ridge"] = {"mae": 5.0, "baseline_mae": 10.0, "n": 5}  # too few test days
    assert fc.select_model(scores, 0.05) == "baseline"
    scores["ridge"] = {"mae": None, "baseline_mae": None, "n": 0}
    assert fc.select_model(scores, 0.05) == "baseline"


def test_footfall_ratio_only_when_expected_footfall_is_known():
    h = series(footfall_obs=200.0, footfall_exp=np.nan)
    target = pd.Timestamp("2026-09-14")
    past = h[h["operating_date"] < target]
    assert fc.predict_footfall_ratio(past, target, fc.DEFAULT_CFG, None) is None
    assert fc.predict_footfall_ratio(past, target, fc.DEFAULT_CFG, float("nan")) is None
    assert fc.predict_footfall_ratio(past, target, fc.DEFAULT_CFG, 300.0) == pytest.approx(150.0 * 300 / 200)


def test_missing_footfall_falls_back_to_baseline():
    h = series()  # no footfall columns have values
    r = fc.forecast_item(h, "2026-09-14", expected_footfall=250)
    assert r["status"] == "ok" and r["model_used"] in ("baseline", "moving_avg_7", "ridge")


def test_backtest_scores_have_expected_shape():
    rng = np.random.default_rng(3)
    h = series(weeks=12, demand_fn=lambda d: BASE[d.weekday()] + int(rng.normal(0, 8)))
    s = fc.backtest(h, fc.DEFAULT_CFG)
    assert set(s) == {"baseline", "moving_avg_7", "footfall_ratio", "ridge"}
    assert s["baseline"]["mae"] is not None and s["baseline"]["n"] == fc.DEFAULT_CFG["backtest_days"]
    assert s["moving_avg_7"]["mae"] > 0 and s["ridge"]["mae"] is not None
