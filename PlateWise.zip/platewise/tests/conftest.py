"""Shared fixtures. Integration tests use a SEPARATE database named by TEST_DATABASE_URL and DROP its tables.
Tests are skipped (not failed) when TEST_DATABASE_URL is unset or the server is not reachable."""
import os
import sys
from datetime import date, timedelta
from pathlib import Path

import pytest
from sqlalchemy import create_engine, text

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from core import database as db  # noqa: E402
from core import security  # noqa: E402
from services import common, inventory_service as inv, menu_service as ms  # noqa: E402

TEST_URL = os.getenv("TEST_DATABASE_URL")  # e.g. mysql+pymysql://user:password@127.0.0.1:3306/platewise_test?charset=utf8mb4
PASSWORD = "Test-Pass-123"


def operating_days_back(n: int, start: date | None = None) -> list[date]:
    """The last n Mon-Sat dates strictly before `start` (default today), oldest first."""
    d, out = (start or date.today()) - timedelta(days=1), []
    while len(out) < n:
        if d.weekday() != 6:
            out.append(d)
        d -= timedelta(days=1)
    return sorted(out)


@pytest.fixture(scope="module")
def engine():
    if not TEST_URL:
        pytest.skip("Set TEST_DATABASE_URL to a throw-away MySQL database to run the integration tests")
    eng = create_engine(TEST_URL, pool_pre_ping=True)
    try:
        with eng.connect() as c:
            c.execute(text("SELECT 1"))
    except Exception as exc:  # pragma: no cover
        pytest.skip(f"MySQL test database not reachable ({exc.__class__.__name__}); set TEST_DATABASE_URL")
    db.set_engine(eng)
    db.create_schema(eng, reset=True)
    yield eng
    db.set_engine(None)


@pytest.fixture(scope="module")
def world(engine):
    """Fresh schema + 4 users + 2 menu items with recipes + one supplier + opening stock."""
    ids = {}
    for u, role in [("admin", "admin"), ("manager", "manager"), ("operator", "operator"), ("analyst", "analyst")]:
        ids[u] = security.create_user(None, u, f"Test {u}", PASSWORD, role, bootstrap=True)
    users = {u: {"user_id": i, "username": u, "full_name": u, "role": u if u != "admin" else "admin"} for u, i in ids.items()}
    admin = users["admin"]
    cat = int(ms.categories().set_index("category_name").loc["Main meal", "category_id"])
    pers = common.periods().set_index("period_name")
    lunch, eve = int(pers.loc["Lunch", "period_id"]), int(pers.loc["Evening snacks", "period_id"])
    item_a = ms.save_item(admin, "Test Biryani", cat, lunch, 70, 0.35, "test: weighed 10 portions", None, 5)
    item_b = ms.save_item(admin, "Test Samosa", cat, eve, 15, 0.10, "test: weighed 20 pieces", 6.0, 10)  # no recipe -> menu estimate cost
    rice = inv.add_ingredient(admin, "Test Rice", "kg", 100, 5, 365)
    oil = inv.add_ingredient(admin, "Test Oil", "l", 140, 2, 180)
    sup = inv.add_supplier(admin, "Test Supplier")
    ms.set_recipe_line(admin, item_a, rice, 0.10)
    ms.set_recipe_line(admin, item_a, oil, 0.01)
    inv.receive_stock(admin, rice, 500, "kg", 100, date.today() - timedelta(days=60), sup)
    inv.receive_stock(admin, oil, 100, "l", 140, date.today() - timedelta(days=60), sup)
    st_ids = {r.station_code: int(r.station_id) for r in common.stations().itertuples()}
    return {"users": users, "item_a": item_a, "item_b": item_b, "rice": rice, "oil": oil, "sup": sup, "lunch": lunch, "eve": eve,
            "st": st_ids, "engine": engine}
