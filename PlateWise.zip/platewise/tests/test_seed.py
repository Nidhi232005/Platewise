"""The synthetic generator: reproducible, clearly labelled, internally consistent."""
from datetime import date

import pytest

from core import database as db
from scripts import seed_synthetic as seed
from services import common, reporting_service as rs

END = date(2026, 10, 17)


def totals():
    return rs.database_totals(), int(db.scalar("SELECT COUNT(*) FROM weighing_records")), float(db.scalar("SELECT SUM(quantity_change) FROM inventory_movements"))


def test_seed_is_reproducible_and_consistent(engine):
    s1 = seed.seed(engine, days=24, end_date=END, intervention_days=6, rng_seed=7, password="Seed-Pass-123", verbose=False)
    t1 = totals()
    s2 = seed.seed(engine, days=24, end_date=END, intervention_days=6, rng_seed=7, password="Seed-Pass-123", verbose=False)
    assert totals() == t1                                   # same seed -> identical data
    seed.seed(engine, days=24, end_date=END, intervention_days=6, rng_seed=8, password="Seed-Pass-123", verbose=False)
    assert totals() != t1                                   # different seed -> different data
    seed.seed(engine, days=24, end_date=END, intervention_days=6, rng_seed=7, password="Seed-Pass-123", verbose=False)

    # everything the generator writes is labelled synthetic
    assert db.scalar("SELECT COUNT(*) FROM prep_batches WHERE is_synthetic=0") == 0
    assert db.scalar("SELECT COUNT(*) FROM weighing_records WHERE is_synthetic=0") == 0
    assert db.scalar("SELECT COUNT(*) FROM service_records WHERE source<>'synthetic'") == 0
    assert db.scalar("SELECT COUNT(*) FROM forecast_runs WHERE is_synthetic=0") == 0

    # integrity: stock never negative, nothing served beyond prepared, weighed food fully allocated
    stock = db.query_df("SELECT ingredient_name, current_stock FROM v_inventory_stock")
    assert (stock["current_stock"] >= -1e-6).all()
    d = common.daily_summary()
    assert (d["served_portions"] <= d["prepared_portions"]).all()
    assert (d["disposition_status"].isin(["complete", "n/a"])).all()
    assert d["recon_status"].isin(["balanced", "unexplained_loss", "over_measured", "not_weighed"]).all()
    assert {"unexplained_loss", "not_weighed"} <= set(d["recon_status"])   # controlled data-quality problems are present
    assert db.scalar("SELECT COUNT(*) FROM inventory_movements WHERE movement_type='spoilage'") > 0
    assert db.scalar("SELECT COUNT(*) FROM actual_outcomes") == s1["outcomes"] > 0
    assert d["sold_out_flag"].sum() > 0 and (d["prepared_portions"] > d["served_portions"] * 1.1).any()  # shortages and overproduction exist
    assert db.query_df("SELECT 1 FROM footfall WHERE expected_count IS NULL LIMIT 1").shape[0] == 1  # some expected-footfall values are missing on purpose


def test_seeded_database_logins_and_roles(engine):
    from core import security
    assert security.authenticate("manager", "Seed-Pass-123")["role"] == "manager"
    assert security.authenticate("analyst", "wrong") is None
