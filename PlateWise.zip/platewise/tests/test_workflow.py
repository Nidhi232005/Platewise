"""End-to-end workflow: record operations -> forecast -> manager approval -> actual outcome -> evaluation -> reports."""
import zipfile
from datetime import datetime
from io import BytesIO

import pandas as pd
import pytest
from openpyxl import load_workbook

from core import database as db
from core.security import PermissionDenied
from core.validation import ValidationError
from exports import excel_export as xl, tableau_export as tb
from services import (common, forecast_service as fs, preparation_service as prep, recommendation_service as rec, reporting_service as rs,
                      sales_service as sales, waste_service as ws, zone_service)
from tests.conftest import operating_days_back

DAYS = operating_days_back(26)
HIST, TARGET = DAYS[:24], DAYS[24]
DEMAND = lambda d: 80 + 5 * d.weekday()   # deterministic weekday pattern: Mon 80 ... Sat 105


def at(d, h, m=0):
    return datetime(d.year, d.month, d.day, h, m)


@pytest.fixture(scope="module")
def hist(world):
    op, ia = world["users"]["operator"], world["item_a"]
    for d in HIST:
        prep.create_batch(op, d, ia, world["st"]["PREP-A"], 120, at(d, 11))
        sales.record_service(op, d, ia, world["lunch"], world["st"]["COUNTER-1"], DEMAND(d), 0, at(d, 13))
        left = (120 - DEMAND(d)) * 0.35
        ws.record_weighing(op, d, ia, world["st"]["SCALE-01"], round(left, 3), "kg", "edible", "overproduction", [{"type": "discarded", "weight_kg": round(left, 3)}], at(d, 15))
        sales.record_footfall(op, d, world["lunch"], observed=300, expected=300)
    prep.create_batch(op, HIST[-1], world["item_b"], world["st"]["PREP-B"], 40, at(HIST[-1], 15))  # item_b has only one day of history
    return True


def test_forecast_generates_explainable_recommendations(world, hist):
    mg = world["users"]["manager"]
    r = fs.run_forecast(mg, TARGET, allow_past=True)
    assert r["created"] == 2
    plan = fs.pending_for(TARGET).set_index("item_name")
    a = plan.loc["Test Biryani"]
    assert a["status"] == "pending" and a["history_points"] == 24
    assert a["predicted_demand"] == pytest.approx(DEMAND(TARGET), abs=6)  # same-weekday pattern recovered
    assert a["recommended_qty"] >= a["predicted_demand"]
    assert "estimate" in a["explanation"].lower() and "Backtest" in a["explanation"]
    b = plan.loc["Test Samosa"]
    assert b["status"] == "insufficient_data" and pd.isna(b["recommended_qty"]) and "manager" in b["explanation"].lower()


def test_forecast_for_past_date_needs_flag_and_non_operating_day_is_rejected(world, hist):
    mg = world["users"]["manager"]
    with pytest.raises(ValidationError, match="today or a future"):
        fs.run_forecast(mg, TARGET)
    with pytest.raises(ValidationError, match="does not operate"):
        sunday = next(d for d in pd.date_range("2026-11-01", periods=7) if d.weekday() == 6).date()
        fs.run_forecast(mg, sunday)
    with pytest.raises(PermissionDenied):
        fs.run_forecast(world["users"]["operator"], TARGET, allow_past=True)


def test_manager_review_rules(world, hist):
    mg, op = world["users"]["manager"], world["users"]["operator"]
    plan = fs.pending_for(TARGET).set_index("item_name")
    rid_b = int(plan.loc["Test Samosa", "rec_id"])
    with pytest.raises(PermissionDenied):
        fs.review(op, rid_b, "adjust", 30, "x")
    with pytest.raises(ValidationError):
        fs.review(mg, rid_b, "approve")             # nothing was recommended, so cannot approve as-is
    with pytest.raises(ValidationError):
        fs.review(mg, rid_b, "adjust", 30, "")      # reason required
    fs.review(mg, rid_b, "adjust", 30, "new item: starting small")
    p = fs.pending_for(TARGET).set_index("item_name").loc["Test Samosa"]
    assert p["status"] == "adjusted" and p["approved_qty"] == 30
    rid_a = int(plan.loc["Test Biryani", "rec_id"])
    fs.review(mg, rid_a, "approve")
    a = fs.pending_for(TARGET).set_index("item_name").loc["Test Biryani"]
    assert a["status"] == "approved" and a["approved_qty"] == a["recommended_qty"]


def test_rerun_keeps_approved_plans(world, hist):
    r = fs.run_forecast(world["users"]["manager"], TARGET, allow_past=True)
    assert r["created"] == 0 and set(r["skipped_already_approved"]) == {"Test Biryani", "Test Samosa"}


def test_actual_outcome_is_recorded_and_evaluated(world, hist):
    op, ia = world["users"]["operator"], world["item_a"]
    plan = fs.pending_for(TARGET).set_index("item_name").loc["Test Biryani"]
    qty = int(plan["approved_qty"])
    prep.create_batch(op, TARGET, ia, world["st"]["PREP-A"], qty, at(TARGET, 11), rec_id=int(plan["rec_id"]))
    served = min(qty, 88)
    sales.record_service(op, TARGET, ia, world["lunch"], world["st"]["COUNTER-1"], served, 0, at(TARGET, 13))
    assert fs.evaluate_outcomes() >= 1
    assert fs.evaluate_outcomes() >= 1  # idempotent: second run updates, never duplicates
    out = db.query_df("SELECT * FROM actual_outcomes WHERE rec_id=:r", {"r": int(plan["rec_id"])})
    assert len(out) == 1
    o = out.iloc[0]
    assert o["prepared_qty"] == qty and o["served_qty"] == served and o["surplus_qty"] == qty - served and o["shortage_flag"] == 0
    assert o["abs_error"] == pytest.approx(abs(served - float(plan["predicted_demand"])), abs=0.01)
    acc = fs.accuracy_summary()
    assert "Test Biryani" in set(acc["item_name"]) and acc.set_index("item_name").loc["Test Biryani", "mae"] >= 0
    assert not fs.series_for_item(ia).empty


def test_sold_out_day_counts_as_shortage_with_uplift(world, hist):
    op, d = world["users"]["operator"], TARGET
    plan = fs.pending_for(TARGET).set_index("item_name").loc["Test Samosa"]
    prep.create_batch(op, d, world["item_b"], world["st"]["PREP-A"], 30, at(d, 15), rec_id=int(plan["rec_id"]))
    sales.record_service(op, d, world["item_b"], world["eve"], world["st"]["COUNTER-1"], 30, 0, at(d, 17), sold_out=True)
    fs.evaluate_outcomes()
    o = db.query_df("SELECT * FROM actual_outcomes WHERE rec_id=:r", {"r": int(plan["rec_id"])}).iloc[0]
    assert o["shortage_flag"] == 1 and float(o["actual_demand_est"]) == pytest.approx(33.0)  # 30 served x 1.10 uplift
    assert pd.isna(o["abs_error"])  # no prediction existed for this item, so no error is invented


def test_zone_status_covers_all_five_zones(world, hist):
    z = zone_service.zone_status(TARGET)
    assert [x["code"] for x in z] == ["A", "B", "C", "D", "E"]
    assert z[0]["count"] >= 1 and all("alerts" in x and "quantities" in x for x in z)


def test_advisory_recommendations_lifecycle(world, hist):
    mg = world["users"]["manager"]
    n = rec.generate(mg, HIST[-1])
    assert n >= 1
    df = rec.listing("open")
    row = df[df["rule_code"] == "repeated_surplus"].iloc[0]
    for col in ("problem", "proposed_action", "expected_benefit", "confidence", "limitations", "metrics_json"):
        assert row[col]
    assert rec.generate(mg, HIST[-1]) == 0          # no duplicate of an open recommendation
    with pytest.raises(PermissionDenied):
        rec.review(world["users"]["operator"], int(row["adv_id"]), "approved")
    with pytest.raises(ValidationError):
        rec.review(mg, int(row["adv_id"]), "rejected", "")
    rec.review(mg, int(row["adv_id"]), "approved")
    with pytest.raises(ValidationError):
        rec.review(mg, int(row["adv_id"]), "implemented")   # needs implementation date
    rec.review(mg, int(row["adv_id"]), "implemented", "trial", HIST[10])
    out = rec.measured_outcome(int(row["adv_id"]), 7)
    assert out and out["before"]["days"] > 0 and out["after"]["days"] > 0


def test_all_named_sql_reports_execute(world, hist):
    q = rs.named_queries()
    assert len(q) >= 10
    for k in q:
        assert isinstance(rs.run_named_query(k), pd.DataFrame), k
    w = rs.run_named_query("highest_waste_items")
    assert w.iloc[0]["waste_pct"] >= w.iloc[-1]["waste_pct"]


def test_excel_totals_match_mysql(world, hist):
    data, info = xl.build_workbook()
    chk = xl.verify_workbook(data)
    assert chk["ok"], chk
    assert chk["excel"] == chk["mysql"] == rs.database_totals()
    wb = load_workbook(BytesIO(data))
    for sheet, tname, *_ in xl.SHEETS:
        assert sheet in wb.sheetnames
        if info["rows"][sheet]:
            assert tname in wb[sheet].tables
    assert {"README", "Summary", "Pivot_Guide"} <= set(wb.sheetnames)
    readme = " ".join(str(c.value) for row in wb["README"].iter_rows() for c in row if c.value)
    assert "NOT a PivotTable" in readme and "SYNTHETIC" in readme
    formulas = [c.value for row in wb["Summary"].iter_rows() for c in row if isinstance(c.value, str) and c.value.startswith("=SUMIFS")]
    assert formulas
    base = pd.read_excel(BytesIO(data), sheet_name="Pivot_Base")
    assert base["Prepared_Portions"].sum() == info["totals"]["prepared"] == rs.database_totals()["prepared"]
    assert pd.api.types.is_datetime64_any_dtype(base["Date"]) and pd.api.types.is_integer_dtype(base["Prepared_Portions"])


def test_excel_verification_detects_tampering(world, hist):
    data, _ = xl.build_workbook()
    wb = load_workbook(BytesIO(data))
    ws_ = wb["Pivot_Base"]
    col = [c.value for c in ws_[1]].index("Prepared_Portions") + 1
    ws_.cell(row=2, column=col).value = ws_.cell(row=2, column=col).value + 7
    bio = BytesIO()
    wb.save(bio)
    chk = xl.verify_workbook(bio.getvalue())
    assert not chk["ok"] and "prepared" in chk["differences"]


def test_date_filtered_export_matches_filtered_mysql_totals(world, hist):
    s, e = HIST[5], HIST[12]
    data, info = xl.build_workbook(s, e)
    assert xl.verify_workbook(data, s, e)["ok"]
    assert info["totals"]["prepared"] == rs.database_totals(s, e)["prepared"] < rs.database_totals()["prepared"]


def test_tableau_zip_contents_and_control_totals(world, hist):
    z, counts = tb.build_tableau_zip()
    zf = zipfile.ZipFile(BytesIO(z))
    assert {"fact_daily_item.csv", "fact_forecast_vs_actual.csv", "dim_item.csv", "control_totals.csv", "README.txt"} <= set(zf.namelist())
    ctrl = pd.read_csv(zf.open("control_totals.csv")).iloc[0]
    fact = pd.read_csv(zf.open("fact_daily_item.csv"))
    assert int(ctrl["prepared"]) == int(fact["Prepared_Portions"].sum()) == rs.database_totals()["prepared"]
    assert len(fact) == len(common.daily_summary())
